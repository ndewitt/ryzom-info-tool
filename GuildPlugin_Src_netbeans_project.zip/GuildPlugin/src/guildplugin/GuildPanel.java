/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package guildplugin;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JList;
import ryzominfotool.gui.*;
import ryzominfotool.gui.utils.Item;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
import java.util.zip.GZIPInputStream;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.NumberFormatter;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import ryzominfotool.Enums.Language;
import ryzominfotool.gui.borders.CustomBorder;
import ryzominfotool.Main;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.utils.ItemExporter;
import ryzominfotool.gui.utils.ItemUtils;
import ryzominfotool.gui.utils.ItemUtils.ItemCats;
import ryzominfotool.gui.utils.panels.CrystalViewPanel;
import ryzominfotool.gui.utils.panels.DekoratedTabbedPane;
import ryzominfotool.gui.utils.panels.InventoryPanel;
import ryzominfotool.gui.utils.panels.MatInventoryPanel;

/**
 * The GuildPlugin.
 * - Available information on the guil
 * - Available items of the guild rooms
 * - Available materials in the guild rooms
 * @author Niels-Peter de Witt
 */
public class GuildPanel extends PluggableContent
{

    private Vector<Item> allItems = new Vector();
    private Properties prop = new Properties();
    private File propFile = new File("plugins/GuildPlugin/GuildPlugin.prop");
    private CustomBorder custBorder = new CustomBorder();
    private DekoratedTabbedPane tabPane = new DekoratedTabbedPane();
    private MatInventoryPanel matInventoryPanel1 = new MatInventoryPanel();
    private InventoryPanel inventoryPanel1 = new InventoryPanel();
    private CrystalViewPanel crystalViewPanel1 = new CrystalViewPanel();
    private String[][] memberData = new String[0][2];
    private String[] header = new String[]
    {
        "Name", "Rank"
    };
    private boolean manualKeyFill = false;
    private Language curLanguage = Language.English;
    private Thread thread = null;    
    private JFileChooser jfcExport = new JFileChooser();    
    private ItemExporter itemExporter = new ItemExporter();    
    private DefaultListCellRenderer cmbFilterItemsRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof ItemCats)
            {
                ItemCats ip = (ItemCats) value;
                String txt = TranslationDbHandler.getTranslation(ItemCats.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName());
                lbl.setText(txt);
            }
            return lbl;
        }
    };

    /** Creates new form GuildPanel */
    public GuildPanel()
    {
        initComponents();
        propFile.getParentFile().mkdirs();
        cmbFilterItems.removeAllItems();
        for (ItemCats ic : ItemCats.values())
        {
            cmbFilterItems.addItem(ic);
        }
        cmbFilterItems.setRenderer(cmbFilterItemsRenderer);
        try
        {
            prop.loadFromXML(new FileInputStream(propFile));
        }
        catch (Exception ex)
        {
            prop.clear();
        }
        rebuildKeyList();

        lblNameValue.setText("");
        lblRaceValue.setText("");
        lblShardValue.setText("");
        txtDescriptionValue.setText("");
        lblMoneyValue.setText("");
        lblCultureValue.setText("");
        lblCivilizationValue.setText("");
        tblMembers.setModel(new DefaultTableModel());
        tabPane.setButtonBackgroundColor(new Color(200, 255, 200));
        tabPane.addComponent(panGuildInfo, "Guild data");
        tabPane.addComponent(panGuildInv, "Guild Inventory");
        tabPane.addComponent(matInventoryPanel1, "Guild Materials Only");
        panDekPane.add(tabPane, BorderLayout.CENTER);
        crystalViewPanel1.setOpaque(true);
        crystalViewPanel1.setBorder(new CustomBorder());
        panCrystalCont.add(crystalViewPanel1, BorderLayout.CENTER);
        panInvMatCont.add(inventoryPanel1, BorderLayout.CENTER);

    }

    /**
     * Rebuilds the combobox with the guild keys
     */
    private void rebuildKeyList()
    {
        String oldKey = getSelectedKey();
        String newSelObj = null;

        cmbGuildKey.removeAllItems();
        manualKeyFill = true;
        Vector<String> keys = new Vector(prop.stringPropertyNames());
        Collections.sort(keys);
        for (String key : keys)
        {
            String val = prop.getProperty(key);
            String newKey = key;
            if (val != null && val.length() > 0)
            {
                newKey = key + " - " + val;
            }
            cmbGuildKey.addItem(newKey);
            if (key.equals(oldKey))
            {
                newSelObj = newKey;
            }
        }
        cmbGuildKey.setSelectedItem(newSelObj);
        manualKeyFill = false;
    }

    /**
     * Returns the selected key out of the selected combobox item
     * @return the selected key out of the selected combobox item
     */
    private String getSelectedKey()
    {
        String key = (String) cmbGuildKey.getSelectedItem();
        if (key != null)
        {
            if (key.contains(" - "))
            {
                int index = key.indexOf(" - ");
                key = key.substring(0, index);
            }
        }
        return key;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panGuildInv = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblFilterTxt = new javax.swing.JLabel();
        cmbFilterItems = new javax.swing.JComboBox();
        butExportItems = new javax.swing.JButton();
        panInvMatCont = new javax.swing.JPanel();
        panGuildInfo = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblMembers = new javax.swing.JTable();
        lblMemberTitleTxt = new javax.swing.JLabel();
        panGuildData = new javax.swing.JPanel();
        lblCivilizationValue = new javax.swing.JLabel();
        lblCultureValue = new javax.swing.JLabel();
        lblRaceValue = new javax.swing.JLabel();
        lblRace = new javax.swing.JLabel();
        lblMoney = new javax.swing.JLabel();
        lblMoneyValue = new javax.swing.JLabel();
        lblCulture = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblCivilization = new javax.swing.JLabel();
        lblShardValue = new javax.swing.JLabel();
        lblShard = new javax.swing.JLabel();
        lblNameValue = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        lblDesc = new javax.swing.JLabel();
        txtDescriptionValue = new javax.swing.JLabel();
        panCrystalCont = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        panDekPane = new javax.swing.JPanel();
        panKeyData = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblKeyTxt = new javax.swing.JLabel();
        cmbGuildKey = new javax.swing.JComboBox();
        butGetData = new javax.swing.JButton();

        panGuildInv.setBackground(new java.awt.Color(200, 255, 200));
        panGuildInv.setLayout(new java.awt.GridBagLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setBorder(new CustomBorder());
        jPanel3.setLayout(new java.awt.GridBagLayout());

        lblFilterTxt.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel3.add(lblFilterTxt, gridBagConstraints);

        cmbFilterItems.setMaximumRowCount(11);
        cmbFilterItems.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFilterItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFilterItemsActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel3.add(cmbFilterItems, gridBagConstraints);

        butExportItems.setText("Export");
        butExportItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butExportItemsActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel3.add(butExportItems, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panGuildInv.add(jPanel3, gridBagConstraints);

        panInvMatCont.setOpaque(false);
        panInvMatCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panGuildInv.add(panInvMatCont, gridBagConstraints);

        panGuildInfo.setBackground(new java.awt.Color(200, 255, 200));
        panGuildInfo.setLayout(new java.awt.GridBagLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setBorder(custBorder);
        jPanel4.setLayout(new java.awt.GridBagLayout());

        tblMembers.setAutoCreateRowSorter(true);
        tblMembers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblMembers);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 5, 5);
        jPanel4.add(jScrollPane2, gridBagConstraints);

        lblMemberTitleTxt.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        jPanel4.add(lblMemberTitleTxt, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panGuildInfo.add(jPanel4, gridBagConstraints);

        panGuildData.setBackground(new java.awt.Color(255, 255, 204));
        panGuildData.setBorder(custBorder);
        panGuildData.setLayout(new java.awt.GridBagLayout());

        lblCivilizationValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblCivilizationValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblCivilizationValue, gridBagConstraints);

        lblCultureValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblCultureValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblCultureValue, gridBagConstraints);

        lblRaceValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblRaceValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblRaceValue, gridBagConstraints);

        lblRace.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblRace, gridBagConstraints);

        lblMoney.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblMoney, gridBagConstraints);

        lblMoneyValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblMoneyValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblMoneyValue, gridBagConstraints);

        lblCulture.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblCulture, gridBagConstraints);

        lblName.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblName, gridBagConstraints);

        lblCivilization.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblCivilization, gridBagConstraints);

        lblShardValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblShardValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblShardValue, gridBagConstraints);

        lblShard.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblShard, gridBagConstraints);

        lblNameValue.setMinimumSize(new java.awt.Dimension(150, 20));
        lblNameValue.setPreferredSize(new java.awt.Dimension(250, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblNameValue, gridBagConstraints);

        jPanel5.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panGuildData.add(jPanel5, gridBagConstraints);

        lblDesc.setText("Description:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(lblDesc, gridBagConstraints);

        txtDescriptionValue.setMinimumSize(new java.awt.Dimension(20, 15));
        txtDescriptionValue.setPreferredSize(new java.awt.Dimension(20, 15));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        panGuildData.add(txtDescriptionValue, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panGuildInfo.add(panGuildData, gridBagConstraints);

        panCrystalCont.setOpaque(false);
        panCrystalCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panGuildInfo.add(panCrystalCont, gridBagConstraints);

        setBackground(new java.awt.Color(200, 255, 200));
        setLayout(new java.awt.BorderLayout());

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        panDekPane.setOpaque(false);
        panDekPane.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panDekPane, gridBagConstraints);

        add(jPanel1, java.awt.BorderLayout.CENTER);

        panKeyData.setBackground(new java.awt.Color(255, 255, 204));
        panKeyData.setOpaque(false);
        panKeyData.setLayout(new java.awt.GridBagLayout());

        jPanel2.setBorder(custBorder);
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new java.awt.GridBagLayout());

        lblKeyTxt.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        jPanel2.add(lblKeyTxt, gridBagConstraints);

        cmbGuildKey.setEditable(true);
        cmbGuildKey.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbGuildKey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbGuildKeyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        jPanel2.add(cmbGuildKey, gridBagConstraints);

        butGetData.setText("null");
        butGetData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butGetDataActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel2.add(butGetData, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 5);
        panKeyData.add(jPanel2, gridBagConstraints);

        add(panKeyData, java.awt.BorderLayout.NORTH);
    }// </editor-fold>//GEN-END:initComponents

private void cmbGuildKeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbGuildKeyActionPerformed
    if (!manualKeyFill)
    {
        String key = getSelectedKey();
        if (key != null)
        {
            if (!prop.containsKey(key))
            {
                prop.put(key, "");
                storeProperties();
                rebuildKeyList();
                cmbGuildKey.setSelectedItem(key);
            }
        }
    }

}//GEN-LAST:event_cmbGuildKeyActionPerformed

private void butGetDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butGetDataActionPerformed
    final String key = getSelectedKey();
    if (key == null || key.length() == 0)
    {
        return;
    }
    if (thread != null && thread.isAlive()) return;
    
    lblNameValue.setText("");
    lblRaceValue.setText("");
    lblShardValue.setText("");
    txtDescriptionValue.setText("");
    lblMoneyValue.setText("");
    lblCultureValue.setText("");
    lblCivilizationValue.setText("");


    tblMembers.setModel(new DefaultTableModel());
    allItems.clear();
    final String txtUrlGuild = "http://atys.ryzom.com/api/guild.php?key=" + key;
    if (getFrame() != null) {
        getFrame().setLoadingState(true);
    }
    butGetData.setEnabled(false);
    Runnable runner = new Runnable() {

        public void run() {

            try
            {
                URL urlGuild = new URL(txtUrlGuild);


                SAXBuilder builder1 = new SAXBuilder();
                Document docGuild = builder1.build(new InputStreamReader(new GZIPInputStream(urlGuild.openStream())));

                Element rootGuild = docGuild.detachRootElement();
                if (rootGuild.getName().equals("error"))
                {
                    String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotConnectKeyError", curLanguage, "Please check your entered guild key. Ryzom API returns error");
                    Main.showErrorDialog(errorMsg1);
                    return;
                }
                String gName = getElementValue(rootGuild.getChild("name"));
                String gRace = getElementValue(rootGuild.getChild("race"));
                String gShard = getElementValue(rootGuild.getChild("shard"));
                String gDescription = getElementValue(rootGuild.getChild("description"));
                String gMoney = getElementValue(rootGuild.getChild("money"));
                String gCult = getElementValue(rootGuild.getChild("cult"));
                String gCiv = getElementValue(rootGuild.getChild("civ"));

                lblNameValue.setText(gName);
                lblRaceValue.setText(gRace);
                lblShardValue.setText(gShard);
                txtDescriptionValue.setText(gDescription);
                prop.put(key, gName);
                storeProperties();
                rebuildKeyList();
                try
                {
                    long mon = Long.parseLong(gMoney);
                    NumberFormatter nf = new NumberFormatter(new DecimalFormat("###,###,###,###,###"));
                    gMoney = nf.valueToString(mon);
                }
                catch (Exception exc)
                {
                    // NOOP
                }

                lblMoneyValue.setText(gMoney);
                lblCultureValue.setText(gCult);
                lblCivilizationValue.setText(gCiv);
                Element members = rootGuild.getChild("members");
                List<Element> ms = members.getChildren("member");
                memberData = new String[ms.size()][2];
                int i = 0;
                for (Element e : ms)
                {
                    memberData[i][0] = getElementValue(e.getChild("name"));
                    memberData[i][1] = getElementValue(e.getChild("grade"));
                    i++;
                }
                DefaultTableModel m = new DefaultTableModel(memberData, header);
                tblMembers.setModel(m);


                Element room = rootGuild.getChild("room");
                if (room != null)
                {
                    ItemUtils.fillList(room, allItems, ItemUtils.ItemPlaces.RoomItems.name());
                }
                crystalViewPanel1.analyseCrystalls(allItems);
                List<Item> matOnlyList = ItemUtils.filterList(allItems, ItemCats.Material);
                matInventoryPanel1.setContent(matOnlyList);
            }
            catch (Exception exc)
            {
                String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotConnectUrl", curLanguage, "Cannot connect to Ryzom API for Guild data.\nPlease check your proxy settings.\nReported reason: ");
                Main.showErrorDialog(errorMsg1 + exc.getLocalizedMessage());
                exc.printStackTrace();
            }
            setContent();
            if (getFrame() != null) {
                getFrame().setLoadingState(false);
            }
            butGetData.setEnabled(true);            
            
        }
    };
    thread = new Thread(runner);
    thread.start();

}//GEN-LAST:event_butGetDataActionPerformed
    /**
     * Helper to return the value as string of a element. in case the element
     * does not exists (null) a empty string is returned.
     * @param e - element to get the value frmo
     * @return the value of the element or ""
     */
    private String getElementValue(Element e)
    {
        String rv = "";
        if (e != null)
        {
            rv = e.getValue();
        }
        return (rv != null) ? rv : "";
    }

private void cmbFilterItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFilterItemsActionPerformed
    setContent();
}//GEN-LAST:event_cmbFilterItemsActionPerformed

private void butExportItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butExportItemsActionPerformed
    String title = TranslationDbHandler.getTranslation(this.getClass().getName()+".jfcExport", curLanguage, "Export current visible Items");
    jfcExport.setDialogTitle(title);
    int rv = jfcExport.showSaveDialog(getFrame());
    if (rv == JFileChooser.APPROVE_OPTION) {
        File f = jfcExport.getSelectedFile();
        try {
            FileWriter fw = new FileWriter(f);
            String content = itemExporter.doExport(curLanguage);
//            System.out.println(content);
            fw.write(content);
            fw.close();
        } catch (IOException exc) {
            exc.printStackTrace();
        }
        
    }
}//GEN-LAST:event_butExportItemsActionPerformed

    /**
     * Sets the content of the Inventory table with the filter applied before
     */
    private void setContent()
    {
        Object o = cmbFilterItems.getSelectedItem();
        if (o instanceof ItemCats)
        {
            List<Item> filteredList = ItemUtils.filterList(allItems, (ItemCats) o);
            inventoryPanel1.setContent(filteredList);
            itemExporter.setItems(filteredList);
        }
    }

    /**
     * Stores the properties into the property file
     */
    private void storeProperties()
    {
        try
        {
            prop.storeToXML(new FileOutputStream(propFile), null);
        }
        catch (Exception ex)
        {
            String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotStoreProp1", curLanguage, "Cannot store key data to ");
            String errorMsg2 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotStoreProp2", curLanguage, "\nReported reason: ");
            Main.showErrorDialog(errorMsg1 + propFile.getAbsolutePath() + errorMsg2 + ex.getLocalizedMessage());
            ex.printStackTrace();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butExportItems;
    private javax.swing.JButton butGetData;
    private javax.swing.JComboBox cmbFilterItems;
    private javax.swing.JComboBox cmbGuildKey;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCivilization;
    private javax.swing.JLabel lblCivilizationValue;
    private javax.swing.JLabel lblCulture;
    private javax.swing.JLabel lblCultureValue;
    private javax.swing.JLabel lblDesc;
    private javax.swing.JLabel lblFilterTxt;
    private javax.swing.JLabel lblKeyTxt;
    private javax.swing.JLabel lblMemberTitleTxt;
    private javax.swing.JLabel lblMoney;
    private javax.swing.JLabel lblMoneyValue;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNameValue;
    private javax.swing.JLabel lblRace;
    private javax.swing.JLabel lblRaceValue;
    private javax.swing.JLabel lblShard;
    private javax.swing.JLabel lblShardValue;
    private javax.swing.JPanel panCrystalCont;
    private javax.swing.JPanel panDekPane;
    private javax.swing.JPanel panGuildData;
    private javax.swing.JPanel panGuildInfo;
    private javax.swing.JPanel panGuildInv;
    private javax.swing.JPanel panInvMatCont;
    private javax.swing.JPanel panKeyData;
    private javax.swing.JTable tblMembers;
    private javax.swing.JLabel txtDescriptionValue;
    // End of variables declaration//GEN-END:variables

    @Override
    public String getDisplayName()
    {
        return TranslationDbHandler.getTranslation(this.getClass().getName() + ".displayName", curLanguage, "Guild");

    }
    

    @Override
    public void setLanguage(Language lan)
    {
        curLanguage = lan;

        tabPane.updateDisplayNames(panGuildInfo, TranslationDbHandler.getTranslation(this.getClass().getName() + ".panGuildInfo", curLanguage, "Guild Data"));
        tabPane.updateDisplayNames(panGuildInv, TranslationDbHandler.getTranslation(this.getClass().getName() + ".panGuildInv", curLanguage, "Guild Inventory"));
        tabPane.updateDisplayNames(matInventoryPanel1, TranslationDbHandler.getTranslation(this.getClass().getName() + ".matInventoryPanel1".toString(), curLanguage, "Guild materials Only"));

        lblKeyTxt.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblKeyTxt", curLanguage, "Enter Guild Key"));
        butGetData.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".butGetData", curLanguage, "Get Data"));
        lblFilterTxt.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblFilterTxt", curLanguage, "Filter"));
        lblMemberTitleTxt.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMemberTitleTxt", curLanguage, "Members"));
        lblCivilization.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblCivilization", curLanguage, "Civilisation:"));
        lblCulture.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblCulture", curLanguage, "Culture:"));
        lblDesc.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblDesc", curLanguage, "Description:"));
        lblMoney.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMoney", curLanguage, "Money:"));
        lblName.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblName", curLanguage, "Name:"));
        lblRace.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblRace", curLanguage, "Race:"));
        lblShard.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblShard", curLanguage, "Shard:"));
        header = new String[]
                {
                    TranslationDbHandler.getTranslation(this.getClass().getName() + ".header.name", curLanguage, "Name"),
                    TranslationDbHandler.getTranslation(this.getClass().getName() + ".header.ranke", curLanguage, "Rank")
                };
        DefaultTableModel m = new DefaultTableModel(memberData, header);
        tblMembers.setModel(m);
        crystalViewPanel1.setLanguage(curLanguage);
        matInventoryPanel1.setLanguage(curLanguage);
        inventoryPanel1.setLanguage(curLanguage);
        butExportItems.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".butExportItems", curLanguage, "Export current items"));
        

    }

    @Override
    public URL getHelpURL()
    {
        URL url = null;
        switch (curLanguage)
        {
            case English:
                url = this.getClass().getResource("help/help_en.html");
                break;
            case German:
                url = this.getClass().getResource("help/help_de.html");
                break;
            case French:
                url = this.getClass().getResource("help/help_fr.html");
                break;
        }
        return url;
    }

    @Override
    public String getPluginId()
    {
        return "Guild Plugin V1.1";
    }

    public String getResource(String key)
    {
        return "";
    }
}
