/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package characterplugin;

import java.awt.Color;
import java.awt.Graphics2D; 
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.util.Enumeration;
import javax.swing.ImageIcon;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import org.jdom.Element;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.SkillDbHandler;
import ryzominfotool.db.TranslationDbHandler;

/**
 * A tree showing the skills of a player
 * @author  bcsniwi
 */
public class SkillTreePanel extends javax.swing.JPanel
{

    private DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(new SkillEntry("s", "0"));
    private DefaultTreeModel model = new DefaultTreeModel(rootNode);
    private DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
    private Element skillTreeRootElem = null;
    private Language curLanguage = Language.English;

    /** Creates new form SkillTreePanel */
    public SkillTreePanel()
    {
        initComponents();
        treeSkills.setModel(model);
        renderer.setLeafIcon(getIcon(0));
        renderer.setOpenIcon(getIcon(1));
        renderer.setClosedIcon(getIcon(2));
        treeSkills.setCellRenderer(renderer);
    }

    @Override
    public void setBackground(Color bg)
    {
        super.setBackground(bg);
        if (jPanel1 != null)
        {
            jPanel1.setBackground(bg);
        }
    }

    /**
     * Returns an Icon for the tree
     * @param mode - 0 for leaf, 1 for open Icon, 2 for closed icon
     * @return the Icon related to the mode
     */
    private ImageIcon getIcon(int mode)
    {
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = (Graphics2D) img.getGraphics();
        g2d.setColor(Color.white);
        g2d.fillRect(0, 0, 16, 16);
        Polygon p = new Polygon();
        p.addPoint(7, 4);
        p.addPoint(11, 8);
        p.addPoint(7, 12);
        p.addPoint(3, 8);
        p.addPoint(7, 4);

        if (mode == 0)
        {
            g2d.setColor(Color.green);
            g2d.fillPolygon(p);
        }
        else if (mode == 1)
        {
            g2d.setColor(Color.blue);
            g2d.fillPolygon(p);
        }
        else
        {
            g2d.setColor(Color.gray);
            g2d.fillPolygon(p);
        }
        g2d.setColor(Color.darkGray);
        g2d.drawPolygon(p);

        ImageIcon ic = new ImageIcon(img);
        return ic;
    }

    /**
     * One Skill entry with name and value of the skill
     */
    private class SkillEntry
    {

        private String name = "";
        private String realName = "";
        private String value = "";

        public SkillEntry(String name, String value)
        {
            this.name = name;
            this.value = value;
            try
            {
                realName = SkillDbHandler.getSkillDescription(name, curLanguage);
            }
            catch (Exception exc)
            {
                exc.printStackTrace();
            }
        }

        @Override
        public String toString()
        {
            if (realName.equals(""))
            {
                return name + ": " + value;
            }
            return realName + ": " + value;
        }
    }

    /**
     * Adds a skill entry to the tree
     * @param entry - skillentry to add
     */
    private void addSkillEntry(SkillEntry entry)
    {
        boolean foundPlace = false;
        if (entry.name.length() == 2)
        {
            rootNode.add(new DefaultMutableTreeNode(entry));
            foundPlace = true;
        }
        else
        {
            Enumeration<DefaultMutableTreeNode> children = rootNode.breadthFirstEnumeration();
            while (children.hasMoreElements() && !foundPlace)
            {
                DefaultMutableTreeNode node = children.nextElement();
                SkillEntry e = (SkillEntry) node.getUserObject();
                if (e.name.length() == entry.name.length() - 1 && entry.name.startsWith(e.name))
                {
                    DefaultMutableTreeNode n = new DefaultMutableTreeNode(entry);
                    node.add(n);
                    foundPlace = true;
                }
            }
        }
    }

    /**
     * Sets the skill data to analyse and display
     * @param elem - the xml element containing the skill entries
     */
    public void setSkillTreeElement(Element elem)
    {
        skillTreeRootElem = elem;
        java.util.List<Element> skills = elem.getChildren();
        rootNode.removeAllChildren();
        for (Element e : skills)
        {
            String name = e.getName();
            String value = e.getValue();
            SkillEntry entry = new SkillEntry(name, value);
            addSkillEntry(entry);
        }
        model.nodeStructureChanged(rootNode);
    }

    /**
     * Sets the language to use
     * @param lan - the language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblTitleSkills.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTitleSkills", curLanguage, "Skills"));
        butCollaps.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".butCollaps", curLanguage, "Collapse all"));
        butExpand.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".butExpand", curLanguage, "Expand all"));
        if (skillTreeRootElem != null)
        {
            setSkillTreeElement(skillTreeRootElem);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        treeSkills = new javax.swing.JTree();
        jPanel1 = new javax.swing.JPanel();
        butExpand = new javax.swing.JButton();
        butCollaps = new javax.swing.JButton();
        lblTitleSkills = new javax.swing.JLabel();

        setBackground(new java.awt.Color(200, 255, 200));
        setOpaque(false);
        setLayout(new java.awt.BorderLayout());

        treeSkills.setRootVisible(false);
        treeSkills.setShowsRootHandles(true);
        jScrollPane1.setViewportView(treeSkills);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        butExpand.setText("null");
        butExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butExpandActionPerformed(evt);
            }
        });
        jPanel1.add(butExpand);

        butCollaps.setText("null");
        butCollaps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butCollapsActionPerformed(evt);
            }
        });
        jPanel1.add(butCollaps);

        add(jPanel1, java.awt.BorderLayout.SOUTH);

        lblTitleSkills.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitleSkills.setText("Skills");
        add(lblTitleSkills, java.awt.BorderLayout.NORTH);
    }// </editor-fold>//GEN-END:initComponents

private void butExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butExpandActionPerformed

    Enumeration<DefaultMutableTreeNode> enums = rootNode.breadthFirstEnumeration();
    while (enums.hasMoreElements())
    {
        DefaultMutableTreeNode node = enums.nextElement();
        TreePath path = new TreePath(node.getPath());
        treeSkills.expandPath(path);
    }
}//GEN-LAST:event_butExpandActionPerformed

private void butCollapsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butCollapsActionPerformed
    model.nodeStructureChanged(rootNode);   
}//GEN-LAST:event_butCollapsActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butCollaps;
    private javax.swing.JButton butExpand;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitleSkills;
    private javax.swing.JTree treeSkills;
    // End of variables declaration//GEN-END:variables
}
