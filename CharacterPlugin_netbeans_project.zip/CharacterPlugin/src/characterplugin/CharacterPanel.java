/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package characterplugin;

import java.beans.PropertyChangeEvent;
import ryzominfotool.Enums.Language;
import ryzominfotool.gui.utils.Item;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
import java.util.zip.GZIPInputStream;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.text.NumberFormatter;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import ryzominfotool.gui.borders.CustomBorder;
import ryzominfotool.gui.*;
import ryzominfotool.Main;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.utils.ItemUtils;
import ryzominfotool.gui.utils.ItemUtils.ItemCats;
import ryzominfotool.gui.utils.ItemUtils.ItemPlaces;
import ryzominfotool.gui.utils.panels.CrystalViewPanel;
import ryzominfotool.gui.utils.panels.DekoratedTabbedPane;
import ryzominfotool.gui.utils.panels.InventoryPanel;
import ryzominfotool.gui.utils.panels.MatInventoryPanel;
import characterplugin.SkillTreePanel;
import java.beans.PropertyChangeListener;
import ryzominfotool.Enums.Server;

/**
 * The CharacterPlugin.
 * it provides:
 * - Available information on the player, like stats, skills
 * - Available items of the player
 * - Available materials
 * @author Niels-Peter de Witt
 */
public class CharacterPanel extends PluggableContent
{

    private List<Item> allItems = new Vector();
    private Vector<Item> bagItems = new Vector<Item>();
    private Vector<Item> pet1Items = new Vector<Item>();
    private Vector<Item> pet2Items = new Vector<Item>();
    private Vector<Item> pet3Items = new Vector<Item>();
    private Vector<Item> pet4Items = new Vector<Item>();
    private Vector<Item> roomItems = new Vector<Item>();
    private Vector<Item> storeItems = new Vector<Item>();
    private Properties prop = new Properties();
    private File propFile = new File("plugins/CharacterPlugin/CharacterPlugin.prop");
    private CustomBorder custBorder = new CustomBorder();
    private DekoratedTabbedPane tabPane = new DekoratedTabbedPane();
    private MatInventoryPanel matInvPanel = new MatInventoryPanel();
    private InventoryPanel invPanel = new InventoryPanel();
    private CrystalViewPanel crystalViewPanel1 = new CrystalViewPanel();
    private SkillTreePanel skillTreePanel1 = new SkillTreePanel();
    private boolean manualKeyFill = false;
    private List<Item> currentList = new Vector();
    private Language curLanguage = Language.English;
    private DefaultListCellRenderer cmbChooseItemsRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof ItemPlaces)
            {
                ItemPlaces ip = (ItemPlaces) value;
                String txt = TranslationDbHandler.getTranslation(ItemPlaces.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName());
                lbl.setText(txt);
            }
            return lbl;
        }
    };
    private DefaultListCellRenderer cmbFilterItemsRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof ItemCats)
            {
                ItemCats ip = (ItemCats) value;
                String txt = TranslationDbHandler.getTranslation(ItemCats.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName());
                lbl.setText(txt);
            }
            return lbl;
        }
    };
    private String currentServer = null;
    private PropertyChangeListener timeListener = new PropertyChangeListener() {

        public void propertyChange(PropertyChangeEvent evt)
        {
            if (currentServer != null) {
                if (evt.getPropertyName().equals("common.servertick."+Server.Leanon.name()) &&
                    currentServer.equalsIgnoreCase(Server.Leanon.name())) 
                {
                    invPanel.setServerTick((String)evt.getNewValue());
                } else
                if (evt.getPropertyName().equals("common.servertick."+Server.Aniro.name()) &&
                    currentServer.equalsIgnoreCase(Server.Aniro.name())) 
                {
                    invPanel.setServerTick((String)evt.getNewValue());
                } else
                if (evt.getPropertyName().equals("common.servertick."+Server.Arispotle.name()) &&
                    currentServer.equalsIgnoreCase(Server.Arispotle.name())) 
                {
                    invPanel.setServerTick((String)evt.getNewValue());
                } 
            }
        }
    };

    /** Creates new form CharacterPanel */
    public CharacterPanel()
    {
        initComponents();
        propFile.getParentFile().mkdirs();
        cmbChooseItems.removeAllItems();
        cmbChooseItems.addItem(ItemPlaces.All);
        cmbFilterItems.removeAllItems();
        for (ItemCats ic : ItemCats.values())
        {
            cmbFilterItems.addItem(ic);
        }
        for (ItemPlaces ip : ItemPlaces.values()) {
            TranslationDbHandler.getTranslation(ItemPlaces.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName());        
        }
        cmbChooseItems.setRenderer(cmbChooseItemsRenderer);
        cmbFilterItems.setRenderer(cmbFilterItemsRenderer);

        try
        {
            prop.loadFromXML(new FileInputStream(propFile));
        }
        catch (Exception ex)
        {
            prop.clear();
            prop.put("FR521366R0REA16F998", "");
        }
        rebuildKeyList();

        tabPane.setButtonBackgroundColor(new Color(200, 255, 200));
        tabPane.addComponent(panCharData, "Character Data");
        tabPane.addComponent(panCharInv, "Inventory");
        tabPane.addComponent(matInvPanel, "Materials only");
        panDekPane.add(tabPane, BorderLayout.CENTER);
        crystalViewPanel1.setOpaque(true);
        crystalViewPanel1.setBorder(new CustomBorder());
        panCrystalCont.add(crystalViewPanel1, BorderLayout.CENTER);
        skillTreePanel1.setBorder(new CustomBorder());
        panSkillTreeCont.setBackground(new Color(200, 255, 200));
        panSkillTreeCont.add(skillTreePanel1, BorderLayout.CENTER);
        panInvMatCont.add(invPanel, BorderLayout.CENTER);

    }

    @Override
    public void setFrame(FrameworkFrame frame)
    {
        super.setFrame(frame);
        for (Server s : Server.values()) {
            frame.registerOnProperty("common.servertick."+s.name(), timeListener);
        }
    }
    
    

    private void rebuildKeyList()
    {
        String oldKey = getSelectedKey();
        String newSelObj = null;
        cmbFullKey.removeAllItems();

        manualKeyFill = true;
        Vector<String> keys = new Vector(prop.stringPropertyNames());
        Collections.sort(keys);
        for (String key : keys)
        {
            String val = prop.getProperty(key);
            String newKey = key;
            if (val != null && val.length() > 0)
            {
                newKey = key + " - " + val;
            }
            cmbFullKey.addItem(newKey);
            if (key.equals(oldKey))
            {
                newSelObj = newKey;
            }
        }

        cmbFullKey.setSelectedItem(newSelObj);
        manualKeyFill = false;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panCharData = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        panCharValues = new javax.swing.JPanel();
        lblConst = new javax.swing.JLabel();
        lblConstValue = new javax.swing.JLabel();
        lblMeta = new javax.swing.JLabel();
        lblMetaValue = new javax.swing.JLabel();
        lblInt = new javax.swing.JLabel();
        lblIntValue = new javax.swing.JLabel();
        lblWisdom = new javax.swing.JLabel();
        lblWisdomValue = new javax.swing.JLabel();
        lblStr = new javax.swing.JLabel();
        lblStrValue = new javax.swing.JLabel();
        lblBalance = new javax.swing.JLabel();
        lblBalanceValue = new javax.swing.JLabel();
        lblWill = new javax.swing.JLabel();
        lblWillValue = new javax.swing.JLabel();
        lblDex = new javax.swing.JLabel();
        lblDexValue = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        panCharInfo = new javax.swing.JPanel();
        lblChar = new javax.swing.JLabel();
        lblCharName = new javax.swing.JLabel();
        lblServer = new javax.swing.JLabel();
        lblServerName = new javax.swing.JLabel();
        lblGuild = new javax.swing.JLabel();
        lblGuildName = new javax.swing.JLabel();
        lblMoney = new javax.swing.JLabel();
        lblMoneyValue = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        panScores = new javax.swing.JPanel();
        lblHP = new javax.swing.JLabel();
        lblHPValue = new javax.swing.JLabel();
        lblMaxHP = new javax.swing.JLabel();
        lblMaxHPValue = new javax.swing.JLabel();
        lblSap = new javax.swing.JLabel();
        lblSapValue = new javax.swing.JLabel();
        lblMaxSap = new javax.swing.JLabel();
        lblMaxSapValue = new javax.swing.JLabel();
        lblStam = new javax.swing.JLabel();
        lblStamValue = new javax.swing.JLabel();
        lblMaxStam = new javax.swing.JLabel();
        lblMaxStamValue = new javax.swing.JLabel();
        lblFoc = new javax.swing.JLabel();
        lblFocValue = new javax.swing.JLabel();
        lblMaxFoc = new javax.swing.JLabel();
        lblMaxFocValue = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        panCrystalCont = new javax.swing.JPanel();
        panSkillTreeCont = new javax.swing.JPanel();
        panCharInv = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        lblFilter = new javax.swing.JLabel();
        cmbFilterItems = new javax.swing.JComboBox();
        lblSelectStorage = new javax.swing.JLabel();
        cmbChooseItems = new javax.swing.JComboBox();
        panInvMatCont = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        panDekPane = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        lblFullKey = new javax.swing.JLabel();
        butLoadData = new javax.swing.JButton();
        cmbFullKey = new javax.swing.JComboBox();

        panCharData.setBackground(new java.awt.Color(200, 255, 200));
        panCharData.setLayout(new java.awt.GridBagLayout());

        jPanel1.setBackground(new java.awt.Color(200, 255, 200));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        panCharValues.setBackground(new java.awt.Color(255, 255, 204));
        panCharValues.setBorder(custBorder);
        panCharValues.setLayout(new java.awt.GridBagLayout());

        lblConst.setText("null");
        lblConst.setMaximumSize(new java.awt.Dimension(100, 14));
        lblConst.setMinimumSize(new java.awt.Dimension(100, 14));
        lblConst.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblConst, gridBagConstraints);

        lblConstValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblConstValue.setText(" ");
        lblConstValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblConstValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblConstValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblConstValue, gridBagConstraints);

        lblMeta.setText("null");
        lblMeta.setMaximumSize(new java.awt.Dimension(100, 14));
        lblMeta.setMinimumSize(new java.awt.Dimension(100, 14));
        lblMeta.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panCharValues.add(lblMeta, gridBagConstraints);

        lblMetaValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMetaValue.setText(" ");
        lblMetaValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblMetaValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblMetaValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblMetaValue, gridBagConstraints);

        lblInt.setText("null");
        lblInt.setMaximumSize(new java.awt.Dimension(100, 14));
        lblInt.setMinimumSize(new java.awt.Dimension(100, 14));
        lblInt.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblInt, gridBagConstraints);

        lblIntValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblIntValue.setText(" ");
        lblIntValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblIntValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblIntValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblIntValue, gridBagConstraints);

        lblWisdom.setText("null");
        lblWisdom.setMaximumSize(new java.awt.Dimension(100, 14));
        lblWisdom.setMinimumSize(new java.awt.Dimension(100, 14));
        lblWisdom.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panCharValues.add(lblWisdom, gridBagConstraints);

        lblWisdomValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblWisdomValue.setText(" ");
        lblWisdomValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblWisdomValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblWisdomValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblWisdomValue, gridBagConstraints);

        lblStr.setText("null");
        lblStr.setMaximumSize(new java.awt.Dimension(100, 14));
        lblStr.setMinimumSize(new java.awt.Dimension(100, 14));
        lblStr.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblStr, gridBagConstraints);

        lblStrValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblStrValue.setText(" ");
        lblStrValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblStrValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblStrValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblStrValue, gridBagConstraints);

        lblBalance.setText("null");
        lblBalance.setMaximumSize(new java.awt.Dimension(100, 14));
        lblBalance.setMinimumSize(new java.awt.Dimension(100, 14));
        lblBalance.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panCharValues.add(lblBalance, gridBagConstraints);

        lblBalanceValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBalanceValue.setText(" ");
        lblBalanceValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblBalanceValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblBalanceValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblBalanceValue, gridBagConstraints);

        lblWill.setText("null");
        lblWill.setMaximumSize(new java.awt.Dimension(100, 14));
        lblWill.setMinimumSize(new java.awt.Dimension(100, 14));
        lblWill.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblWill, gridBagConstraints);

        lblWillValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblWillValue.setText(" ");
        lblWillValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblWillValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblWillValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblWillValue, gridBagConstraints);

        lblDex.setText("null");
        lblDex.setMaximumSize(new java.awt.Dimension(100, 14));
        lblDex.setMinimumSize(new java.awt.Dimension(100, 14));
        lblDex.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panCharValues.add(lblDex, gridBagConstraints);

        lblDexValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDexValue.setText(" ");
        lblDexValue.setMaximumSize(new java.awt.Dimension(50, 14));
        lblDexValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblDexValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharValues.add(lblDexValue, gridBagConstraints);

        jPanel7.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panCharValues.add(jPanel7, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panCharValues, gridBagConstraints);

        panCharInfo.setBackground(new java.awt.Color(255, 255, 204));
        panCharInfo.setBorder(custBorder);
        panCharInfo.setLayout(new java.awt.GridBagLayout());

        lblChar.setText("null");
        lblChar.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblChar, gridBagConstraints);

        lblCharName.setText(" ");
        lblCharName.setPreferredSize(new java.awt.Dimension(200, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblCharName, gridBagConstraints);

        lblServer.setText("null");
        lblServer.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblServer, gridBagConstraints);

        lblServerName.setText(" ");
        lblServerName.setPreferredSize(new java.awt.Dimension(200, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblServerName, gridBagConstraints);

        lblGuild.setText("null");
        lblGuild.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblGuild, gridBagConstraints);

        lblGuildName.setText(" ");
        lblGuildName.setPreferredSize(new java.awt.Dimension(200, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblGuildName, gridBagConstraints);

        lblMoney.setText("null");
        lblMoney.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblMoney, gridBagConstraints);

        lblMoneyValue.setPreferredSize(new java.awt.Dimension(200, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInfo.add(lblMoneyValue, gridBagConstraints);

        jPanel6.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panCharInfo.add(jPanel6, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panCharInfo, gridBagConstraints);

        panScores.setBackground(new java.awt.Color(255, 255, 204));
        panScores.setBorder(custBorder);
        panScores.setLayout(new java.awt.GridBagLayout());

        lblHP.setText("null");
        lblHP.setMaximumSize(new java.awt.Dimension(100, 14));
        lblHP.setMinimumSize(new java.awt.Dimension(100, 14));
        lblHP.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblHP, gridBagConstraints);

        lblHPValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblHPValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblHPValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblHPValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblHPValue, gridBagConstraints);

        lblMaxHP.setText("null");
        lblMaxHP.setMaximumSize(new java.awt.Dimension(100, 14));
        lblMaxHP.setMinimumSize(new java.awt.Dimension(100, 14));
        lblMaxHP.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panScores.add(lblMaxHP, gridBagConstraints);

        lblMaxHPValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMaxHPValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblMaxHPValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblMaxHPValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblMaxHPValue, gridBagConstraints);

        lblSap.setText("null");
        lblSap.setMaximumSize(new java.awt.Dimension(100, 14));
        lblSap.setMinimumSize(new java.awt.Dimension(100, 14));
        lblSap.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblSap, gridBagConstraints);

        lblSapValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblSapValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblSapValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblSapValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblSapValue, gridBagConstraints);

        lblMaxSap.setText("null");
        lblMaxSap.setMaximumSize(new java.awt.Dimension(100, 14));
        lblMaxSap.setMinimumSize(new java.awt.Dimension(100, 14));
        lblMaxSap.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panScores.add(lblMaxSap, gridBagConstraints);

        lblMaxSapValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMaxSapValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblMaxSapValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblMaxSapValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblMaxSapValue, gridBagConstraints);

        lblStam.setText("null");
        lblStam.setMaximumSize(new java.awt.Dimension(100, 14));
        lblStam.setMinimumSize(new java.awt.Dimension(100, 14));
        lblStam.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblStam, gridBagConstraints);

        lblStamValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblStamValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblStamValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblStamValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblStamValue, gridBagConstraints);

        lblMaxStam.setText("null");
        lblMaxStam.setMaximumSize(new java.awt.Dimension(100, 14));
        lblMaxStam.setMinimumSize(new java.awt.Dimension(100, 14));
        lblMaxStam.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panScores.add(lblMaxStam, gridBagConstraints);

        lblMaxStamValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMaxStamValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblMaxStamValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblMaxStamValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblMaxStamValue, gridBagConstraints);

        lblFoc.setText("null");
        lblFoc.setMaximumSize(new java.awt.Dimension(100, 14));
        lblFoc.setMinimumSize(new java.awt.Dimension(100, 14));
        lblFoc.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblFoc, gridBagConstraints);

        lblFocValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblFocValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblFocValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblFocValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblFocValue, gridBagConstraints);

        lblMaxFoc.setText("null");
        lblMaxFoc.setMaximumSize(new java.awt.Dimension(100, 14));
        lblMaxFoc.setMinimumSize(new java.awt.Dimension(100, 14));
        lblMaxFoc.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 35, 2, 2);
        panScores.add(lblMaxFoc, gridBagConstraints);

        lblMaxFocValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMaxFocValue.setMaximumSize(new java.awt.Dimension(40, 14));
        lblMaxFocValue.setMinimumSize(new java.awt.Dimension(40, 14));
        lblMaxFocValue.setPreferredSize(new java.awt.Dimension(40, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panScores.add(lblMaxFocValue, gridBagConstraints);

        jPanel8.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panScores.add(jPanel8, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panScores, gridBagConstraints);

        panCrystalCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panCrystalCont, gridBagConstraints);

        panSkillTreeCont.setOpaque(false);
        panSkillTreeCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panSkillTreeCont, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharData.add(jPanel1, gridBagConstraints);

        panCharInv.setBackground(new java.awt.Color(200, 255, 200));
        panCharInv.setLayout(new java.awt.GridBagLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 204));
        jPanel5.setBorder(custBorder);
        jPanel5.setLayout(new java.awt.GridBagLayout());

        lblFilter.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel5.add(lblFilter, gridBagConstraints);

        cmbFilterItems.setMaximumRowCount(11);
        cmbFilterItems.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFilterItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFilterItemsActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel5.add(cmbFilterItems, gridBagConstraints);

        lblSelectStorage.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel5.add(lblSelectStorage, gridBagConstraints);

        cmbChooseItems.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All Items", "Wearing", "Bag", "Pet 1", "Pet 2", "Pet 3", "Pet 4", "Room", "Store" }));
        cmbChooseItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbChooseItemsActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel5.add(cmbChooseItems, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInv.add(jPanel5, gridBagConstraints);

        panInvMatCont.setOpaque(false);
        panInvMatCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panCharInv.add(panInvMatCont, gridBagConstraints);

        setBackground(new java.awt.Color(200, 255, 200));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(200, 255, 200));
        jPanel2.setLayout(new java.awt.GridBagLayout());

        panDekPane.setOpaque(false);
        panDekPane.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel2.add(panDekPane, gridBagConstraints);

        add(jPanel2, java.awt.BorderLayout.CENTER);

        jPanel3.setBackground(new java.awt.Color(200, 255, 200));
        jPanel3.setLayout(new java.awt.GridBagLayout());

        jPanel9.setBackground(new java.awt.Color(200, 255, 200));
        jPanel9.setBorder(custBorder);
        jPanel9.setLayout(new java.awt.GridBagLayout());

        lblFullKey.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        jPanel9.add(lblFullKey, gridBagConstraints);

        butLoadData.setText("null");
        butLoadData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butLoadDataActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        jPanel9.add(butLoadData, gridBagConstraints);

        cmbFullKey.setEditable(true);
        cmbFullKey.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFullKey.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbFullKeyMouseClicked(evt);
            }
        });
        cmbFullKey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFullKeyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        jPanel9.add(cmbFullKey, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 5);
        jPanel3.add(jPanel9, gridBagConstraints);

        add(jPanel3, java.awt.BorderLayout.NORTH);
    }// </editor-fold>//GEN-END:initComponents

    private String getSelectedKey()
    {
        String key = (String) cmbFullKey.getSelectedItem();
        if (key != null)
        {
            if (key.contains(" - "))
            {
                int index = key.indexOf(" - ");
                key = key.substring(0, index);
            }
        }
        return key;
    }

private void butLoadDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butLoadDataActionPerformed
    String key = getSelectedKey();

    String txtUrlItems = "http://atys.ryzom.com/api/character.php?key=" + key + "&part=items";
    String txtUrlChar = "http://atys.ryzom.com/api/character.php?key=" + key;
    lblCharName.setText("");
    lblServerName.setText("");
    lblGuildName.setText("");
    lblBalanceValue.setText("");
    lblConstValue.setText("");
    lblDexValue.setText("");
    lblIntValue.setText("");
    lblMetaValue.setText("");
    lblStrValue.setText("");
    lblWillValue.setText("");
    lblWisdomValue.setText("");
    lblFocValue.setText("");
    lblSapValue.setText("");
    lblHPValue.setText("");
    lblStamValue.setText("");
    lblMaxFocValue.setText("");
    lblMaxHPValue.setText("");
    lblMaxSapValue.setText("");
    lblMaxStamValue.setText("");
    lblMoneyValue.setText("");

    allItems.clear();
    bagItems.clear();
    pet1Items.clear();
    pet2Items.clear();
    pet3Items.clear();
    pet4Items.clear();
    roomItems.clear();
    storeItems.clear();
    cmbChooseItems.removeAllItems();
    cmbChooseItems.addItem(ItemPlaces.All);
    matInvPanel.setContent(new Vector<Item>());
    currentServer = null;
    try
    {
        URL urlItems = new URL(txtUrlItems);
        URL urlChar = new URL(txtUrlChar);

        SAXBuilder builder1 = new SAXBuilder();
        SAXBuilder builder2 = new SAXBuilder();
        Document docItems = builder1.build(new InputStreamReader(new GZIPInputStream(urlItems.openStream())));
        Document docChar = builder2.build(new InputStreamReader(new GZIPInputStream(urlChar.openStream())));

        Element rootChar = docChar.detachRootElement();
        if (rootChar.getName().equals("error"))
        {
            String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotConnectKeyError", curLanguage, "Please check your entered playerKey key. Ryzom API returns error");
            Main.showErrorDialog(errorMsg1);
        }
        else
        {

            String name = rootChar.getChild("name").getValue();
            String server = rootChar.getChild("shard").getValue();
            currentServer = server;
            Element guild = rootChar.getChild("guild");
            if (guild != null)
            {
                String guildName = guild.getChild("name").getValue();
                lblGuildName.setText(guildName);
            }
            lblCharName.setText(name);
            prop.put(key, name);
            storeProperties();
            rebuildKeyList();
            lblServerName.setText(server);
            int moneyValue = Integer.parseInt(rootChar.getChildText("money"));
            NumberFormatter nf = new NumberFormatter(new DecimalFormat("###,###,###"));
            lblMoneyValue.setText(nf.valueToString(moneyValue));
            skillTreePanel1.setSkillTreeElement(rootChar.getChild("skills"));
            Element phyChars = rootChar.getChild("phys_characs");
            if (phyChars != null)
            {
                String con = phyChars.getChild("constitution").getValue();
                String meta = phyChars.getChild("metabolism").getValue();
                String inte = phyChars.getChild("intelligence").getValue();
                String wis = phyChars.getChild("wisdom").getValue();
                String str = phyChars.getChild("strength").getValue();
                String bal = phyChars.getChild("wellbalanced").getValue();
                String dex = phyChars.getChild("dexterity").getValue();
                String wil = phyChars.getChild("will").getValue();

                lblBalanceValue.setText(bal);
                lblConstValue.setText(con);
                lblDexValue.setText(dex);
                lblIntValue.setText(inte);
                lblMetaValue.setText(meta);
                lblStrValue.setText(str);
                lblWillValue.setText(wil);
                lblWisdomValue.setText(wis);
            }
            Element physScores = rootChar.getChild("phys_scores");
            if (physScores != null)
            {
                Element hp = physScores.getChild("hitpoints");
                Element sta = physScores.getChild("stamina");
                Element sap = physScores.getChild("sap");
                Element foc = physScores.getChild("focus");
                lblFocValue.setText(foc.getValue());
                lblSapValue.setText(sap.getValue());
                lblHPValue.setText(hp.getValue());
                lblStamValue.setText(sta.getValue());
                lblMaxFocValue.setText(foc.getAttributeValue("max"));
                lblMaxHPValue.setText(hp.getAttributeValue("max"));
                lblMaxSapValue.setText(sap.getAttributeValue("max"));
                lblMaxStamValue.setText(sta.getAttributeValue("max"));
            }

        }
        Element rootItems = docItems.detachRootElement();
        if (rootItems.getName().equals("error"))
        {
            String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotConnectKeyError", curLanguage, "Please check your entered player key. Ryzom API returns error");
            Main.showErrorDialog(errorMsg1);
        }
        else
        {
            Element inv = rootItems.getChild("inventories");
            Element bag = inv.getChild("bag");
            Element pet1 = inv.getChild("pet_animal1");
            Element pet2 = inv.getChild("pet_animal2");
            Element pet3 = inv.getChild("pet_animal3");
            Element pet4 = inv.getChild("pet_animal4");
            Element room = rootItems.getChild("room");
            Element store = rootItems.getChild("item_in_store");
            if (bag != null && bag.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.BagItems);
                
            }
            if (pet1 != null && pet1.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.Pet1Items);
                
            }
            if (pet2 != null && pet2.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.Pet2Items);
                
            }
            if (pet3 != null && pet3.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.Pet3Items);
                
            }
            if (pet4 != null && pet4.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.Pet4Items);
                
            }
            if (room != null && room.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.RoomItems);
                
            }
            if (store != null && store.getChildren().size() > 0)
            {
                cmbChooseItems.addItem(ItemPlaces.StoreItems);
                
            }

            ItemUtils.fillList(bag, bagItems, "Bag");
            ItemUtils.fillList(pet1, pet1Items, "Pet_1");
            ItemUtils.fillList(pet2, pet2Items, "Pet_2");
            ItemUtils.fillList(pet3, pet3Items, "Pet_3");
            ItemUtils.fillList(pet4, pet4Items, "Pet_4");
            ItemUtils.fillList(room, roomItems, "Room");
            ItemUtils.fillList(store, storeItems, "Store");

            allItems.addAll(bagItems);
            allItems.addAll(pet1Items);
            allItems.addAll(pet2Items);
            allItems.addAll(pet3Items);
            allItems.addAll(pet4Items);
            allItems.addAll(roomItems);
            allItems.addAll(storeItems);
        }
        crystalViewPanel1.analyseCrystalls(allItems);
        List<Item> matOnlyList = ItemUtils.filterList(allItems, ItemCats.Material);
        matInvPanel.setContent(matOnlyList);
    }
    catch (Exception ex)
    {
        String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotConnectUrl", curLanguage, "Cannot connect to Ryzom API for Player and/or Item data.\nPlease check your proxy settings.\nReported reason: ");
        Main.showErrorDialog(errorMsg1 + ex.getLocalizedMessage());
        getFrame().addLog(ex);
    }
    cmbChooseItemsActionPerformed(null);
}//GEN-LAST:event_butLoadDataActionPerformed
    /**
     * Stores the properties into the property file
     */
    private void storeProperties()
    {
        try
        {
            prop.storeToXML(new FileOutputStream(propFile), null);
        }
        catch (Exception ex)
        {
            String errorMsg1 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotStoreProp1", curLanguage, "Cannot store key data to ");
            String errorMsg2 = TranslationDbHandler.getTranslation(this.getClass().getName() + ".cannotStoreProp2", curLanguage, "\nReported reason: ");
            Main.showErrorDialog(errorMsg1 + propFile.getAbsolutePath() + errorMsg2 + ex.getLocalizedMessage());
            getFrame().addLog(ex);
        }
    }

private void cmbChooseItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbChooseItemsActionPerformed
    Object o = cmbChooseItems.getSelectedItem();
    if (o instanceof ItemPlaces)
    {
        ItemPlaces ip = (ItemPlaces) o;
        switch (ip)
        {
            case All:
                currentList = allItems;
                break;
            case BagItems:
                currentList = (bagItems);
                break;
            case Pet1Items:
                currentList = (pet1Items);
                break;
            case Pet2Items:
                currentList = (pet2Items);
                break;
            case Pet3Items:
                currentList = (pet3Items);
                break;
            case Pet4Items:
                currentList = (pet4Items);
                break;
            case RoomItems:
                currentList = (roomItems);
                break;
            case StoreItems:
                currentList = (storeItems);
                break;
        }
        setContent();
    }
}//GEN-LAST:event_cmbChooseItemsActionPerformed

private void cmbFilterItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFilterItemsActionPerformed
    setContent();
}//GEN-LAST:event_cmbFilterItemsActionPerformed

private void cmbFullKeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFullKeyActionPerformed
    if (!manualKeyFill)
    {
        String key = getSelectedKey();
        if (key != null)
        {
            if (!prop.containsKey(key))
            {
                prop.put(key, "");
                storeProperties();
                rebuildKeyList();
                cmbFullKey.setSelectedItem(key);
            }
        }
    }
}//GEN-LAST:event_cmbFullKeyActionPerformed

private void cmbFullKeyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbFullKeyMouseClicked
}//GEN-LAST:event_cmbFullKeyMouseClicked

    private void setContent()
    {
        Object o = cmbFilterItems.getSelectedItem();
        if (o instanceof ItemCats)
        {
            List<Item> filteredList = ItemUtils.filterList(currentList, (ItemCats) o);
            invPanel.setContent(filteredList);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butLoadData;
    private javax.swing.JComboBox cmbChooseItems;
    private javax.swing.JComboBox cmbFilterItems;
    private javax.swing.JComboBox cmbFullKey;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblBalance;
    private javax.swing.JLabel lblBalanceValue;
    private javax.swing.JLabel lblChar;
    private javax.swing.JLabel lblCharName;
    private javax.swing.JLabel lblConst;
    private javax.swing.JLabel lblConstValue;
    private javax.swing.JLabel lblDex;
    private javax.swing.JLabel lblDexValue;
    private javax.swing.JLabel lblFilter;
    private javax.swing.JLabel lblFoc;
    private javax.swing.JLabel lblFocValue;
    private javax.swing.JLabel lblFullKey;
    private javax.swing.JLabel lblGuild;
    private javax.swing.JLabel lblGuildName;
    private javax.swing.JLabel lblHP;
    private javax.swing.JLabel lblHPValue;
    private javax.swing.JLabel lblInt;
    private javax.swing.JLabel lblIntValue;
    private javax.swing.JLabel lblMaxFoc;
    private javax.swing.JLabel lblMaxFocValue;
    private javax.swing.JLabel lblMaxHP;
    private javax.swing.JLabel lblMaxHPValue;
    private javax.swing.JLabel lblMaxSap;
    private javax.swing.JLabel lblMaxSapValue;
    private javax.swing.JLabel lblMaxStam;
    private javax.swing.JLabel lblMaxStamValue;
    private javax.swing.JLabel lblMeta;
    private javax.swing.JLabel lblMetaValue;
    private javax.swing.JLabel lblMoney;
    private javax.swing.JLabel lblMoneyValue;
    private javax.swing.JLabel lblSap;
    private javax.swing.JLabel lblSapValue;
    private javax.swing.JLabel lblSelectStorage;
    private javax.swing.JLabel lblServer;
    private javax.swing.JLabel lblServerName;
    private javax.swing.JLabel lblStam;
    private javax.swing.JLabel lblStamValue;
    private javax.swing.JLabel lblStr;
    private javax.swing.JLabel lblStrValue;
    private javax.swing.JLabel lblWill;
    private javax.swing.JLabel lblWillValue;
    private javax.swing.JLabel lblWisdom;
    private javax.swing.JLabel lblWisdomValue;
    private javax.swing.JPanel panCharData;
    private javax.swing.JPanel panCharInfo;
    private javax.swing.JPanel panCharInv;
    private javax.swing.JPanel panCharValues;
    private javax.swing.JPanel panCrystalCont;
    private javax.swing.JPanel panDekPane;
    private javax.swing.JPanel panInvMatCont;
    private javax.swing.JPanel panScores;
    private javax.swing.JPanel panSkillTreeCont;
    // End of variables declaration//GEN-END:variables

    @Override
    public String getDisplayName()
    {
        return TranslationDbHandler.getTranslation(this.getClass().getName(), curLanguage, "Character");
    }

    @Override
    public String getPluginId()
    {
        return "Character Plugin V0.1";
    }
    

    @Override
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        tabPane.updateDisplayNames(panCharData, TranslationDbHandler.getTranslation(this.getClass().getName() + ".panCharData", curLanguage, "Character Data"));
        tabPane.updateDisplayNames(panCharInv, TranslationDbHandler.getTranslation(this.getClass().getName() + ".panCharInv", curLanguage, "Inventory"));
        tabPane.updateDisplayNames(matInvPanel, TranslationDbHandler.getTranslation(this.getClass().getName() + ".matInvPanel", curLanguage, "Materials only"));


        lblConst.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblConst", curLanguage, "Constitution:"));
        lblBalance.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblBalance", curLanguage, "Balance:"));
        lblChar.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblChar", curLanguage, "Name:"));
        lblDex.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblDex", curLanguage, "Dexterity:"));
        lblFoc.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblFoc", curLanguage, "Focus:"));
        lblGuild.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblGuild", curLanguage, "Guild:"));
        lblHP.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblHP", curLanguage, "HP:"));
        lblInt.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblInt", curLanguage, "Intelligence:"));
        lblMaxFoc.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMaxFoc", curLanguage, "Max Foc.:"));
        lblMaxHP.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMaxHP", curLanguage, "Max HP:"));
        lblMaxSap.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMaxSap", curLanguage, "Max Sap:"));
        lblMaxStam.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMaxStam", curLanguage, "Max Stam.:"));
        lblMeta.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMeta", curLanguage, "Metabolism:"));
        lblMoney.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMoney", curLanguage, "Money:"));
        lblSap.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblSap", curLanguage, "Sap:"));
        lblServer.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblServer", curLanguage, "Server:"));
        lblStam.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblStam", curLanguage, "Stamina:"));
        lblStr.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblStr", curLanguage, "Strength:"));
        lblWill.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblWill", curLanguage, "Will:"));
        lblWisdom.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblWisdom", curLanguage, "Wisdom:"));
        lblFilter.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblFilter", curLanguage, "Filter"));
        lblSelectStorage.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblSelectStorage", curLanguage, "Select Storage"));
        lblFullKey.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblFullKey", curLanguage, "Enter Full Key"));
        butLoadData.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".butLoadData", curLanguage, "Get Data"));
        matInvPanel.setLanguage(curLanguage);
        crystalViewPanel1.setLanguage(curLanguage);
        skillTreePanel1.setLanguage(curLanguage);
        invPanel.setLanguage(curLanguage);
    }

    @Override
    public URL getHelpURL()
    {
        URL url = null;
        switch (curLanguage)
        {
            case English:
                url = this.getClass().getResource("help/help_en.html");
                break;
            case German:
                url = this.getClass().getResource("help/help_de.html");
                break;
            case French:
                url = this.getClass().getResource("help/help_fr.html");
                break;
        }
        return url;
    }
}


