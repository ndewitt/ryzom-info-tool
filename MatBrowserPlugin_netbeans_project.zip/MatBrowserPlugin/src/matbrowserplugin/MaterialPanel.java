/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package matbrowserplugin;

import ryzominfotool.gui.*;
import java.awt.BorderLayout;
import java.awt.Component;
import java.net.URL;
import java.sql.SQLException;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import ryzominfotool.gui.utils.*;
import ryzominfotool.utils.*;
import ryzominfotool.*;
import ryzominfotool.db.*;
import ryzominfotool.gui.utils.panels.MatFilterPanel;
import ryzominfotool.gui.utils.panels.StatusPanel;

/**
 * MatBrowser Plugin:
 * Provides Mats and their stats.
 * @author  Niels-Peter de Witt
 */
public class MaterialPanel extends PluggableContent {

    private StatusPanel materialStatusPanel = new StatusPanel();
    private boolean fillingMaterials = false;
    private MatTableModel myMatTableModel = new MatTableModel();
    private MatFilterPanel matFilterPanel = new MatFilterPanel();
    private MatFilter matFilter = null;
    private MatTableCellRenderer matRenderer = new MatTableCellRenderer();
    private MatTableHeaderRenderer matHeaderRenderer = new MatTableHeaderRenderer();
    private Enums.Language curLanguage = Enums.Language.English;
    private FilterChangedListener matFilterChangedListener = new FilterChangedListener() {

        @Override
        public void filterChanged(MatFilter filter) {
            matFilter = filter;
            fillMaterials();
        }
    };
    private DefaultListCellRenderer cmbCatListCellRenderer = new DefaultListCellRenderer() {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Enums.Categorie) {
                Enums.Categorie cat = (Enums.Categorie) value;
                String txt = TranslationDbHandler.getTranslation(Enums.Categorie.class.getName() + "." + cat.name(), curLanguage, cat.getCatName());
                lbl.setText(txt);
            }
            return lbl;
        }
    };

    /** Creates new form MaterialPanel */
    public MaterialPanel() {
        initComponents();
        tblMaterials.setModel(myMatTableModel);
        tblMaterials.getTableHeader().setDefaultRenderer(matHeaderRenderer);
        panMatDetails.add(materialStatusPanel, BorderLayout.CENTER);
        panFilterArea.add(matFilterPanel, BorderLayout.CENTER);
        matFilterPanel.addFilterChangedListener(matFilterChangedListener);
        tblMaterials.setDefaultRenderer(Object.class, matRenderer);

        cmbCategorie.removeAllItems();
        for (Enums.Categorie cat : Enums.Categorie.values()) {
            cmbCategorie.addItem(cat);
        }
        cmbCategorie.setRenderer(cmbCatListCellRenderer);
        ListSelectionListener matTableSelListener = new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                int index = tblMaterials.getSelectedRow();
                if (index >= 0) {
                    Object o = tblMaterials.getModel().getValueAt(index, 0);
                    Material m = (Material) o;
                    if (fillingMaterials) {
                        materialStatusPanel.setMaterial(null);
                    } else {
                        materialStatusPanel.setMaterial(m);
                    }
                } else {
                    materialStatusPanel.setMaterial(null);
                }
            }
        };
        tblMaterials.getSelectionModel().addListSelectionListener(matTableSelListener);
        tblMaterials.getTableHeader().setReorderingAllowed(false);
        tblMaterials.getColumnModel().getColumn(0).setMinWidth(250);
        tblMaterials.getColumnModel().getColumn(1).setMinWidth(80);
        tblMaterials.getColumnModel().getColumn(2).setMinWidth(80);
        tblMaterials.getColumnModel().getColumn(3).setMinWidth(80);
        tblMaterials.getColumnModel().getColumn(4).setMinWidth(80);
        try {
            MaterialDbHandler.loadMats();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        fillMaterials();
    }

    /**
     * Applys the matfilter on all available mats
     * and displays them
     */
    public void fillMaterials() {

        fillingMaterials = true;
        myMatTableModel.clearList();
        MyMap<Enums.Categorie, java.util.List<Material>> map = MaterialDbHandler.getLoadedMats();
        Enums.Categorie categorie = (Enums.Categorie) cmbCategorie.getSelectedItem();
        if (categorie != null) {
            java.util.List<Material> lst = map.get(categorie);
            java.util.List<Material> tmpList = MatFilter.applyFilter(matFilter, lst);
            myMatTableModel.setList(tmpList);
        }
        fillingMaterials = false;
        tblMaterials.getSelectionModel().setSelectionInterval(-1, -1);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panMaterials = new javax.swing.JPanel();
        panMatListing = new javax.swing.JPanel();
        panFilterArea = new javax.swing.JPanel();
        panMatListArea = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMaterials = new javax.swing.JTable();
        panMatDetails = new javax.swing.JPanel();
        panCategorieArea = new javax.swing.JPanel();
        lblCategorie = new javax.swing.JLabel();
        cmbCategorie = new javax.swing.JComboBox();

        setBackground(new java.awt.Color(200, 255, 200));
        setLayout(new java.awt.GridBagLayout());

        panMaterials.setBackground(new java.awt.Color(200, 255, 200));
        panMaterials.setLayout(new java.awt.GridBagLayout());

        panMatListing.setBackground(new java.awt.Color(255, 255, 204));
        panMatListing.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panMatListing.setLayout(new java.awt.GridBagLayout());

        panFilterArea.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        panMatListing.add(panFilterArea, gridBagConstraints);

        panMatListArea.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 204));
        jScrollPane1.setOpaque(false);

        tblMaterials.setRowHeight(42);
        jScrollPane1.setViewportView(tblMaterials);

        panMatListArea.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        panMatListing.add(panMatListArea, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panMaterials.add(panMatListing, gridBagConstraints);

        panMatDetails.setBackground(new java.awt.Color(255, 255, 204));
        panMatDetails.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panMatDetails.setMinimumSize(new java.awt.Dimension(260, 250));
        panMatDetails.setPreferredSize(new java.awt.Dimension(260, 250));
        panMatDetails.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        panMaterials.add(panMatDetails, gridBagConstraints);

        panCategorieArea.setBackground(new java.awt.Color(255, 255, 204));
        panCategorieArea.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panCategorieArea.setLayout(new java.awt.GridBagLayout());

        lblCategorie.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panCategorieArea.add(lblCategorie, gridBagConstraints);

        cmbCategorie.setBackground(new java.awt.Color(255, 255, 204));
        cmbCategorie.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCategorie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategorieActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 5, 5);
        panCategorieArea.add(cmbCategorie, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 2, 2);
        panMaterials.add(panCategorieArea, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 2, 2);
        add(panMaterials, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void cmbCategorieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategorieActionPerformed
    fillMaterials();
}//GEN-LAST:event_cmbCategorieActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cmbCategorie;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCategorie;
    private javax.swing.JPanel panCategorieArea;
    private javax.swing.JPanel panFilterArea;
    private javax.swing.JPanel panMatDetails;
    private javax.swing.JPanel panMatListArea;
    private javax.swing.JPanel panMatListing;
    private javax.swing.JPanel panMaterials;
    private javax.swing.JTable tblMaterials;
    // End of variables declaration//GEN-END:variables
    @Override
    public String getDisplayName() {
        return TranslationDbHandler.getTranslation(this.getClass().getName() + ".displayName", curLanguage, "Mat-Browser");
    }

    @Override
    public void setLanguage(Enums.Language lan) {
        curLanguage = lan;
        lblCategorie.setText(TranslationDbHandler.getTranslation(this.getClass().getName(), curLanguage, "Choose Categorie"));
        materialStatusPanel.setLanguage(curLanguage);
        matFilterPanel.setLanguage(curLanguage);
        matRenderer.setLanguage(curLanguage);
        matHeaderRenderer.setLanguage(curLanguage);
    }

    @Override
    public URL getHelpURL() {
        URL url = null;
        switch (curLanguage) {
            case English:
                url = this.getClass().getResource("help/help_en.html");
                break;
            case German:
                url = this.getClass().getResource("help/help_de.html");
                break;
            case French:
                url = this.getClass().getResource("help/help_fr.html");
                break;
        }
        return url;
    }

    @Override
    public String getPluginId() {
        return "MatBrowser Plugin V0.1";
    }
}
