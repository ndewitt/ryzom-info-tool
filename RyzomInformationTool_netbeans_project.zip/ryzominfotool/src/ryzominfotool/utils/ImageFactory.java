/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.swing.*;
import ryzominfotool.Enums.*;
import ryzominfotool.Main;
import ryzominfotool.db.ImageDbHandler;

/**
 * The ImageFactory retrieves Inventory Items from the database and
 * renders additional information on the immage, if needed
 * @author Niels-Peter de Witt
 */
public class ImageFactory
{

    private static Font myFont = null;

    /**
     * Loads an external TT Font, if not already done.
     */
    private static void setFont()
    {
        if (myFont == null)
        {
            try
            {
                InputStream is = Main.class.getResourceAsStream("resource/Tahoma.ttf");
                myFont = Font.createFont(Font.TRUETYPE_FONT, is);
                myFont = myFont.deriveFont(Font.PLAIN, 9);
            }
            catch (Exception exc)
            {
                exc.printStackTrace();
            }
        }
    }

    /**
     * Returns the Icon with the itemId
     * If the itemId is not available an gray Icon will be returned.
     * @param itemId - the itemId of the icon to fetch
     * @return the icon related to the itemId
     */
    public static Icon getMatIcon(String itemId)
    {
        return new ImageIcon(getMatImage(itemId, ""));
    }

    /**
     * Returns the Icon with the itemId
     * If the itemId is not available an gray Icon will be returned.
     * @param itemId - the itemId of the icon to fetch
     * @param level - the qualitly level to draw on the image
     * @param amount - the stack size to draw on the image
     * @return the icon related to the itemId
     */    
    public static Icon getMatIcon(String itemId, int level, int amount)
    {
        ImageIcon rv = null;
        BufferedImage img = getMatImage(itemId, "");
        drawQualityLevel(img, level);
        drawAmount(img, amount);
        rv = new ImageIcon(img);
        return rv;
    }

    /**
     * Returns the Icon with the itemId
     * If the itemId is not available an gray Icon will be returned.
     * @param itemId - the itemId of the icon to fetch
     * @param level - the qualitly level to draw on the image
     * @param amount - the stack size to draw on the image
     * @param color - the color of the item to fetch
     * @return the icon related to the itemId
     */    
    public static Icon getMatIcon(String itemId, int level, int amount, String color)
    {
        ImageIcon rv = null;
        BufferedImage img = getMatImage(itemId, color);
        drawQualityLevel(img, level);
        drawAmount(img, amount);
        rv = new ImageIcon(img);
        return rv;
    }

    /**
     * Returns the Icon with the itemId
     * If the itemId is not available an gray Icon will be returned.
     * @param itemId - the itemId of the icon to fetch
     * @param level - the qualitly level to draw on the image
     * @return the icon related to the itemId
     */    
    public static Icon getMatIconLevel(String itemId, int level)
    {
        ImageIcon rv = null;
        BufferedImage img = getMatImage(itemId, "");
        drawQualityLevel(img, level);
        return rv;
    }

    /**
     * Returns the Icon with the itemId
     * If the itemId is not available an gray Icon will be returned.
     * @param itemId - the itemId of the icon to fetch
     * @param amount - the stack size to draw on the image
     * @return the icon related to the itemId
     */    
    public static Icon getMatIconAmount(String itemId, int amount)
    {
        ImageIcon rv = null;
        BufferedImage img = getMatImage(itemId, "");
        drawAmount(img, amount);
        return rv;
    }

    /**
     * Returns the image related to the itemId with the passed colorCode
     * @param itemId - the itemId of the Image to fetch
     * @param colorCode - the color code of the Image to fetch
     * @return a image for the itemId and colorCode
     */
    private static BufferedImage getMatImage(String itemId, String colorCode)
    {
        BufferedImage rv = null;
        try
        {
            rv = ImageDbHandler.getItemImage(itemId, colorCode);
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
        }
        if (rv == null)
        {
            BufferedImage img = new BufferedImage(40, 40, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = img.createGraphics();
            g2d.setColor(Color.lightGray);
            g2d.fillRect(0, 0, 40, 40);
            g2d.dispose();
            rv = img;
        }
        return rv;
    }

    /**
     * Draws the quality level into the passed image
     * @param img - the image to draw into
     * @param level - the quality level to draw
     */
    private static void drawQualityLevel(BufferedImage img, int level)
    {
        if (level < 0 || img == null)
        {
            return;
        }
        Graphics2D g2d = img.createGraphics();
        setFont();
        g2d.setFont(myFont);
        String l = level + "";
        if (level < 100 && level > 9)
        {
            l = " " + level;
        }
        else if (level < 10)
        {
            l = "  " + level;
        }
        g2d.setColor(Color.black);
        g2d.drawString(l, 26, 39);
        g2d.setColor(Color.white);
        g2d.drawString(l, 25, 38);
    }

    /**
     * Draws the stack size into the passed image
     * @param img - the image to draw into
     * @param amount - the stack size to draw
     */
    private static void drawAmount(BufferedImage img, int amount)
    {
        if (amount < 0 || img == null)
        {
            return;
        }
        Graphics2D g2d = img.createGraphics();
        setFont();
        g2d.setFont(myFont);
        g2d.setColor(Color.black);
        g2d.drawString("x" + amount, 4, 39);
        g2d.setColor(Color.white);
        g2d.drawString("x" + amount, 3, 38);
    }
}
