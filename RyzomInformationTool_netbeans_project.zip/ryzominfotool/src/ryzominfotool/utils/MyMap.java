/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

/**
 * MyMap is a Map implementation to store items in the order, they are put into.
 * The same order can be retrived.
 * @author Niels-Peter de Witt
 * @param <K> - KeyClass
 * @param <V> - ValueClass
 */
public class MyMap<K, V> implements Map
{

    private Vector<KeyContainer<K, V>> keys = new Vector<KeyContainer<K, V>>();

    @Override
    public int size()
    {
        return keys.size();
    }

    @Override
    public boolean isEmpty()
    {
        return (keys.size() == 0);
    }

    @Override
    public boolean containsKey(Object key)
    {
        boolean rv = false;
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext() && !rv;)
        {
            KeyContainer entry = it.next();
            if (entry.getKey().equals(key))
            {
                rv = true;
            }
        }
        return rv;
    }

    @Override
    public boolean containsValue(Object value)
    {
        boolean rv = false;
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext() && !rv;)
        {
            KeyContainer entry = it.next();
            if (entry.getValue().equals(value))
            {
                rv = true;
            }
        }
        return rv;
    }

    @Override
    public V get(Object key)
    {
        V rv = null;
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext() && rv == null;)
        {
            KeyContainer entry = it.next();
            if (entry.getKey().equals(key))
            {
                rv = (V) entry.getValue();
            }
        }
        return rv;
    }

    @Override
    public V put(Object key, Object value)
    {
        V rv = null;
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext() && rv == null;)
        {
            KeyContainer entry = it.next();
            if (entry.getKey().equals(key))
            {
                rv = (V) entry.getValue();
                entry.setValue(value);
            }
        }
        if (rv == null)
        {
            keys.add(new KeyContainer(key, value));
        }
        return rv;
    }

    @Override
    public V remove(Object key)
    {
        V rv = null;
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext() && rv == null;)
        {
            KeyContainer entry = it.next();
            if (entry.getKey().equals(key))
            {
                rv = (V) entry.getValue();
                keys.remove(entry);
            }
        }
        return rv;
    }

    @Override
    public void putAll(Map m)
    {
        for (Object k : m.keySet())
        {
            Object e = m.get(k);
            this.put(k, e);
        }
    }

    @Override
    public void clear()
    {
        keys.clear();
    }

    @Override
    public Set<K> keySet()
    {
        Set rv = new LinkedHashSet();
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext();)
        {
            KeyContainer entry = it.next();
            rv.add(entry.getKey());
        }
        return rv;
    }

    @Override
    public Collection<V> values()
    {
        Vector<V> rv = new Vector<V>();
        for (Iterator<KeyContainer<K, V>> it = keys.iterator(); it.hasNext();)
        {
            KeyContainer entry = it.next();
            rv.add((V) entry.getValue());
        }
        return rv;
    }

    @Override
    public Set<KeyContainer<K, V>> entrySet()
    {
        Set<KeyContainer<K, V>> rv = new LinkedHashSet<KeyContainer<K, V>>();
        rv.addAll(keys);
        return rv;
    }

    /**
     * A Container that stores key and value
     * @param <K>
     * @param <V>
     */
    public class KeyContainer<K, V> implements Map.Entry<K, V>
    {

        private K key = null;
        private V value = null;

        private KeyContainer(K key, V value)
        {
            if (key == null || value == null)
            {
                throw new IllegalArgumentException("Key or value not allowed to be null");
            }
            this.key = key;
            this.value = value;
        }

        @Override
        public K getKey()
        {
            return key;
        }

        @Override
        public V getValue()
        {
            return value;
        }

        @Override
        public V setValue(Object value)
        {
            V old = this.value;
            this.value = (V) value;
            return old;
        }

        @Override
        public String toString()
        {
            return "[key=" + key + "|value=" + value + "]";
        }
    }
}
