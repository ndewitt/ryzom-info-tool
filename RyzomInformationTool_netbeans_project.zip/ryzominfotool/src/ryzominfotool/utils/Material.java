/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.utils;

import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.*;

/**
 * Represents a Material with grade, name, race, color, stats and much more
 * 
 * @author Niels-Peter de Witt
 */
public class Material
{


    private Source rtype;
    private Grade grade;
    private String name = "";
    private Race race = Race.All;
    private MatColor color;
    private int[] statusValue = new int[Status.Average.getIndex() + 1];
    private int qualityLevel = 250;
    private String itemID = "";
    private String description = "";
    private int DB_ID = 0;
    private int maxAmount = Integer.MAX_VALUE;
    private Categorie categorie = Categorie.ArmorClip;

    public Material(Source rtype, Grade grade,
                    String name, MatColor color, Categorie cat)
    {
        setColor(color);
        setGrade(grade);
        setName(name);
        setRtype(rtype);
        setCategorie(cat);
        for (int i = 0; i < statusValue.length; i++)
        {
            statusValue[i] = -1;
        }
    }

    public void setStatusValue(Status status, int value)
    {
        statusValue[status.getIndex()] = value;
    }

    public int getStatusValue(Status status)
    {
        return statusValue[status.getIndex()];
    }

    public List<Status> getStati()
    {
        Vector<Status> rv = new Vector<Status>();
        for (Status s : Status.values())
        {
            if (getStatusValue(s) >= 0)
            {
                rv.add(s);
            }
        }
        return rv;
    }

    @Override
    public String toString()
    {
        String rv = "";
        rv = getName() + " " + getGrade().name() + " " + getColor().name() + " " + getRtype().name() + " " + getRace().toString();
        return rv;
    }

    @Override
    public boolean equals(Object obj)
    {
        boolean rv = false;
        if (obj instanceof Material)
        {
            Material m = (Material) obj;
            rv = getName().equals(m.getName()) &&
                    getGrade().equals(m.getGrade()) &&
                    getColor().equals(m.getColor()) &&
                    getRtype().equals(m.getRtype());
        }
        return rv;
    }

    @Override
    public int hashCode()
    {
        String hashString = getName() + getGrade().name() + getColor().name() + getRtype().name();
        return hashString.hashCode();
    }

    public int getQualityLevel()
    {
        return qualityLevel;
    }

    public void setQualityLevel(int qualityLevel)
    {
        this.qualityLevel = qualityLevel;
    }

    public String getItemID()
    {
        return itemID;
    }

    public void setItemID(String itemID)
    {
        this.itemID = itemID;
    }

    public int getDB_ID()
    {
        return DB_ID;
    }

    public void setDB_ID(int DB_ID)
    {
        this.DB_ID = DB_ID;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public int getMaxAmount()
    {
        return maxAmount;
    }

    public void setMaxAmount(int maxAmount)
    {
        this.maxAmount = maxAmount;
    }

    public Categorie getCategorie()
    {
        return categorie;
    }

    public void setCategorie(Categorie categorie)
    {
        this.categorie = categorie;
    }
    
    public Source getRtype()
    {
        return rtype;
    }

    public void setRtype(Source rtype)
    {
        this.rtype = rtype;
    }

    public Grade getGrade()
    {
        return grade;
    }

    public void setGrade(Grade grade)
    {
        this.grade = grade;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Race getRace()
    {
        return race;
    }

    public void setRace(Race race)
    {
        this.race = race;
    }

    public MatColor getColor()
    {
        return color;
    }

    public void setColor(MatColor color)
    {
        this.color = color;
    }    
}
