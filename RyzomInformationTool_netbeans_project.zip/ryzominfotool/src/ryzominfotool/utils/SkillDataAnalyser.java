/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */


package ryzominfotool.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.DerbyLoader;
import ryzominfotool.db.SkillDbHandler;

/**
 * Translation helper for Skills entries in the database.
 * Note: Adapt path to *.serial file. They are located in the ExternalResources
 * directory
 * @author Niels-Peter de Witt
 */
public class SkillDataAnalyser {
    public static void main(String[] args) throws Exception {
        DerbyLoader.open(DerbyLoader.INFO_DB, false, "user1", "user1");
        
        StringBuffer contentEn = new StringBuffer();
        StringBuffer contentDe = new StringBuffer();
        StringBuffer contentFr = new StringBuffer();

        {
            FileReader fr = new FileReader(new File("/work/words_en_skill.serial"));
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            while ((line = br.readLine()) != null) {
                contentEn.append(line);
            }
            br.close();
        }
        {
            FileReader fr = new FileReader(new File("/work/words_de_skill.serial"));
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            while ((line = br.readLine()) != null) {
                contentDe.append(line);
            }
            br.close();
        }
        {
            FileReader fr = new FileReader(new File("/work/words_fr_skill.serial"));
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            while ((line = br.readLine()) != null) {
                contentFr.append(line);
            }
            br.close();
        }
        
        List<String> ids = SkillDbHandler.getSkillIds();
        for (String id : ids)
        {
            String desc = lookupDescription(id, contentEn.toString());
            SkillDbHandler.setSkillDescription(id, Language.English, desc);
            desc = lookupDescription(id, contentDe.toString());
            SkillDbHandler.setSkillDescription(id, Language.German, desc);
            desc = lookupDescription(id, contentFr.toString());
            SkillDbHandler.setSkillDescription(id, Language.French, desc);
        }
        DerbyLoader.close(DerbyLoader.INFO_DB);
    }
    
    private static String lookupDescription(String itemId, String content) {
            String searchTxt = "\""+itemId+"\"";
            int index = content.indexOf(searchTxt);
            int index2 = content.indexOf(searchTxt, index+searchTxt.length());
            if (index < 0) {
                return null;
            }
            if (index2 >= 0) {
                return null;
            }
            String descLookup = ":\"";
            index = content.indexOf(descLookup, index+searchTxt.length());
            index = content.indexOf(descLookup, index+descLookup.length());
            index2 = content.indexOf("\"", index+descLookup.length());
            String description = content.substring(index+descLookup.length(), index2);
            return description;
    }
    
}
