/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool;

import java.awt.Color;

/**
 * This file contains a list of commonly used Enums used during the project
 * @author Niels-Peter de Witt
 */
public class Enums
{
    
    public enum Server {
        Leanon,
        Aniro,
        Arispotle
    }

    /**
     * Contains the 4 Races and a All marker.
     * Commonly used for Materials, where All means, that it is not assigned
     * to a specified contry like Prime Roots or basic and fine mats
     */
    public enum Race
    {

        Zorai,
        Tryker,
        Fyros,
        Matis,
        All;
    }

    /**
     * The Langugage the Programm should use
     */
    public enum Language
    {

        German,
        English,
        French
    
    }

    /** 
     * The Material Color of a Mat or maybe a resulting item created with it
     * The colors are ordered like theire preference in game for crafting 
     * activities
     * Any_Color is a not determined color yet.
     */
    public enum MatColor
    {

        Any_Color(new Color(20, 20, 20)),
        Red(new Color(255, 0, 0)),
        Beige(new Color(240, 240, 175)),
        Green(new Color(0, 255, 0)),
        Turquoise(new Color(64, 224, 208)),
        Blue(new Color(0, 0, 255)),
        Purple(new Color(160, 32, 240)),
        White(new Color(255, 255, 255)),
        Black(new Color(0, 0, 0)),;
        /*    >| Tür | Red | Gre | Blu | Pur | Whi | Bla | Bei |
         * -----------------------------------------------------
         * Red |  >  |  -  |  >  |  >  |  >  |  >  |  >  |  >  | 0
         * Bei |  >  |  <  |  >  |  >  |  >  |  >  |  >  |  -  | 1
         * Gre |  >  |  <  |  -  |  >  |  >  |  >  |  >  |  <  | 2
         * Tür |  -  |  <  |  <  |  >  |  >  |  >  |  >  |  <  | 3
         * Blu |  <  |  <  |  <  |  -  |  >  |  >  |  >  |  <  | 4
         * Pur |  <  |  <  |  <  |  <  |  -  |  >  |  >  |  <  | 5
         * Whi |  <  |  <  |  <  |  <  |  <  |  -  |  >  |  <  | 6
         * Bla |  <  |  <  |  <  |  <  |  <  |  <  |  -  |  <  | 7
         */
        private Color c;

        MatColor(Color c)
        {
            this.c = c;
        }

        public Color getColor()
        {
            return c;
        }
    }

    /** 
     * The Grade of a material.
     */
    public enum Grade
    {

        Basic(0),
        Fine(1),
        Choice(2),
        Excellent(3),
        Supreme(4);
        private int order = 0;

        Grade(int order)
        {
            this.order = order;
        }

        public int getOrder()
        {
            return order;
        }
    }

    /**
     * Kind of source of the material, if it is from forage or loot.
     */
    public enum Source
    {

        Forage,
        Loot;
    }

    /**
     * The categorie a Material can have.
     */
    public enum Categorie
    {

        ArmorClip("Armor Clip"),
        ArmorShell("Armor Shell"),
        Barrel("Barrel"),
        Blade("Blade"),
        Bullet("Bullet"),
        Cloth("Cloth"),
        Counterweight("Counterweight"),
        Explosive("Explosive"),
        FiringPin("Firing Pin"),
        Grip("Grip"),
        Hammer("Hammer"),
        Jacket("Jacket"),
        JewelSetting("Jewel Setting"),
        Jewels("Jewels"),
        Lining("Lining"),
        MagicFokus("Magic Fokus"),
        Point("Point"),
        Shaft("Shaft"),
        Stuffing("Stuffing"),
        Trigger("Trigger");
        private String catName = "";

        Categorie(String catName)
        {
            this.catName = catName;
        }

        public String getCatName()
        {
            return catName;
        }

        @Override
        public String toString()
        {
            return catName;
        }
    }

    /**
     * The possible states a material can have
     */
    public enum Status
    {

        Dura(0, "Duration"),
        Light(1, "Lightness"),
        Dodge_Mod(2, "Dodge mod."),
        Parry_Mod(3, "Parry mod."),
        Prot_Factor(4, "Prot. Factor"),
        Max_Slash_Prot(5, "Slashing prot."),
        Max_Smash_Prot(6, "Smashing prot."),
        Max_Pierce_Prot(7, "Piercing prot."),
        SAP_Load(8, "Sap load"),
        DMG(9, "Damage"),
        Speed(10, "Speed"),
        Range(11, "Range"),
        Adv_Dodge_Mod(12, "Adv. Dodge mod."),
        Adv_Parry_Mod(13, "Adv. Parry mod"),
        Desert_Resistance(14, "Desert resist."),
        Forest_Resistance(15, "Forest resist."),
        Lake_Resistance(16, "Lake resist."),
        Jungle_Resistance(17, "Jungle resist."),
        Prime_Roots_Resistance(18, "Prime roots resist."),
        Acid_Prot(19, "Acid prot."),
        Cold_Prot(20, "Cold prot."),
        Rot_Prot(21, "Rot prot."),
        Fire_Prot(22, "Fire prot."),
        Shockwave_Prot(23, "Shockwave prot."),
        Poison_Prot(24, "Posion prot."),
        Electric_Prot(25, "Electric prot."),
        Ele_Speed(26, "Elemental speed"),
        Ele_Power(27, "Elemental power"),
        OA_Speed(28, "Off. Affl. speed"),
        OA_Power(29, "Off. Affl. power"),
        DA_Speed(30, "Def. Affl. speed"),
        DA_Power(31, "Def. Affl. power"),
        Heal_Speed(32, "Heal speed"),
        Heal_Power(33, "Heal power"),
        Average(34, "Average");
        private int index = 0;
        private String name = "";

        Status(int index, String name)
        {
            this.index = index;
            this.name = name;
        }

        public int getIndex()
        {
            return index;
        }

        public String getName()
        {
            return name;
        }
    }

    /**
     * Categories a item can have
     */
    public enum ItemCategories
    {

        Equipment("Equipment"),
        Equ_Jewels("Jewels"),
        Equ_Weapon("Melee Weapons"),
        Equ_Armor("Armor"),
        Equ_LightArmor("Light Armor"),
        Equ_MediumArmor("Medium Armor"),
        Equ_HeavyArmor("Heavy Armor"),
        Equ_Ammo("Ammo"),
        Equ_Ranged("Range Weapons"),
        Equ_Shield("Shields"),
        LootMat("Loot Material"),
        ForageMat("Forage Materials"),
        Ticket("Tickets"),
        Crystall("Crystalls"),
        Flowers("Flowers"),
        Mektoub("Mecktoubs"),
        Not_definable("not defined yet");
        private String name = "";

        ItemCategories(String name)
        {
            this.name = name;
        }

        @Override
        public String toString()
        {
            return name;
        }
    }
}
