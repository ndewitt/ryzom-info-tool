/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui;

import java.awt.Color;
import java.awt.Cursor;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.DerbyLoader;
import ryzominfotool.gui.utils.panels.DekoratedTabbedPane;
import ryzominfotool.plugin.log.LogPanel;

/**
 * The Main Frame.
 * It provides adding/removing of PluggableContents (Plugins)
 * Setting of Languages to all added PluggableContents
 * Setting/Getting and register/unregister on Properties(-changes)
 * Adding to the log
 * @author bcsniwi
 */
public class FrameworkFrame extends javax.swing.JFrame
{

    private DekoratedTabbedPane tabPane = new DekoratedTabbedPane();
    private Vector<PluggableContent> pluggedContent = new Vector();
    private Language currentLanguage = Language.English;
    private HashMap<String, Object> properties = new HashMap<String, Object>();
    private HashMap<String, Vector<PropertyChangeListener>> propChangeListeners = new HashMap<String, Vector<PropertyChangeListener>>();

    /** 
     * Creates new form FrameworkFrame 
     */
    public FrameworkFrame()
    {
        initComponents();
        this.getContentPane().add(tabPane);
        tabPane.setButtonBackgroundColor(new Color(200, 255, 200));
    }
    

    
    /**
     * Sets the loading state with cursor info
     * @param loading - true if loading is enabled
     */
    public void setLoadingState(boolean loading) {
        if (loading) {
            this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        } else {
            this.setCursor(Cursor.getDefaultCursor());
        }
        
    }

    /**
     * Adds a PluggableContent to the frame and sets the property of this and
     * the current language to the added plugin.
     * @param content
     */
    public void addPluggableContent(PluggableContent content)
    {
        tabPane.addComponent(content, content.getDisplayName());
        content.setLanguage(currentLanguage);
        content.setFrame(this);
        pluggedContent.add(content);

    }

    /**
     * Removes a PluggableContent from the frame.
     * @param content - the plugin to remove
     */
    public void removePluggableContent(PluggableContent content)
    {
        tabPane.removeComponent(content);
        content.setFrame(null);
        pluggedContent.remove(content);
    }

    /**
     * Returns a list of all pluggable contents
     * @return a list of all pluggable contents
     */
    public List<PluggableContent> getPluggableContents()
    {
        return pluggedContent;
    }

    /**
     * Sets the current language and informs all plugins of the current language
     * @param lan - the new language
     */
    public void setCurrentLanguage(Language lan)
    {
        this.currentLanguage = lan;
        for (PluggableContent pl : pluggedContent)
        {
            pl.setLanguage(lan);
            tabPane.updateDisplayNames(pl);
        }

    }

    /**
     * Returns the current used language
     * @return the current used language
     */
    public Language getCurrentLanguage()
    {
        return this.currentLanguage;
    }

    /**
     * Sets a property and informs registered listener on the property change
     * 
     * @param source - the source that sets the property
     * @param key - the property key
     * @param value - the new value to set
     * @param description - meaning of this property - can be null
     * @return Returns the old property value.
     */
    public synchronized Object setProperty(Object source, String key, Object value, String description)
    {
        Object rv = null;
        rv =  getProperty(key);
       
        PropertyContainerValue pcv = new PropertyContainerValue();
        pcv.propertyDescription = description;
        pcv.propertyValue = value;
        
        properties.put(key, pcv);

        Vector<PropertyChangeListener> lst = propChangeListeners.get(key);
        if (lst != null)
        {
            for (Iterator<PropertyChangeListener> it = lst.iterator(); it.hasNext();)
            {
                PropertyChangeListener l = it.next();
                l.propertyChange(new PropertyChangeEvent(source, key, rv, value));

            }
        }
        return rv;
    }

    /**
     * Gets the property to the key
     * @param key - the key to get the property for
     * @return the property value, or null, if no property exists with the given key
     */
    public synchronized Object getProperty(String key)
    {
        Object rv = null;
        rv = properties.get(key);
        if (rv != null) {
            rv = ((PropertyContainerValue) rv).propertyValue;
        }

        return rv;
    }

    /**
     * Returns the property key names
     * @return the property key names
     */
    public synchronized List<String> getPropertyKeys() {
        List<String> lst = new Vector();
        Iterator<String> it = properties.keySet().iterator();
        while (it.hasNext()) {
            lst.add(it.next());
        }
        return lst;
    }
    
    /**
     * Returns the property description by the key
     * @param key - the property key
     * @return the description of the property
     */
    public synchronized String getPropertyDescription(String key) {
        String rv = "";
        PropertyContainerValue pcv = (PropertyContainerValue)properties.get(key);
        if (pcv != null) {
            rv = pcv.propertyDescription;
            if (rv == null) {
                rv = "";
            }
        }
        return rv;
    }
    
    /**
     * Returns the used class of the value of the property referenced by the key
     * @param key - the property key
     * @return the used class of the value of the property referenced by the key
     */
    public synchronized String getPropertyValueClass(String key) {
        String rv = "";
        PropertyContainerValue pcv = (PropertyContainerValue)properties.get(key);
        if (pcv != null && pcv.propertyValue != null) {
            rv = pcv.propertyValue.getClass().getName();
            if (rv == null) {
                rv = "";
            }
        }
        return rv;
    }    
    
    /**
     * Storage for property data
     */
    private class PropertyContainerValue {
        public String propertyDescription = "";
        public Object propertyValue = null;
    }
    
    /**
     * Registers on a property key change
     * @param key - the key to register on
     * @param listener - the listener to register
     */
    public synchronized void registerOnProperty(String key, PropertyChangeListener listener)
    {
        if (!propChangeListeners.containsKey(key))
        {
            propChangeListeners.put(key, new Vector<PropertyChangeListener>());
        }
        Vector<PropertyChangeListener> lst = (Vector<PropertyChangeListener>) propChangeListeners.get(key);
        lst.add(listener);
    }

    /**
     * Unregisters on a property change for a special key
     * @param key - the key to unregister to
     * @param listener - the listener to remove
     */
    public synchronized void unregisterOnProperty(String key, PropertyChangeListener listener)
    {
        if (propChangeListeners.containsKey(key))
        {
            Vector<PropertyChangeListener> lst = (Vector<PropertyChangeListener>) propChangeListeners.get(key);
            lst.remove(listener);
        }
    }
    
    public synchronized boolean hasPropertyRegisteredListener(String key) {
        boolean rv = false;
        if (propChangeListeners.containsKey(key)) {
            Vector<PropertyChangeListener> lst = (Vector<PropertyChangeListener>) propChangeListeners.get(key);
            rv = lst.size() > 0;
        }
        return rv;
    }

    /**
     * Adds a String to the log
     * @param txt - text to add
     */
    public void addLog(String txt)
    {
        Object obj = this.getProperty("common.log");
        if (obj instanceof LogPanel)
        {
            LogPanel lp = (LogPanel) obj;
            lp.addLog(txt);
        }
    }

    /**
     * Adds a Exception to the log
     * @param exc - exception to add
     */
    public void addLog(Exception exc)
    {
        Object obj = this.getProperty("common.log");
        if (obj instanceof LogPanel)
        {
            LogPanel lp = (LogPanel) obj;
            lp.addException(exc);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
    try {
        System.out.println("closing DB");
        DerbyLoader.close(DerbyLoader.INFO_DB);
    } catch (SQLException exc) {
        exc.printStackTrace();
    }
}//GEN-LAST:event_formWindowClosing

private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed

}//GEN-LAST:event_formWindowClosed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
