/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.util.List;
import java.util.Vector;
import javax.swing.table.AbstractTableModel;

/**
 * A TableModel for a compact display of the Items of an inventory.
 * Compact means, that in every cell a complete Item is displayed. The amount 
 * of columns can be adjusted by the outside.
 * @author bcsniwi
 */
public class CompactInventoryTableModel extends AbstractTableModel
{

    private List<Item> data = new Vector();
    private int colCount = 10;

    /**
     * Constructs a new TableModel
     */
    public CompactInventoryTableModel()
    {
    }

    /**
     * Sets the Items to display
     * @param items - list of items to display
     */
    public void setItemList(List<Item> items)
    {
        data.clear();
        data.addAll(items);
        fireTableStructureChanged();
    }

    @Override
    public String getColumnName(int column)
    {
        return "";
    }

    @Override
    public int getRowCount()
    {
        int rowCount = data.size() / getColumnCount();
        if (rowCount * getColumnCount() < data.size())
        {
            rowCount++;
        }
        return rowCount;
    }

    @Override
    public int getColumnCount()
    {
        return colCount;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex)
    {
        int index = rowIndex * getColumnCount() + columnIndex;
        Object rv = null;
        if (index < data.size())
        {
            rv = data.get(rowIndex * getColumnCount() + columnIndex);
        }
        return rv;
    }

    /**
     * Sets the amount of columns that should be visible
     * @param colCount
     */
    public void setColumnCount(int colCount)
    {
        this.colCount = colCount;
        fireTableStructureChanged();
    }
}
