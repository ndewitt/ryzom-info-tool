/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import javax.swing.text.NumberFormatter;

/**
 * Table model to display Inventory Items.
 * The model is variable of its columns. It calculates which columns should be
 * present, because needed of the items to display.
 * 
 * @author Niels-Peter de Witt
 */
public class InventoryTableModel extends AbstractTableModel
{

    private Vector<InventoryColumnHeader> headerNames = new Vector();
    private List<Item> data = new Vector();
    private NumberFormatter nf = new NumberFormatter(new DecimalFormat("000"));

    /**
     * Constructs a new InventoryTableModel with all available headernames.
     */
    public InventoryTableModel()
    {
        for (InventoryColumnHeader is : InventoryColumnHeader.values())
        {
            headerNames.add(is);
        }

    }
    

    /**
     * Sets the items to display and calculates the needed columns
     * @param items - the items to display
     */
    public void setItemList(List<Item> items)
    {
        data.clear();
        data.addAll(items);
        calcHeaderNames();
        fireTableStructureChanged();
    }

    @Override
    public String getColumnName(int column)
    {
        return headerNames.get(column).toString();
    }

    @Override
    public int getRowCount()
    {
        return data.size();
    }

    @Override
    public int getColumnCount()
    {
        return headerNames.size();
    }

    /**
     * Returns the Item at the given row in this model
     * @param row - the row to get the Item frmo
     * @return the item stored at the row index
     */
    public Item getItemAtRow(int row)
    {
        return data.get(row);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex)
    {
        Object rv = null;
        if (rowIndex >= data.size() || columnIndex >= headerNames.size()) return null;
        InventoryColumnHeader col = headerNames.get(columnIndex);
        Item it = data.get(rowIndex);
        switch (col)
        {
            case adodge:
                rv = formatNumber(it.getStat(ItemStats.adm));
                break;
            case amount:
                rv = formatNumber(it.getStat(ItemStats.s));
                break;
            case aparry:
                rv = formatNumber(it.getStat(ItemStats.apm));
                break;
            case dodge:
                rv = formatNumber(it.getStat(ItemStats.dm));
                break;
            case duration:
                if (it.getStat(ItemStats.hp) == null || it.getStat(ItemStats.dur) == null)
                {
                    rv = null;
                }
                else
                {
                    rv = formatNumber(it.getStat(ItemStats.hp)) + "/" + formatNumber(it.getStat(ItemStats.dur));
                }
                break;
            case fob:
                rv = formatNumber(it.getStat(ItemStats.fob));
                break;
            case hpb:
                rv = formatNumber(it.getStat(ItemStats.hpb));
                break;
            case hr:
                rv = formatNumber(it.getStat(ItemStats.hr));
                break;
            case itemClass:
                rv = it.getStat(ItemStats.e);
                break;
            case itemId:
                rv = it.getStat(ItemStats.itemId);
                break;
            case location:
                rv = it.getStat(ItemStats.location);
                break;
            case mbp:
                rv = formatNumber(it.getStat(ItemStats.mbp));
                break;
            case mpp:
                rv = formatNumber(it.getStat(ItemStats.mpp));
                break;
            case msp:
                rv = formatNumber(it.getStat(ItemStats.msp));
                break;
            case name:
                rv = it.getStat(ItemStats.name);
                break;
            case parry:
                rv = formatNumber(it.getStat(ItemStats.pm));
                break;
            case part:
                rv = it.getStat(ItemStats.part);
                break;
            case price:
                rv = it.getStat(ItemStats.price);
                break;
            case protf:
                rv = formatNumber(it.getStat(ItemStats.pf));
                break;
            case quality:
                rv = formatNumber(it.getStat(ItemStats.q));
                break;
            case range:
                rv = it.getStat(ItemStats.r);
                break;
            case sab:
                rv = formatNumber(it.getStat(ItemStats.sab));
                break;
            case sapLoad:
                if (it.getStat(ItemStats.sl) == null || it.getStat(ItemStats.csl) == null)
                {
                    rv = null;
                }
                else
                {
                    rv = formatNumber(it.getStat(ItemStats.csl)) + "/" + formatNumber(it.getStat(ItemStats.sl));
                }
                break;
            case stb:
                rv = formatNumber(it.getStat(ItemStats.stb));
                break;
            case text:
                rv = it.getStat(ItemStats.text);
                break;
            case weight:
                rv = it.getStat(ItemStats.w);
                break;
            case sold_in:
                rv = it.getStat(ItemStats.in_sell_since);
                break;
            case continent:
                rv = it.getStat(ItemStats.continent);
                break;
        }

        return rv;
    }

    /**
     * Formats a String into a 3 digit number. if value is below 100 a 0 is 
     * added at the beginning
     * @param value - value to parse as a 3 digit number
     * @return a 3 digit number with leading 0s
     */
    private String formatNumber(String value)
    {
        String rv = null;
        if (value != null)
        {
            try
            {
                int i = Integer.parseInt(value);
                rv = nf.valueToString(i);
            }
            catch (Exception exc)
            {
                exc.printStackTrace();
            }
        }
        return rv;
    }

    /**
     * Calculates the used headernames/columns with the current stored Items
     */
    private void calcHeaderNames()
    {
        HashSet<ItemStats> usedStats = new HashSet<ItemStats>();
        for (Item it : data)
        {
            for (ItemStats is : ItemStats.values())
            {
                if (it.getStat(is) != null)
                {
                    usedStats.add(is);
                }
            }
        }
        headerNames.clear();
        for (InventoryColumnHeader ch : InventoryColumnHeader.values())
        {
            switch (ch)
            {
                case adodge:
                    if (usedStats.contains(ItemStats.adm))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case amount:
                    if (usedStats.contains(ItemStats.s))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case aparry:
                    if (usedStats.contains(ItemStats.apm))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case dodge:
                    if (usedStats.contains(ItemStats.dm))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case duration:
                    if (usedStats.contains(ItemStats.hp))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case fob:
                    if (usedStats.contains(ItemStats.fob))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case hpb:
                    if (usedStats.contains(ItemStats.hpb))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case hr:
                    if (usedStats.contains(ItemStats.hr))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case itemClass:
                    if (usedStats.contains(ItemStats.c))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case itemId:
                    if (usedStats.contains(ItemStats.itemId))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case location:
                    if (usedStats.contains(ItemStats.location))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case mbp:
                    if (usedStats.contains(ItemStats.mbp))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case mpp:
                    if (usedStats.contains(ItemStats.mpp))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case msp:
                    if (usedStats.contains(ItemStats.msp))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case name:
                    if (usedStats.contains(ItemStats.name))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case parry:
                    if (usedStats.contains(ItemStats.pm))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case part:
                    if (usedStats.contains(ItemStats.part))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case price:
                    if (usedStats.contains(ItemStats.price))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case protf:
                    if (usedStats.contains(ItemStats.pf))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case quality:
                    if (usedStats.contains(ItemStats.q))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case range:
                    if (usedStats.contains(ItemStats.r))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case sab:
                    if (usedStats.contains(ItemStats.sab))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case sapLoad:
                    if (usedStats.contains(ItemStats.sl))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case stb:
                    if (usedStats.contains(ItemStats.stb))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case text:
                    if (usedStats.contains(ItemStats.text))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case weight:
                    if (usedStats.contains(ItemStats.w))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case sold_in:
                    if (usedStats.contains(ItemStats.in_sell_since))
                    {
                        headerNames.add(ch);
                    }
                    break;
                case continent:
                    if (usedStats.contains(ItemStats.continent))
                    {
                        headerNames.add(ch);
                    }
                    break;                    
            }

        }

    }
}
