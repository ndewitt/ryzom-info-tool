/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.TranslationDbHandler;

/**
 * An Inventory Header Renderer, that will translate a header entry for the current
 * language
 * @author Niels-Peter de Witt
 */
public class InventoryTableHeaderRenderer extends DefaultTableCellRenderer
{

    private Language curLanguage = Language.English;

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        String txt = value.toString();
        InventoryColumnHeader ich = InventoryColumnHeader.valueOf(txt);
        lbl.setOpaque(true);
        lbl.setBackground(new Color(255, 255, 204));
        lbl.setBorder(new LineBorder(Color.gray));
        lbl.setHorizontalAlignment(JLabel.CENTER);

        lbl.setText(TranslationDbHandler.getTranslation(ich.getClass().getName() + "." + ich.name(), curLanguage, ich.getDefaultEnName()));

        return lbl;
    }

    /**
     * Set the current language to use.
     * @param lan - current language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
    }
}
