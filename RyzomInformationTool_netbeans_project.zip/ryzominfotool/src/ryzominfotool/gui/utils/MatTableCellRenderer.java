/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.awt.Component;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import ryzominfotool.Enums.Grade;
import ryzominfotool.Enums.Language;
import ryzominfotool.Enums.MatColor;
import ryzominfotool.Enums.Race;
import ryzominfotool.db.ItemDbHandler;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.utils.*;

/**
 * TableCellRenderer to render Materials in a table
 * Materials are row wise in the table.
 * Fixed Columns.
 * Material description is taken via the current lange property.
 * 
 * @author Niels-Peter de Witt
 */
public class MatTableCellRenderer extends DefaultTableCellRenderer
{

    private Language curLanguage = Language.English;

    /**
     * Set the current used language for rendering item description
     * @param lan - the new language
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        Component sc = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        Material m = (Material) value;
        JLabel rv = new JLabel();
        String name = m.getName();
        try
        {
            name = ItemDbHandler.getItemDescription(m.getItemID(), curLanguage);
        }
        catch (SQLException exc)
        {
            exc.printStackTrace();
        }
        String grade = TranslationDbHandler.getTranslation(Grade.class.getName() + "." + m.getGrade().name(), curLanguage, m.getGrade().name());
        String race = TranslationDbHandler.getTranslation(Race.class.getName() + "." + m.getRace().name(), curLanguage, m.getRace().name());
        String color = TranslationDbHandler.getTranslation(MatColor.class.getName() + "." + m.getColor().name(), curLanguage, m.getColor().name());

        switch (column)
        {
            case 0: // Name

                rv.setText(name);
                try
                {
                    rv.setIcon(ImageFactory.getMatIcon(m.getItemID(), m.getQualityLevel(), -1));
                }
                catch (Exception exc)
                {
                    exc.printStackTrace();
                }
                setToolTipText(grade + " " + name);
                break;
            case 1: // Grade

                rv.setText(grade);
                break;
            case 2: // Race

                rv.setText(race);
                break;
            case 3: // Color

                rv.setText(color);
                break;
            case 4: // max level

                rv.setText(m.getQualityLevel() + "");
                break;

        }


        rv.setForeground(sc.getForeground());
        rv.setBackground(sc.getBackground());
        rv.setOpaque(true);
        return rv;
    }
}
