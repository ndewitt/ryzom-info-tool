/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.util.HashMap;

/**
 * A item has some Stats with values. These are stored in here.
 * 
 * @author Niels-Peter de Witt
 */
public class Item
{

    private HashMap<ItemStats, String> map = new HashMap();

    /**
     * Set the stat of the Item
     * @param stat - the stat to set
     * @param value - the value of the stat
     */
    public void setStat(ItemStats stat, String value)
    {
        map.put(stat, value);
    }

    /**
     * Returns the Stat of the Item, or null, if the stat does not exists.
     * @param stat - the stat to get the value for
     * @return the stat to get the value for or null, if stat is not available
     */
    public String getStat(ItemStats stat)
    {
        return map.get(stat);
    }
}
