/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import ryzominfotool.utils.ImageFactory;
import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import ryzominfotool.Enums;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.ItemDbHandler;
import ryzominfotool.db.TranslationDbHandler;

/**
 * A Table Cell Renderer for displaying the inventory in a  way with only
 * one Item per Line.
 * At Header with Enum itemId an Image will be displayed.
 * At Header with Enum duration a cur/max will be displayed and if cur is 
 * below 25% of max it will be colored red, otherwise green
 * @author Niels-Peter de Witt
 */

public class InventoryTableCellRenderer extends DefaultTableCellRenderer
{

    private long serverTicks = 0;
    private final long MAX_SELL_TIME = 7*24*60*60*1000; // server ticks of 7 days
    private Language curLanguage = Language.English;
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        lbl.setIcon(null);
        if (isSelected)
        {
            lbl.setBackground(new Color(0, 0, 255, 50));
        }
        else
        {
            lbl.setBackground(Color.white);
        }
        String hVal = table.getColumnModel().getColumn(column).getHeaderValue().toString();
        InventoryColumnHeader ich = InventoryColumnHeader.valueOf(hVal);
        if (ich.equals(InventoryColumnHeader.itemId))
        {
            int newRow = table.getRowSorter().convertRowIndexToModel(row);
            Item it = ((InventoryTableModel) table.getModel()).getItemAtRow(newRow);
            String itemId = it.getStat(ItemStats.itemId);
            String stackSize = it.getStat(ItemStats.s);
            String qual = it.getStat(ItemStats.q);
            int q = (qual != null) ? Integer.parseInt(qual) : -1;
            int s = (stackSize != null) ? Integer.parseInt(stackSize) : -1;
            String c = it.getStat(ItemStats.c);
            Icon ic = null;
            if (c != null)
            {
                ic = ImageFactory.getMatIcon(itemId, q, s, c);
            }
            else
            {
                ic = ImageFactory.getMatIcon(itemId, q, s);
            }
            lbl.setIcon(ic);
            lbl.setText("");

        }

        if (ich.equals(InventoryColumnHeader.duration))
        {
            if (value != null)
            {
                String val = (String) value;
                String curHP = val.substring(0, 3).trim();
                String maxHP = val.substring(4, 7).trim();
                Integer cur = Integer.parseInt(curHP);
                Integer max = Integer.parseInt(maxHP);
                double ratio = (double) cur / (double) max;
                if (ratio < 0.25)
                {
                    lbl.setBackground(new Color(255, 0, 0, 50));
                }
                else
                {
                    lbl.setBackground(new Color(0, 255, 0, 50));
                }

            }
        }
        
        if (ich.equals(InventoryColumnHeader.itemClass))
        {
            if (value != null)
            {
                String val = (String) value;
                if (val.equals("s")) {
                    val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName()+"."+Enums.Grade.Supreme.name(), curLanguage, Enums.Grade.Supreme.name());
                } else 
                if (val.equals("e")) {
                    val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName()+"."+Enums.Grade.Excellent.name(), curLanguage, Enums.Grade.Excellent.name());
                } else 
                if (val.equals("c")) {
                    val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName()+"."+Enums.Grade.Choice.name(), curLanguage, Enums.Grade.Choice.name());
                } else 
                if (val.equals("f")) {
                    val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName()+"."+Enums.Grade.Fine.name(), curLanguage, Enums.Grade.Fine.name());
                } else 
                if (val.equals("b")) {
                    val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName()+"."+Enums.Grade.Basic.name(), curLanguage, Enums.Grade.Basic.name());
                } lbl.setText(val);
            }
        }        
        if (ich.equals(InventoryColumnHeader.location))
        {
            if (value != null)
            {
                String val = (String) value;
                ItemUtils.ItemPlaces ip = ItemUtils.ItemPlaces.valueOf(val);
                lbl.setText(TranslationDbHandler.getTranslation(ItemUtils.ItemPlaces.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName()));        
            }
        }
        if (ich.equals(InventoryColumnHeader.sold_in))
        {
            if (value != null)
            {
                String val = (String) value;
                if (serverTicks > 0) {
                    try {
                        long sellSince = Long.parseLong(val)*1000;
                        
                        long curTime = System.currentTimeMillis();
                        long endTime = (sellSince+MAX_SELL_TIME);
                        if (curTime < endTime) {
                            Date date  =new Date(endTime-curTime);
                            GregorianCalendar gc = new GregorianCalendar();
                            gc.setTime(date);
                            int da = gc.get(Calendar.DAY_OF_YEAR)-1;
                            int ho = gc.get(Calendar.HOUR);
                            int mi = gc.get(Calendar.MINUTE);
                            String d = TranslationDbHandler.getTranslation(this.getClass()+".days", curLanguage, "d");
                            String h = TranslationDbHandler.getTranslation(this.getClass()+".hours", curLanguage, "h");
                            String m = TranslationDbHandler.getTranslation(this.getClass()+".minutes", curLanguage, "m");
                            if (da == 0) {
                                lbl.setBackground(new Color(255, 0, 0, 50));
                            } 
                            lbl.setText(da+d+" "+ho+h+" "+mi+m);
                        } else {
                            lbl.setBackground(new Color(255, 0, 0, 50));
                            lbl.setText(TranslationDbHandler.getTranslation(this.getClass()+".sold", curLanguage, "Sold"));
                        }
                    } catch (Exception exc) {
                        exc.printStackTrace();
                    }
                } else {
                    lbl.setText(TranslationDbHandler.getTranslation(this.getClass()+".unknown", curLanguage, "unknown"));
                    
                }
            }
        }        
        return lbl;
    }
    
    
    public void setServerTicks(Long currentTick) {
        serverTicks = currentTick;
    }
    
    /**
     * Set the current language to use.
     * @param lan - current language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
    }    
}

