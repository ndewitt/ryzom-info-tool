/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.TranslationDbHandler;

/**
 * A TableHeaderRenderer, that renders the Headernames by the current language.
 * @author Niels-Peter de Witt
 */
public class MatTableHeaderRenderer extends DefaultTableCellRenderer
{
    private Language curLanguage = Language.English;

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        lbl.setOpaque(true);
        lbl.setBackground(new Color(255, 255, 204));
        lbl.setBorder(new LineBorder(Color.gray));
        lbl.setHorizontalAlignment(JLabel.CENTER);
        switch (column)
        {
            case 0: // name

                lbl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".name", curLanguage, "Name"));
                break;
            case 1: // Grade

                lbl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".grade", curLanguage, "Grade"));
                break;
            case 2: // Race

                lbl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".race", curLanguage, "Race"));
                break;
            case 3: // Color

                lbl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".color", curLanguage, "Color"));
                break;
            case 4: // Max_Level

                lbl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".max_Level", curLanguage, "Max Level"));
                break;

        }

        return lbl;
    }

    /**
     * Sets the current used language to render with
     * @param lan - the new language
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
    }
}
