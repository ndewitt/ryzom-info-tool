/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import ryzominfotool.utils.ImageFactory;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * A Table Cell Renderer for displaying the inventory in a compact way with only
 * images.
 * Returns a Label with only the Item related Image in it and a tooltip with the
 * items description
 * @author Niels-Peter de Witt
 */
public class CompactInventoryTableCellRenderer extends DefaultTableCellRenderer
{

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        lbl.setIcon(null);

        if (value instanceof Item)
        {
            Item it = (Item) value;

            String itemId = it.getStat(ItemStats.itemId);
            String stackSize = it.getStat(ItemStats.s);
            String qual = it.getStat(ItemStats.q);
            int q = (qual != null) ? Integer.parseInt(qual) : -1;
            int s = (stackSize != null) ? Integer.parseInt(stackSize) : -1;
            String c = it.getStat(ItemStats.c);
            Icon ic = null;
            if (c != null)
            {
                ic = ImageFactory.getMatIcon(itemId, q, s, c);
            }
            else
            {
                ic = ImageFactory.getMatIcon(itemId, q, s);
            }
            lbl.setIcon(ic);
            lbl.setText("");
            String tooltip = it.getStat(ItemStats.name);
            lbl.setToolTipText(tooltip);
        }
        else
        {
            lbl.setIcon(null);
            lbl.setText("");
        }
        return lbl;
    }
}
