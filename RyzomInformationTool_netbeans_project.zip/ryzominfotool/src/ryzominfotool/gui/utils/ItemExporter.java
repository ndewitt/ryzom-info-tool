/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums;
import ryzominfotool.db.TranslationDbHandler;

/**
 * The ItemExporter creates language dependend csv content out of a list of items
 * @author Niels-Peter de Witt
 */
public class ItemExporter
{

    private List<ItemStats> exportableStats = new Vector<ItemStats>();
    private List<Item> currentItems = new Vector<Item>();

    public ItemExporter()
    {
        fillItemStats();
    }

    /**
     * Fills the ItemStats to export
     */
    private void fillItemStats()
    {
        exportableStats.clear();
        for (ItemStats is : ItemStats.values())
        {
            exportableStats.add(is);
        }
    }

    /**
     * Sets the list of items to export
     * @param items items to export
     */
    public void setItems(List<Item> items)
    {
        currentItems.clear();
        currentItems.addAll(items);
    }

    /**
     * Creates language dependend csv String for the set items.
     * The content is seperated by ";" and has a heading line with stats
     * @param curLanguage - the language to export to
     * @return the cvs content of the items
     */
    public String doExport(Enums.Language curLanguage)
    {
        StringBuffer buf = new StringBuffer();
        for (ItemStats is : exportableStats)
        {
            if (is.equals(ItemStats.icon))
            {
                continue;
            }
            String name = TranslationDbHandler.getTranslation(ItemStats.class.getName() + "." + is.name(), curLanguage, is.name());
            buf.append(name + ";");
        }
        buf.append("\n");
        for (Item item : currentItems)
        {
            for (ItemStats is : exportableStats)
            {
                String val = item.getStat(is);
                if (val == null)
                {
                    val = "";
                }
                else
                {
                    if (is.equals(ItemStats.e))
                    {
                        if (val.equals("s"))
                        {
                            val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName() + "." + Enums.Grade.Supreme.name(), curLanguage, Enums.Grade.Supreme.name());
                        }
                        else if (val.equals("e"))
                        {
                            val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName() + "." + Enums.Grade.Excellent.name(), curLanguage, Enums.Grade.Excellent.name());
                        }
                        else if (val.equals("c"))
                        {
                            val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName() + "." + Enums.Grade.Choice.name(), curLanguage, Enums.Grade.Choice.name());
                        }
                        else if (val.equals("f"))
                        {
                            val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName() + "." + Enums.Grade.Fine.name(), curLanguage, Enums.Grade.Fine.name());
                        }
                        else if (val.equals("b"))
                        {
                            val = TranslationDbHandler.getTranslation(Enums.Grade.class.getName() + "." + Enums.Grade.Basic.name(), curLanguage, Enums.Grade.Basic.name());
                        }
                    }
                    if (is.equals(ItemStats.location))
                    {
                        ItemUtils.ItemPlaces ip = ItemUtils.ItemPlaces.valueOf(val);
                        val = TranslationDbHandler.getTranslation(ItemUtils.ItemPlaces.class.getName() + "." + ip.name(), curLanguage, ip.getDefaultEnName());
                    }
                    if (is.equals(ItemStats.in_sell_since))
                    {
                        long time = Long.parseLong(val)*1000;
                        DateFormat df = new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss z");
                        val = df.format(new Date(time));
                    }
                }
                buf.append(val + ";");
            }
            buf.append("\n");
        }
        return buf.toString();
    }
}
