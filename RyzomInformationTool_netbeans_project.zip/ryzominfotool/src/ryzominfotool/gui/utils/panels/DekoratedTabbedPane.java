/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Vector;
import ryzominfotool.gui.PluggableContent;

/**
 * The Dekorated TabbedPane is an own implementation of a panel with 
 * dekoreated buttons.
 * @author  Niels-Peter de Witt
 */
public class DekoratedTabbedPane extends javax.swing.JPanel
{

    private Vector<MyContainer> data = new Vector<MyContainer>();
    private Color buttonBackgroundColor = new Color(200, 255, 200);
    private Color buttonSelectedColor = new Color(150, 190, 240);
    private Color buttonDeselectedColor = new Color(255, 210, 150);
    
    private ActionListener tglGroupListener = new ActionListener()
    {

        @Override
        public void actionPerformed(ActionEvent e)
        {
            panContent.removeAll();
            for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
            {
                MyContainer con = it.next();
                con.button.setSelected(con.button.equals(e.getSource()));
                if (con.button.isSelected())
                {
                    panContent.add(con.comp, BorderLayout.CENTER);
                }

            }
            panContent.revalidate();
            panContent.repaint();
        }
    };

    /** Creates new form DekoratedTabbedPane */
    public DekoratedTabbedPane()
    {
        initComponents();
    }

    /**
     * Adds a component at the end of the panel. The text is used as button label
     * @param c - component to add
     * @param text - text of the button
     */
    public synchronized void addComponent(Component c, String text)
    {
        MyContainer con = new MyContainer();
        con.button = new MyBorderedToggleButton(text);
        con.button.setSelectedColor(buttonSelectedColor);
        con.button.setNotSelectedColor(buttonDeselectedColor);
        con.button.addActionListener(tglGroupListener);
        con.text = text;
        con.comp = c;
        data.add(con);
        panButtons.add(con.button);
        if (data.size() == 1)
        {
            setSelectedComponent(c);
            Dimension dim = new Dimension(this.getWidth(), con.button.getMinimumSize().height + 10);
            panButtons.setMinimumSize(dim);
        }
        panButtons.revalidate();
        panButtons.repaint();
    }

    /**
     * Removes the component from the panel
     * @param c - the component to remove
     */
    public synchronized void removeComponent(Component c)
    {
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            if (con.comp.equals(c))
            {
                it.remove();
                panButtons.remove(con.button);
            }
        }
        panButtons.revalidate();
        panButtons.repaint();
    }

    /**
     * Updated the display name of the component. As a PluggableContent, it bring
     * its own display name that is used
     * @param pl - component to update
     */
    public synchronized void updateDisplayNames(PluggableContent pl)
    {
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            if (con.comp.equals(pl))
            {
                con.button.setText(pl.getDisplayName());
            }
        }
    }

    
    /**
     * Updated the display name of the component. The new display name is used
     * for the button
     * @param com - component to update
     * @param newDisplayName - the new name to display
     */
    public synchronized void updateDisplayNames(Component com, String newDisplayName)
    {
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            if (con.comp.equals(com))
            {
                con.button.setText(newDisplayName);
            }
        }
    }

    /**
     * Sets a selected Component
     * @param c - component to select
     */
    public synchronized void setSelectedComponent(Component c)
    {
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            if (con.comp.equals(c))
            {
                tglGroupListener.actionPerformed(new ActionEvent(con.button, 0, ""));
            }
        }
    }

    /**
     * get the background color of the buttons
     * @return the background color of the buttons
     */
    public Color getButtonBackgroundColor()
    {
        return buttonBackgroundColor;
    }

    /**
     * Set the background color of the buttons
     * @param buttonBackgroundColor - the background color of the buttons
     */
    public void setButtonBackgroundColor(Color buttonBackgroundColor)
    {
        this.buttonBackgroundColor = buttonBackgroundColor;
        this.panButtons.setBackground(buttonBackgroundColor);
        this.panButtons.setOpaque(true);
        this.revalidate();
        this.repaint();
    }

    /**
     * get the background color of the buttons in selected state
     * @return the background color of the buttons in selected state
     */
    public Color getButtonSelectedColor()
    {
        return buttonSelectedColor;
    }

    /**
     * Set the background color of the buttons for the selected state
     * @param buttonSelectedColor - the background color of the buttons for 
     * the selected state
     */
    public void setButtonSelectedColor(Color buttonSelectedColor)
    {
        this.buttonSelectedColor = buttonSelectedColor;
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            con.button.setSelectedColor(buttonSelectedColor);
            con.button.revalidate();
            con.button.repaint();
        }

    }

    /**
     * get the background color of the buttons in deselected state
     * @return the background color of the buttons in deselected state
     */
    public Color getButtonDeselectedColor()
    {
        return buttonDeselectedColor;
    }

    /**
     * Set the background color of the buttons for the deselected state
     * @param buttonDeselectedColor - the background color of the buttons for 
     * the deselected state
     */    
    public void setButtonDeselectedColor(Color buttonDeselectedColor)
    {
        this.buttonDeselectedColor = buttonDeselectedColor;
        for (Iterator<MyContainer> it = data.iterator(); it.hasNext();)
        {
            MyContainer con = it.next();
            con.button.setNotSelectedColor(buttonDeselectedColor);
        }
        this.revalidate();
        this.repaint();

    }

    /**
     * Container for component, button text and button
     */
    private class MyContainer
    {

        protected Component comp;
        protected String text;
        protected MyBorderedToggleButton button;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane1 = new javax.swing.JScrollPane();
        panButtons = new javax.swing.JPanel();
        panContent = new javax.swing.JPanel();

        setLayout(new java.awt.GridBagLayout());

        jScrollPane1.setBorder(null);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(5, 55));
        jScrollPane1.setOpaque(false);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(100, 55));

        panButtons.setMinimumSize(new java.awt.Dimension(100, 20));
        panButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));
        jScrollPane1.setViewportView(panButtons);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        add(jScrollPane1, gridBagConstraints);

        panContent.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        add(panContent, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panButtons;
    private javax.swing.JPanel panContent;
    // End of variables declaration//GEN-END:variables
}
