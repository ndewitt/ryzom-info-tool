/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import ryzominfotool.gui.utils.*;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.regex.PatternSyntaxException;
import javax.swing.JTable;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.ItemDbHandler;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.borders.CustomBorder;

/**
 * A panel containing a Inventory
 * @author Niels-Peter de Witt
 */
public class InventoryPanel extends javax.swing.JPanel
{

    private InventoryTableModel model = new InventoryTableModel();
    private CompactInventoryTableModel comModel = new CompactInventoryTableModel();
    private JTable comTableContent = new JTable();
    private InventoryTableHeaderRenderer invTblHeaderRenderer = new InventoryTableHeaderRenderer();
    private List<Item> currentItems = new Vector();
    private Language curLanguage = Language.English;
    private InventoryTableCellRenderer invCellRenderer = new InventoryTableCellRenderer();

    /** Creates new form InventoryPanel */
    public InventoryPanel()
    {
        initComponents();
        chkCompact.setSelected(false);
        setView(false);
        jPanel2ComponentResized(null);
        
    }

    /**
     * Sets the server tick for the renderer of store items
     * @param tick - the servertick string
     */
    public void setServerTick(String tick) {
        
        invCellRenderer.setServerTicks(tick);
    }    
    /**
     * Switch between compact and detailed view
     * @param isCompact - true for compact view
     */
    private void setView(boolean isCompact)
    {
        if (isCompact)
        {
            comTableContent.setModel(comModel);
            comTableContent.setRowHeight(41);
            comTableContent.setDefaultRenderer(Object.class, new CompactInventoryTableCellRenderer());
            comTableContent.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            comTableContent.setTableHeader(null);
            int cols = comTableContent.getColumnCount();
            for (int i = 0; i < cols; i++)
            {
                comTableContent.getColumnModel().getColumn(i).setMaxWidth(41);
                comTableContent.getColumnModel().getColumn(i).setMinWidth(41);
            }
            jScrollPane1.setViewportView(comTableContent);
        }
        else
        {
            tblContent.setModel(model);
            tblContent.setDefaultRenderer(Object.class, invCellRenderer);
            tblContent.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            tblContent.getTableHeader().setDefaultRenderer(invTblHeaderRenderer);
            jScrollPane1.setViewportView(tblContent);
        }
    }

    /**
     * Sets the content of items to display. The regular expression filter is
     * applied in here
     * @param items - the items to set
     */
    public void setContent(List<Item> items)
    {
        currentItems.clear();
        currentItems.addAll(items);
        Comparator<Item> comp = new Comparator<Item>()
        {

            @Override
            public int compare(Item o1, Item o2)
            {
                return o1.getStat(ItemStats.itemId).compareTo(o2.getStat(ItemStats.itemId));
            }
        };
        Collections.sort(currentItems, comp);
        for (Iterator<Item> it = currentItems.iterator(); it.hasNext();)
        {
            Item item = it.next();
            String itemId = item.getStat(ItemStats.itemId);
            try
            {
                item.setStat(ItemStats.name, ItemDbHandler.getItemDescription(itemId, curLanguage));
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
            }
        }
        applyRegexprFilter();
    }

    /**
     * Sets the language of the panel
     * @param lan - new language
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblSearch.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblSearch", curLanguage, "Search"));
        chkUseRegExpr.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".chkUseRegExpr", curLanguage, "Use Reg. Expression"));
        chkCompact.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".chkCompact", curLanguage, "compact View"));
        invTblHeaderRenderer.setLanguage(curLanguage);
        for (Iterator<Item> it = currentItems.iterator(); it.hasNext();)
        {
            Item item = it.next();
            String itemId = item.getStat(ItemStats.itemId);
            try
            {
                item.setStat(ItemStats.name, ItemDbHandler.getItemDescription(itemId, curLanguage));
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
            }
        }
        invCellRenderer.setLanguage(curLanguage);
    }

    /**
     * applies the regualer expression filter
     */
    private void applyRegexprFilter()
    {
        String txt = txtRegExpr.getText();
        Vector<Item> newItems = new Vector<Item>();
        if (txt.length() > 0)
        {
            for (Item i : currentItems)
            {
                boolean matches = false;
                for (ItemStats st : ItemStats.values())
                {
                    String stat = i.getStat(st);
                    if (stat != null)
                    {
                        if (chkUseRegExpr.isSelected())
                        {
                            try {
                                matches |= stat.matches(txt);
                            } catch (PatternSyntaxException exc) { }
                        }
                        else
                        {
                            matches |= stat.toLowerCase().contains(txt.toLowerCase());
                        }
                    }
                }
                if (matches)
                {
                    newItems.add(i);
                }
            }
        }
        else
        {
            newItems.addAll(currentItems);
        }
        model.setItemList(newItems);
        comModel.setItemList(newItems);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        lblSearch = new javax.swing.JLabel();
        txtRegExpr = new javax.swing.JTextField();
        chkUseRegExpr = new javax.swing.JCheckBox();
        chkCompact = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblContent = new javax.swing.JTable();

        setBackground(new java.awt.Color(200, 255, 200));
        setBorder(new CustomBorder());
        setOpaque(false);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
        });
        setLayout(new java.awt.BorderLayout());

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        lblSearch.setText("Search: ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(lblSearch, gridBagConstraints);

        txtRegExpr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRegExprKeyReleased(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(txtRegExpr, gridBagConstraints);

        chkUseRegExpr.setText("Regular Expression");
        chkUseRegExpr.setOpaque(false);
        chkUseRegExpr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkUseRegExprActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(chkUseRegExpr, gridBagConstraints);

        chkCompact.setText("compact View");
        chkCompact.setOpaque(false);
        chkCompact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCompactActionPerformed(evt);
            }
        });
        jPanel1.add(chkCompact, new java.awt.GridBagConstraints());

        add(jPanel1, java.awt.BorderLayout.SOUTH);

        jPanel2.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel2ComponentResized(evt);
            }
        });
        jPanel2.setLayout(new java.awt.BorderLayout());

        jScrollPane1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jScrollPane1ComponentResized(evt);
            }
        });

        tblContent.setAutoCreateRowSorter(true);
        tblContent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblContent.setRowHeight(42);
        tblContent.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(tblContent);

        jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        add(jPanel2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
}//GEN-LAST:event_formMouseEntered

private void txtRegExprKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRegExprKeyReleased
    applyRegexprFilter();
}//GEN-LAST:event_txtRegExprKeyReleased

private void chkUseRegExprActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkUseRegExprActionPerformed
    applyRegexprFilter();
}//GEN-LAST:event_chkUseRegExprActionPerformed

private void chkCompactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCompactActionPerformed
    setView(chkCompact.isSelected());
}//GEN-LAST:event_chkCompactActionPerformed

private void jScrollPane1ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jScrollPane1ComponentResized
}//GEN-LAST:event_jScrollPane1ComponentResized

private void jPanel2ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel2ComponentResized
    comModel.setColumnCount((jPanel2.getWidth() / 41) - 1);
    for (int i = 0; i < comTableContent.getColumnCount(); i++)
    {
        comTableContent.getColumnModel().getColumn(i).setMaxWidth(41);
        comTableContent.getColumnModel().getColumn(i).setMinWidth(41);
    }
}//GEN-LAST:event_jPanel2ComponentResized

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkCompact;
    private javax.swing.JCheckBox chkUseRegExpr;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JTable tblContent;
    private javax.swing.JTextField txtRegExpr;
    // End of variables declaration//GEN-END:variables
}
