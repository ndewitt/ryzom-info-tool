/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 * This panel contains a diagram with the value to display. Rubbarn value (extra
 * 20%) can be switched on
 * @author Niels-Peter de Witt
 */
public class StatusDisplay extends JPanel
{

    private double shownValue = 0.0;
    private double shownRubbarnValue = 0.0;
    private boolean showRubbarnValue = false;

    public StatusDisplay()
    {
        this.setPreferredSize(new Dimension(150,20));
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        Graphics2D g2d = (Graphics2D) g;
        int w = this.getWidth() - 7;
        int h = this.getHeight() - 3;

        g2d.drawRect(0, 0, w + 2, h + 2);
        int maxShownValue = (isShowRubbarnValue()) ? 120 : 100;
        double oneTick = (double) w / (double) maxShownValue;

        g2d.setColor(Color.lightGray);
        int value = (int) (shownValue * oneTick);
        g2d.fillRect(1, 1, value, h);
        if (isShowRubbarnValue())
        {
            g2d.setColor(Color.gray);
            int rubbarnValue = (int) (shownRubbarnValue * oneTick);
            g2d.fillRect(value + 1, 1, rubbarnValue - value - 1, h);
        }
        g2d.setColor(Color.black);
        String txt = shownValue + "";
        if (isShowRubbarnValue())
        {
            txt += " (" + shownRubbarnValue + ")";
        }
        g2d.drawString(txt, 5, h - 2);
    }

    public double getShownValue()
    {
        return shownValue;
    }

    public void setShownValue(double shownValue)
    {
        this.shownValue = (double) (Math.round(shownValue * 10.0) / 10.0);
        this.shownRubbarnValue = (double) ((int) (shownValue * 1.2 * 10.0) / 10.0);
    }

    public boolean isShowRubbarnValue()
    {
        return showRubbarnValue;
    }

    public void setShowRubbarnValue(boolean showRubbarnValue)
    {
        this.showRubbarnValue = showRubbarnValue;
    }
}
