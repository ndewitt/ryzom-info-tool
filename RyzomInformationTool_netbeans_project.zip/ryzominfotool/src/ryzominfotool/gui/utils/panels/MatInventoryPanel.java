/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JList;
import ryzominfotool.gui.utils.*;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.regex.PatternSyntaxException;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableColumn;
import ryzominfotool.Enums.Categorie;
import ryzominfotool.Enums.Language;
import ryzominfotool.utils.Material;
import ryzominfotool.db.ItemDbHandler;
import ryzominfotool.db.MaterialDbHandler;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.borders.CustomBorder;

/**
 * A Inventory Panel especially for Materials only
 * @author Niels-Peter de Witt
 */
public class MatInventoryPanel extends javax.swing.JPanel
{

    private InventoryTableModel model = new InventoryTableModel();
    private StatusPanel statusPanel1 = new StatusPanel();
    private List<Item> currentItems = new Vector();
    private List<Material> currentMaterials = new Vector();
    private Language curLanguage = Language.English;
    private InventoryTableHeaderRenderer invHeaderRenderer = new InventoryTableHeaderRenderer();
    private InventoryTableCellRenderer invCellRenderer = new InventoryTableCellRenderer();
    private DefaultListCellRenderer cmbCatListCellRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Categorie)
            {
                Categorie cat = (Categorie) value;
                String txt = TranslationDbHandler.getTranslation(Categorie.class.getName() + "." + cat.name(), curLanguage, cat.getCatName());
                lbl.setText(txt);
            }
            return lbl;
        }
    };

    /** Creates new form InventoryPanel */
    public MatInventoryPanel()
    {
        initComponents();
        panStatusPanelCont.add(statusPanel1, BorderLayout.CENTER);
        tblContent.setModel(model);
        tblContent.setDefaultRenderer(Object.class, invCellRenderer);

        tblContent.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblContent.getTableHeader().setDefaultRenderer(invHeaderRenderer);
        cmbCategories.removeAllItems();
        cmbCategories.setRenderer(cmbCatListCellRenderer);
        tblContent.getSelectionModel().addListSelectionListener(new ListSelectionListener()
        {

            @Override
            public void valueChanged(ListSelectionEvent e)
            {
                if (e.getValueIsAdjusting())
                {
                    return;
                }
                selectionChanged();
            }
        });
        setContent(currentItems);
    }

    /**
     * Sets the content of Items to display. The regular Expression filter will 
     * be applied on this list.
     * @param items - items to display
     */
    public void setContent(List<Item> items)
    {
        currentItems.clear();
        currentItems.addAll(items);
        for (Iterator<Item> it = currentItems.iterator(); it.hasNext();)
        {
            Item item = it.next();
            String itemId = item.getStat(ItemStats.itemId);
            try
            {
                item.setStat(ItemStats.name, ItemDbHandler.getItemDescription(itemId, curLanguage));
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
            }
        }
        applyRegexprFilter();
    }

    /**
     * applies the regular expression
     */
    private void applyRegexprFilter()
    {
        String txt = txtRegExpr.getText();
        Vector<Item> newItems = new Vector<Item>();
        if (txt.length() > 0)
        {
            for (Item i : currentItems)
            {
                boolean matches = false;
                for (ItemStats st : ItemStats.values())
                {
                    String stat = i.getStat(st);
                    if (stat != null)
                    {
                        if (chkUseRegExpr.isSelected())
                        {
                            try
                            {
                                matches |= stat.matches(txt);
                            }
                            catch (PatternSyntaxException exc)
                            {
                            }
                        }
                        else
                        {
                            matches |= stat.toLowerCase().contains(txt.toLowerCase());
                        }
                    }
                }
                if (matches)
                {
                    newItems.add(i);
                }
            }
        }
        else
        {
            newItems.addAll(currentItems);
        }
        model.setItemList(newItems);

    }

    /**
     * in case a selection has changed, the statuspanel with the mat states
     * will be updated
     */
    private void selectionChanged()
    {
        int row = tblContent.getSelectedRow();
        Categorie oldCat = (Categorie) cmbCategories.getSelectedItem();
        currentMaterials.clear();
        cmbCategories.removeAllItems();

        if (row >= 0 && row < model.getRowCount())
        {
            int col = -1;
            int i = 0;
            Enumeration<TableColumn> enu = tblContent.getColumnModel().getColumns();
            while (enu.hasMoreElements())
            {
                TableColumn tableColumn = enu.nextElement();
                InventoryColumnHeader ic = InventoryColumnHeader.valueOf(tableColumn.getHeaderValue().toString());
                if (InventoryColumnHeader.itemId.equals(ic))
                {
                    col = i;
                }
                i++;
            }
            if (col == -1)
            {
                return;
            }
            String selItemId = (String) tblContent.getValueAt(row, col);
            try
            {
                boolean lookupOldCatAsNewItem = false;
                List<Material> mats = MaterialDbHandler.getMats(selItemId);
                currentMaterials.addAll(mats);
                for (Material m : mats)
                {
                    Categorie cat = m.getCategorie();
                    cmbCategories.addItem(cat);
                    if (cat.equals(oldCat))
                    {
                        lookupOldCatAsNewItem = true;
                    }
                }
                if (lookupOldCatAsNewItem)
                {
                    cmbCategories.setSelectedItem(oldCat);
                }
                else
                {
                    if (cmbCategories.getItemCount() > 0)
                    {
                        cmbCategories.setSelectedIndex(0);
                    }
                }
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
                statusPanel1.setMaterial(null);
            }
        }
        else
        {
            statusPanel1.setMaterial(null);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panIventory = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblContent = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        lblSearch = new javax.swing.JLabel();
        txtRegExpr = new javax.swing.JTextField();
        chkUseRegExpr = new javax.swing.JCheckBox();
        panStatus = new javax.swing.JPanel();
        cmbCategories = new javax.swing.JComboBox();
        panStatusPanelCont = new javax.swing.JPanel();

        setBackground(new java.awt.Color(200, 255, 200));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
        });
        setLayout(new java.awt.GridBagLayout());

        panIventory.setBackground(new java.awt.Color(255, 255, 204));
        panIventory.setBorder(new CustomBorder());
        panIventory.setLayout(new java.awt.GridBagLayout());

        tblContent.setAutoCreateRowSorter(true);
        tblContent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblContent.setRowHeight(42);
        tblContent.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblContent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblContentMouseClicked(evt);
            }
        });
        tblContent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tblContentKeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(tblContent);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panIventory.add(jScrollPane1, gridBagConstraints);

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        lblSearch.setText("Search: ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(lblSearch, gridBagConstraints);

        txtRegExpr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRegExprKeyReleased(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(txtRegExpr, gridBagConstraints);

        chkUseRegExpr.setText("Regular Expression");
        chkUseRegExpr.setOpaque(false);
        chkUseRegExpr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkUseRegExprActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(chkUseRegExpr, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 5, 5);
        panIventory.add(jPanel1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(panIventory, gridBagConstraints);

        panStatus.setBackground(new java.awt.Color(255, 255, 204));
        panStatus.setBorder(new CustomBorder());
        panStatus.setLayout(new java.awt.GridBagLayout());

        cmbCategories.setBackground(new java.awt.Color(255, 255, 204));
        cmbCategories.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCategories.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoriesActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panStatus.add(cmbCategories, gridBagConstraints);

        panStatusPanelCont.setOpaque(false);
        panStatusPanelCont.setLayout(new java.awt.BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panStatus.add(panStatusPanelCont, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(panStatus, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
}//GEN-LAST:event_formMouseEntered

private void txtRegExprKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRegExprKeyReleased
    applyRegexprFilter();
}//GEN-LAST:event_txtRegExprKeyReleased

private void chkUseRegExprActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkUseRegExprActionPerformed
    applyRegexprFilter();
}//GEN-LAST:event_chkUseRegExprActionPerformed

private void tblContentKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblContentKeyTyped
}//GEN-LAST:event_tblContentKeyTyped

private void tblContentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblContentMouseClicked
}//GEN-LAST:event_tblContentMouseClicked

private void cmbCategoriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoriesActionPerformed
    Categorie cat = (Categorie) cmbCategories.getSelectedItem();
    Material setM = null;
    if (cat != null)
    {
        for (Material m : currentMaterials)
        {
            if (m.getCategorie().equals(cat))
            {
                setM = m;
            }
        }
    }
    statusPanel1.setMaterial(setM);
}//GEN-LAST:event_cmbCategoriesActionPerformed

    /**
     * Sets the language to use
     * @param lan - the language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblSearch.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblSearch", curLanguage, "Search:"));
        chkUseRegExpr.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".chkUseRegExpr", curLanguage, "Use Reg. Expression"));
        invHeaderRenderer.setLanguage(curLanguage);
        cmbCategories.repaint();
        statusPanel1.setLanguage(curLanguage);
        for (Iterator<Item> it = currentItems.iterator(); it.hasNext();)
        {
            Item item = it.next();
            String itemId = item.getStat(ItemStats.itemId);
            try
            {
                item.setStat(ItemStats.name, ItemDbHandler.getItemDescription(itemId, curLanguage));
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
            }
        }
        invCellRenderer.setLanguage(curLanguage);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkUseRegExpr;
    private javax.swing.JComboBox cmbCategories;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JPanel panIventory;
    private javax.swing.JPanel panStatus;
    private javax.swing.JPanel panStatusPanelCont;
    private javax.swing.JTable tblContent;
    private javax.swing.JTextField txtRegExpr;
    // End of variables declaration//GEN-END:variables
}
