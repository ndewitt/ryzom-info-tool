/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import java.awt.Component;
import ryzominfotool.gui.utils.*;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.swing.*;
import ryzominfotool.Enums.*;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.borders.CustomBorder2;

/**
 * Panel with filtering possibilites for Materials
 * Informs registered FilterChangedListeners of the changed MatFilter
 * Supports different languages
 * @author Niels-Peter de Witt
 */
public class MatFilterPanel extends javax.swing.JPanel
{

    private DefaultListModel model_race = new DefaultListModel();
    private DefaultListModel model_grade = new DefaultListModel();
    private DefaultListModel model_source = new DefaultListModel();
    private List<FilterChangedListener> listener = new Vector<FilterChangedListener>();
    private MatFilter filter = new MatFilter();
    private boolean isMatFilterAdjusting = false;
    private CustomBorder2 custBorder = new CustomBorder2();
    private Language curLanguage = Language.English;
    private DefaultListCellRenderer lstRaceListCellRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Race)
            {
                Race race = (Race) value;
                String txt = TranslationDbHandler.getTranslation(Race.class.getName() + "." + race.name(), curLanguage, race.name());
                lbl.setText(txt);
            }
            return lbl;
        }
    };
    private DefaultListCellRenderer lstGradeListCellRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Grade)
            {
                Grade grade = (Grade) value;
                String txt = TranslationDbHandler.getTranslation(Grade.class.getName() + "." + grade.name(), curLanguage, grade.name());
                lbl.setText(txt);
            }
            return lbl;
        }
    };
    private DefaultListCellRenderer lstSourceListCellRenderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Source)
            {
                Source src = (Source) value;
                String txt = TranslationDbHandler.getTranslation(Source.class.getName() + "." + src.name(), curLanguage, src.name());
                lbl.setText(txt);
            }
            return lbl;
        }
    };

    /** Creates new form MatFilterPanel */
    public MatFilterPanel()
    {
        initComponents();
        for (Race race : Race.values())
        {
            model_race.addElement(race);
        }
        lstRace.setCellRenderer(lstRaceListCellRenderer);
        for (Grade grade : Grade.values())
        {
            model_grade.addElement(grade);
        }
        lstGrade.setCellRenderer(lstGradeListCellRenderer);
        for (Source src : Source.values())
        {
            model_source.addElement(src);
        }
        lstSource.setCellRenderer(lstSourceListCellRenderer);
        lstRace.setModel(model_race);
        lstGrade.setModel(model_grade);
        lstSource.setModel(model_source);
        isMatFilterAdjusting = true;
        lstRace.setSelectionInterval(0, Race.values().length - 1);
        lstGrade.setSelectionInterval(0, Grade.values().length - 1);
        lstSource.setSelectionInterval(0, Source.values().length - 1);
        isMatFilterAdjusting = false;
    }

    /**
     * Informs FilterChangedListeners of a changed Filter
     */
    private void informFilterChanged()
    {
        if (isMatFilterAdjusting)
        {
            return;
        }
        getFilter();
        for (Iterator<FilterChangedListener> it = listener.iterator(); it.hasNext();)
        {
            it.next().filterChanged(filter);
        }
    }

    /**
     * Sets the language to use
     * @param lan - new language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblTitleFilterBy.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTitleFilterBy", curLanguage, "Filter by"));
        lblTitleGrade.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTitleGrade", curLanguage, "Grade"));
        lblTitleRace.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTitleRace", curLanguage, "Race"));
        lblTitleSource.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTitleSource", curLanguage, "Source"));

    }

    /**
     * Adds a FilterChangedListener
     * @param l - new listener
     */
    public void addFilterChangedListener(FilterChangedListener l)
    {
        listener.add(l);
    }

    /**
     * removes a FilterChangedListener
     * @param l - listener to remove
     */
    public void removeFilterChangedListener(FilterChangedListener l)
    {
        listener.remove(l);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstGrade = new javax.swing.JList();
        lblTitleGrade = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstRace = new javax.swing.JList();
        lblTitleRace = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstSource = new javax.swing.JList();
        lblTitleSource = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblTitleFilterBy = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 204));
        setLayout(new java.awt.GridBagLayout());

        jPanel1.setBorder(custBorder);
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setBorder(null);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(60, 120));
        jScrollPane1.setOpaque(false);

        lstGrade.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        lstGrade.setMaximumSize(new java.awt.Dimension(60, 60));
        lstGrade.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstGradeValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(lstGrade);

        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        lblTitleGrade.setBackground(new java.awt.Color(255, 255, 204));
        lblTitleGrade.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitleGrade.setText("Grade");
        lblTitleGrade.setOpaque(true);
        jPanel1.add(lblTitleGrade, java.awt.BorderLayout.PAGE_START);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(jPanel1, gridBagConstraints);

        jPanel2.setBorder(custBorder);
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new java.awt.BorderLayout());

        jScrollPane2.setBorder(null);
        jScrollPane2.setMinimumSize(new java.awt.Dimension(60, 120));
        jScrollPane2.setOpaque(false);

        lstRace.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        lstRace.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstRaceValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(lstRace);

        jPanel2.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        lblTitleRace.setBackground(new java.awt.Color(255, 255, 204));
        lblTitleRace.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitleRace.setText("Race");
        lblTitleRace.setOpaque(true);
        jPanel2.add(lblTitleRace, java.awt.BorderLayout.PAGE_START);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(jPanel2, gridBagConstraints);

        jPanel3.setBorder(custBorder);
        jPanel3.setOpaque(false);
        jPanel3.setLayout(new java.awt.BorderLayout());

        jScrollPane3.setBorder(null);
        jScrollPane3.setMinimumSize(new java.awt.Dimension(60, 120));
        jScrollPane3.setOpaque(false);

        lstSource.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        lstSource.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstSourceValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(lstSource);

        jPanel3.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        lblTitleSource.setBackground(new java.awt.Color(255, 255, 204));
        lblTitleSource.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitleSource.setText("Source");
        lblTitleSource.setOpaque(true);
        jPanel3.add(lblTitleSource, java.awt.BorderLayout.PAGE_START);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(jPanel3, gridBagConstraints);

        jPanel4.setBorder(custBorder);
        jPanel4.setOpaque(false);
        jPanel4.setLayout(new java.awt.BorderLayout());

        lblTitleFilterBy.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitleFilterBy.setText("Filter by");
        jPanel4.add(lblTitleFilterBy, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jPanel4, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void lstGradeValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_lstGradeValueChanged
    informFilterChanged();
}//GEN-LAST:event_lstGradeValueChanged

private void lstRaceValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_lstRaceValueChanged
    informFilterChanged();
}//GEN-LAST:event_lstRaceValueChanged

private void lstSourceValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_lstSourceValueChanged
    informFilterChanged();
}//GEN-LAST:event_lstSourceValueChanged
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblTitleFilterBy;
    private javax.swing.JLabel lblTitleGrade;
    private javax.swing.JLabel lblTitleRace;
    private javax.swing.JLabel lblTitleSource;
    private javax.swing.JList lstGrade;
    private javax.swing.JList lstRace;
    private javax.swing.JList lstSource;
    // End of variables declaration//GEN-END:variables

    /**
     * gets the current MatFilter instance
     * @return the current MatFilter instance
     */
    public MatFilter getFilter()
    {
        int[] grades = lstGrade.getSelectedIndices();
        int[] races = lstRace.getSelectedIndices();
        int[] sources = lstSource.getSelectedIndices();
        filter.selectedGrades = new Grade[grades.length];
        filter.selectedRaces = new Race[races.length];
        filter.selectedSources = new Source[sources.length];
        for (int i = 0; i < grades.length; i++)
        {
            filter.selectedGrades[i] = (Grade) model_grade.get(grades[i]);
        }
        for (int i = 0; i < races.length; i++)
        {
            filter.selectedRaces[i] = (Race) model_race.get(races[i]);
        }
        for (int i = 0; i < sources.length; i++)
        {
            filter.selectedSources[i] = (Source) model_source.get(sources[i]);
        }
        return filter;
    }

    /**
     * Sets a MatFilter - not supported yet
     * @param filter - the filter to set
     */
    public void setFilter(MatFilter filter)
    {
        this.filter = filter;
        throw new UnsupportedOperationException("not_yet_implemented");
    }
}
