/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils.panels;

import ryzominfotool.gui.utils.*;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.text.NumberFormatter;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.TranslationDbHandler;

/**
 * A Panel to display Crystall amounts by a list of Items
 * This panel supports different languages
 * 
 * @author  Niels-Peter de Witt
 */
public class CrystalViewPanel extends javax.swing.JPanel
{

    private NumberFormatter nf = new NumberFormatter(new DecimalFormat("###,###,###.#"));
    private final String notAvail = "---";
    private Language curLanguage = Language.English;

    /** Creates new form CrystalViewPanel */
    public CrystalViewPanel()
    {
        initComponents();
        analyseCrystalls(null);
    }

    /**
     * Analysis the list of items for crystall and displays the amount of
     * Q50-Q250 crystals
     * 
     * @param allItems - items to analyse
     */
    public void analyseCrystalls(List<Item> allItems)
    {

        lblQ50Crys.setText(notAvail);
        lblQ100Crys.setText(notAvail);
        lblQ150Crys.setText(notAvail);
        lblQ200Crys.setText(notAvail);
        lblQ250Crys.setText(notAvail);
        lblQ50Stacks.setText(notAvail);
        lblQ100Stacks.setText(notAvail);
        lblQ150Stacks.setText(notAvail);
        lblQ200Stacks.setText(notAvail);
        lblQ250Stacks.setText(notAvail);
        int countCrysQ50 = 0;
        int countCrysQ100 = 0;
        int countCrysQ150 = 0;
        int countCrysQ200 = 0;
        int countCrysQ250 = 0;

        if (allItems != null)
        {

            for (Item it : allItems)
            {
                if (it.getStat(ItemStats.itemId).equalsIgnoreCase("ixpca01"))
                {
                    String qual = it.getStat(ItemStats.q);
                    String amount = it.getStat(ItemStats.s);
                    int stack = 0;
                    if (amount == null)
                    {
                        stack = 1;
                    }
                    else
                    {
                        try
                        {
                            stack = Integer.parseInt(amount);
                        }
                        catch (NumberFormatException exc)
                        {
                            stack = 0;
                        }
                    }
                    if (qual.equals("50"))
                    {
                        countCrysQ50 += stack;
                    }
                    else if (qual.equals("100"))
                    {
                        countCrysQ100 += stack;
                    }
                    if (qual.equals("150"))
                    {
                        countCrysQ150 += stack;
                    }
                    if (qual.equals("200"))
                    {
                        countCrysQ200 += stack;
                    }
                    if (qual.equals("250"))
                    {
                        countCrysQ250 += stack;
                    }
                }
            }
            double stackQ50 = (countCrysQ50 / 999.0);
            double stackQ100 = (countCrysQ100 / 999.0);
            double stackQ150 = (countCrysQ150 / 999.0);
            double stackQ200 = (countCrysQ200 / 999.0);
            double stackQ250 = (countCrysQ250 / 999.0);
            lblQ50Crys.setText(parseNumber(countCrysQ50));
            lblQ100Crys.setText(parseNumber(countCrysQ100));
            lblQ150Crys.setText(parseNumber(countCrysQ150));
            lblQ200Crys.setText(parseNumber(countCrysQ200));
            lblQ250Crys.setText(parseNumber(countCrysQ250));
            lblQ50Stacks.setText(parseNumber(stackQ50));
            lblQ100Stacks.setText(parseNumber(stackQ100));
            lblQ150Stacks.setText(parseNumber(stackQ150));
            lblQ200Stacks.setText(parseNumber(stackQ200));
            lblQ250Stacks.setText(parseNumber(stackQ250));
        }
    }

    /**
     * parses a int value into a string
     * 
     * @param value - the int value to parste
     * @return A formatted String representation of the int value
     */
    private String parseNumber(int value)
    {
        String rv = "";
        try
        {
            rv = nf.valueToString(value);
        }
        catch (Exception exc)
        {
            rv = "";
        }

        return rv;
    }

    /**
     * parses a double value into a string
     * 
     * @param value - the double value to parste
     * @return A formatted String representation of the double value
     */
    private String parseNumber(double value)
    {
        String rv = "";
        try
        {
            rv = nf.valueToString(value);
        }
        catch (Exception exc)
        {
            rv = "";
        }

        return rv;
    }

    /**
     * Set the language to use for display
     * @param lan - the language to use
     */
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblTxtAmount.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtAmount", curLanguage, "Amount"));
        lblTxtQ50.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtQ50", curLanguage, "Q150 Crystals"));
        lblTxtQ100.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtQ100", curLanguage, "Q100 Crystals"));
        lblTxtQ150.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtQ150", curLanguage, "Q150 Crystals"));
        lblTxtQ200.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtQ200", curLanguage, "Q200 Crystals"));
        lblTxtQ250.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtQ250", curLanguage, "Q250 Crystals"));
        lblTxtStacks.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblTxtStacks", curLanguage, "Stacks"));
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        lblEmpty = new javax.swing.JLabel();
        lblTxtAmount = new javax.swing.JLabel();
        lblTxtStacks = new javax.swing.JLabel();
        lblTxtQ50 = new javax.swing.JLabel();
        lblQ50Crys = new javax.swing.JLabel();
        lblQ50Stacks = new javax.swing.JLabel();
        lblTxtQ100 = new javax.swing.JLabel();
        lblQ100Crys = new javax.swing.JLabel();
        lblQ100Stacks = new javax.swing.JLabel();
        lblTxtQ150 = new javax.swing.JLabel();
        lblQ150Crys = new javax.swing.JLabel();
        lblQ150Stacks = new javax.swing.JLabel();
        lblTxtQ200 = new javax.swing.JLabel();
        lblQ200Crys = new javax.swing.JLabel();
        lblQ200Stacks = new javax.swing.JLabel();
        lblTxtQ250 = new javax.swing.JLabel();
        lblQ250Crys = new javax.swing.JLabel();
        lblQ250Stacks = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblEmpty, gridBagConstraints);

        lblTxtAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTxtAmount.setText("Amount");
        lblTxtAmount.setMinimumSize(new java.awt.Dimension(100, 14));
        lblTxtAmount.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtAmount, gridBagConstraints);

        lblTxtStacks.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTxtStacks.setText("Stacks");
        lblTxtStacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblTxtStacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtStacks, gridBagConstraints);

        lblTxtQ50.setText("Q50 Crystalls");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtQ50, gridBagConstraints);

        lblQ50Crys.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ50Crys.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ50Crys.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ50Crys.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ50Crys, gridBagConstraints);

        lblQ50Stacks.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ50Stacks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ50Stacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ50Stacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ50Stacks, gridBagConstraints);

        lblTxtQ100.setText("Q100 Crystalls");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtQ100, gridBagConstraints);

        lblQ100Crys.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ100Crys.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ100Crys.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ100Crys.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ100Crys, gridBagConstraints);

        lblQ100Stacks.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ100Stacks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ100Stacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ100Stacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ100Stacks, gridBagConstraints);

        lblTxtQ150.setText("Q150 Crystalls");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtQ150, gridBagConstraints);

        lblQ150Crys.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ150Crys.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ150Crys.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ150Crys.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ150Crys, gridBagConstraints);

        lblQ150Stacks.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ150Stacks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ150Stacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ150Stacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ150Stacks, gridBagConstraints);

        lblTxtQ200.setText("Q200 Crystalls");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtQ200, gridBagConstraints);

        lblQ200Crys.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ200Crys.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ200Crys.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ200Crys.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ200Crys, gridBagConstraints);

        lblQ200Stacks.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ200Stacks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ200Stacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ200Stacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ200Stacks, gridBagConstraints);

        lblTxtQ250.setText("Q250 Crystalls");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblTxtQ250, gridBagConstraints);

        lblQ250Crys.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ250Crys.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ250Crys.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ250Crys.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ250Crys, gridBagConstraints);

        lblQ250Stacks.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblQ250Stacks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblQ250Stacks.setMinimumSize(new java.awt.Dimension(100, 14));
        lblQ250Stacks.setPreferredSize(new java.awt.Dimension(100, 14));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(lblQ250Stacks, gridBagConstraints);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        add(jPanel1, gridBagConstraints);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.weighty = 1.0;
        add(jPanel2, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblEmpty;
    private javax.swing.JLabel lblQ100Crys;
    private javax.swing.JLabel lblQ100Stacks;
    private javax.swing.JLabel lblQ150Crys;
    private javax.swing.JLabel lblQ150Stacks;
    private javax.swing.JLabel lblQ200Crys;
    private javax.swing.JLabel lblQ200Stacks;
    private javax.swing.JLabel lblQ250Crys;
    private javax.swing.JLabel lblQ250Stacks;
    private javax.swing.JLabel lblQ50Crys;
    private javax.swing.JLabel lblQ50Stacks;
    private javax.swing.JLabel lblTxtAmount;
    private javax.swing.JLabel lblTxtQ100;
    private javax.swing.JLabel lblTxtQ150;
    private javax.swing.JLabel lblTxtQ200;
    private javax.swing.JLabel lblTxtQ250;
    private javax.swing.JLabel lblTxtQ50;
    private javax.swing.JLabel lblTxtStacks;
    // End of variables declaration//GEN-END:variables
}
