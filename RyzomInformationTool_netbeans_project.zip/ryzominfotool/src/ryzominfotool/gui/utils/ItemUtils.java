/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.sql.SQLException;
import org.jdom.Element;
import java.util.*;
import ryzominfotool.Enums.ItemCategories;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.ItemDbHandler;

/**
 * A utility collection for handling Items
 * @author Niels-Peter De Witt
 */
public class ItemUtils
{

    /**
     * Place where the Item is located. All is a general location, that includes
     * all others
     */
    public enum ItemPlaces
    {

        All("All"),
        BagItems("Bag"),
        Pet1Items("Pet 1"),
        Pet2Items("Pet 2"),
        Pet3Items("Pet 3"),
        Pet4Items("Pet 4"),
        RoomItems("Room"),
        StoreItems("Store");
        
        private String defaultEnName = "";
        ItemPlaces(String defaultEnName) {
            this.defaultEnName = defaultEnName;
        }
        public String getDefaultEnName() {
            return defaultEnName;
        }
    }

    /**
     * Category of the item.
     */
    public enum ItemCats
    {

        All("All"),
        Armor("Armor"),
        Jewels("Jewels"),
        Weapons("Weapons"),
        Material("Materials"),
        LootMaterial("Loot Materials"),
        ForageMaterial("Forage Materials"),
        Tickets("Tickets"),
        Crystalls("Crystalls"),
        Flowers("Flowers"),
        Other("Other");
        private String defaultEnName = "";
        ItemCats(String defaultEnName) {
            this.defaultEnName = defaultEnName;
        }
        public String getDefaultEnName() {
            return defaultEnName;
        }
        

    }

    /**
     * Fills a list of Items given by a Element that contains children of name
     * "item". The storage location is added to the items.
     * 
     * @param elem - XML element to analyse
     * @param itemList - the list, where to add the found items
     * @param location - the location where this item was found
     */
    static public void fillList(Element elem, Vector<Item> itemList, String location)
    {
        if (elem == null || itemList == null)
        {
            return;
        }
        java.util.List<Element> itEles = elem.getChildren("item");
        for (Element e : itEles)
        {
            Item i = buildItem(e);
            i.setStat(ItemStats.location, location);
            itemList.add(i);
        }
    }

    /**
     * Creates out of a XML-Item a Item
     * @param item - the xml item
     * @return the Item
     */
    static public Item buildItem(Element item)
    {
        Item rv = new Item();
        for (ItemStats stats : ItemStats.values())
        {
            String val = item.getAttributeValue(stats.name());

            rv.setStat(stats, val);
        }
        String itemId = item.getValue().replace(".sitem", "");
        rv.setStat(ItemStats.itemId, itemId);
        try
        {
            rv.setStat(ItemStats.name, ItemDbHandler.getItemDescription(itemId, Language.English));
        }
        catch (SQLException exc)
        {
            exc.printStackTrace();
        }
        Object itemText = rv.getStat(ItemStats.text);
        if (itemText != null)
        {
            rv.setStat(ItemStats.text, ((String) itemText).replace("%mfc", ""));
        }
        return rv;
    }

    /**
     * Filters a given list by an item category
     * @param orgList - the orignal list to filter
     * @param filterCat - the category to filter by
     * @return a new list, with the filtered items. Maybe empty.
     */
    static public List<Item> filterList(List<Item> orgList, ItemCats filterCat)
    {
        Vector<Item> rv = new Vector();
        for (Iterator<Item> it = orgList.iterator(); it.hasNext();)
        {
            Item i = it.next();
            ItemCategories ic = getCategorieOfItem(i.getStat(ItemStats.itemId));
            boolean addItem = false;
            switch (filterCat)
            {
                case All:
                    addItem = true;
                    break;
                case Armor:
                    addItem = ic.equals(ItemCategories.Equ_Armor) ||
                            ic.equals(ItemCategories.Equ_Shield) ||
                            ic.equals(ItemCategories.Equ_HeavyArmor) ||
                            ic.equals(ItemCategories.Equ_LightArmor) ||
                            ic.equals(ItemCategories.Equ_MediumArmor);
                    break;
                case Crystalls:
                    addItem = ic.equals(ItemCategories.Crystall);
                    break;
                case Flowers:
                    addItem = ic.equals(ItemCategories.Flowers);
                    break;
                case ForageMaterial:
                    addItem = ic.equals(ItemCategories.ForageMat);
                    break;
                case Jewels:
                    addItem = ic.equals(ItemCategories.Equ_Jewels);
                    break;
                case LootMaterial:
                    addItem = ic.equals(ItemCategories.LootMat);
                    break;
                case Material:
                    addItem = ic.equals(ItemCategories.ForageMat) ||
                            ic.equals(ItemCategories.LootMat);
                    break;
                case Tickets:
                    addItem = ic.equals(ItemCategories.Ticket);
                    break;
                case Weapons:
                    addItem = ic.equals(ItemCategories.Equ_Weapon) ||
                            ic.equals(ItemCategories.Equ_Ranged) ||
                            ic.equals(ItemCategories.Equ_Ammo);
                    break;
                case Other:
                    addItem = ic.equals(ItemCategories.Equipment) ||
                            ic.equals(ItemCategories.Mektoub) ||
                            ic.equals(ItemCategories.Not_definable);
                    break;
            }
            if (addItem)
            {
                rv.add(i);
            }
        }

        return rv;
    }
    

    /**
     * Calculates the category of an item by its itemId
     * @param itemCode - the itemId
     * @return the Category the itemId matches.
     */
    public static ItemCategories getCategorieOfItem(String itemCode)
    {
        ItemCategories rv = ItemCategories.Not_definable;
        if (itemCode.startsWith("ic"))
        {
            rv = ItemCategories.Equipment;
            if (itemCode.charAt(3) == 'j')
            {
                rv = ItemCategories.Equ_Jewels;
            }
            else if (itemCode.charAt(3) == 'r')
            {
                rv = ItemCategories.Equ_Ranged;
            }
            else if (itemCode.charAt(3) == 'p')
            {
                rv = ItemCategories.Equ_Ammo;
            }
            else if (itemCode.charAt(3) == 'm')
            {
                rv = ItemCategories.Equ_Weapon;
            }
            else if (itemCode.charAt(3) == 's')
            {
                rv = ItemCategories.Equ_Shield;
            }
            else if (itemCode.charAt(3) == 'a')
            {
                rv = ItemCategories.Equ_Armor;
                if (itemCode.charAt(4) == 'l')
                {
                    rv = ItemCategories.Equ_LightArmor;
                }
                else if (itemCode.charAt(4) == 'm')
                {
                    rv = ItemCategories.Equ_MediumArmor;
                }
                else if (itemCode.charAt(4) == 'h')
                {
                    rv = ItemCategories.Equ_HeavyArmor;
                }
            }
        }
        else if (itemCode.startsWith("tp"))
        {
            rv = ItemCategories.Ticket;
        }
        else if (itemCode.startsWith("ixpca"))
        {
            rv = ItemCategories.Crystall;
        }
        else if (itemCode.startsWith("ipoc"))
        {
            rv = ItemCategories.Flowers;
        }
        else if (itemCode.startsWith("ia"))
        {
            rv = ItemCategories.Mektoub;
        }
        else if (itemCode.startsWith("m0"))
        {
            if (itemCode.contains("dxa"))
            {
                rv = ItemCategories.ForageMat;
            }
            else
            {
                rv = ItemCategories.LootMat;
            }

        }
        else
        {
            rv = ItemCategories.Not_definable;
        }
        return rv;
    }    
}
