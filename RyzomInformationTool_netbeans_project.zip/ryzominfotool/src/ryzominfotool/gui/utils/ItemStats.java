/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

/**
 * The Stats an item can have. They are based on the Ryzom API for Item, with 
 * additional data for name and location 
 * @author Niels-Peter De Witt
 */
public enum ItemStats
{
    /* not API stats */

    icon,
    itemId,
    name,
    /* API stats */
    slot, //: the position of the item in the inventory
    text, //: the text specified by the crafter
    s, //: stack size
    c, //: color
    q, //: quality
    sap, //: 0 means no sap(""), 1 mean sap icon
    w, //: weight
    hp, //: hp of the item (between 0 and dur)
    dur, //: durability of the item
    sl, //: sap load
    csl, //: current sap load
    hpb, //: hp buff
    sab, //: sap buff
    stb, //: sta buff
    fob, //: focus buff
    hr, //: hit rate
    r, //: range
    dm, //: dodge modifier
    pm, //: parry modifier
    adm, //: adversary dodge modifier
    apm, //: adversary parry modifier
    pf, //: protection factor
    msp, //: max slashing protection
    mbp, //: max blunt protection
    mpp, //: max piercing protection
    e, //: energy of the item (b=basic f=fine c=choice e=excelent s=supreme)
    //special parameters: 
    part, //: to determine where the item is in the body
    price, //: price of the item in a store    
    in_sell_since, // stored since server Tick (stored for 7 Days
    continent, // stored in continent
    location;
}