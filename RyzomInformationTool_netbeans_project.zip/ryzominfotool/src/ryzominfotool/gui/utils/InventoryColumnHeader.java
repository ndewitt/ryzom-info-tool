/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

/**
 * Enum used for Table Header for Inventory Panels
 * 
 * @author Niels-Peter de Witt
 */
public enum InventoryColumnHeader
{

    itemId("Item"),
    name("Name"),
    amount("Amount"),
    text("Crafter text"),
    quality("Quality"),
    weight("Weight"),
    duration("Duration"),
    sapLoad("Sap Load"),
    hpb("HP Buff"),
    sab("Sap Buff"),
    stb("Sta. Buff"),
    fob("Foc. Buff"),
    hr("Hitrate"),
    range("Range"),
    dodge("Dodge"),
    parry("Parry"),
    adodge("Adv. Dodge"),
    aparry("Adv. Parry"),
    protf("Prot. Factor"),
    msp("Max Slash Prot."),
    mbp("Max Blunt Prot."),
    mpp("Max Pierce Prot."),
    itemClass("Class"),
    part("Part"),
    price("Price"),
    sold_in("Sold in"), 
    continent("Continent"), // stored in continent
    location("Location");
    
    private String defaultEnName = "";
    InventoryColumnHeader(String defaultEnName) {
        this.defaultEnName = defaultEnName;
    }
    
    public String getDefaultEnName() {
        return defaultEnName;
    }
}

