/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.util.List;
import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import ryzominfotool.utils.*;

/**
 * A TableModel for Materials
 * @author Niels-Peter de Witt
 */
public class MatTableModel extends AbstractTableModel
{

    private Vector<Material> data = new Vector<Material>();
    private String[] columnNames = new String[]
    {
        "Name",
        "Grade",
        "Race",
        "Color",
        "Max_Level"
    };

    /**
     * Constructs a new TableModel
     */ 
    public MatTableModel()
    {
        super();
        data.clear();
    }

    @Override
    public String getColumnName(int col)
    {
        return columnNames[col].toString();
    }

    @Override
    public int getRowCount()
    {
        return data.size();
    }

    @Override
    public int getColumnCount()
    {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col)
    {
        return data.get(row);
    }

    @Override
    public boolean isCellEditable(int row, int col)
    {
        return false;
    }

    @Override
    public void setValueAt(Object value, int row, int col)
    {
    }

    /**
     * Sets the new List of Materials
     * @param mats - new list of Materials
     */
    public void setList(List<Material> mats)
    {
        data.clear();
        data.addAll(mats);
        fireTableDataChanged();
    }

    /**
     * Clears the stored list of materials
     */
    public void clearList()
    {
        data.clear();
        fireTableDataChanged();
    }
}
