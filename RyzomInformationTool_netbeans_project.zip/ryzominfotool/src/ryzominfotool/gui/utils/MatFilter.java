/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.*;
import ryzominfotool.utils.Material;
/**
 * A Material filter, where Materials can be filter by a combination of
 * Races, Grades and Sources.
 * TODO: make selectedXXX with Accessor methods
 * @author Niels-Peter de Witt
 */
public class MatFilter
{

    public Race[] selectedRaces = new Race[0];
    public Grade[] selectedGrades = new Grade[0];
    public Source[] selectedSources = new Source[0];

    /**
     * Applys a MatFilter onto a list of Materials.
     * @param filter - the filter to apply
     * @param unfiltered - the list to filter
     * @return a filtered list
     */
    public static List<Material> applyFilter(MatFilter filter, List<Material> unfiltered)
    {
        java.util.List<Material> tmpList = new Vector<Material>();
        if (unfiltered != null)
        {
            for (Iterator<Material> it = unfiltered.iterator(); it.hasNext();)
            {
                Material m = it.next();
                if (filter != null)
                {
                    boolean filterAcceptedGrade = false;
                    boolean filterAcceptedRace = false;
                    boolean filterAcceptedSource = false;
                    for (int i = 0; i < filter.selectedGrades.length && !filterAcceptedGrade; i++)
                    {
                        filterAcceptedGrade = m.getGrade().equals(filter.selectedGrades[i]);
                    }
                    for (int i = 0; i < filter.selectedRaces.length && !filterAcceptedRace; i++)
                    {
                        filterAcceptedRace = m.getRace().equals(filter.selectedRaces[i]);
                    }
                    for (int i = 0; i < filter.selectedSources.length && !filterAcceptedSource; i++)
                    {
                        filterAcceptedSource = m.getRtype().equals(filter.selectedSources[i]);
                    }
                    if (filterAcceptedGrade && filterAcceptedRace && filterAcceptedSource)
                    {
                        tmpList.add(m);
                    }
                }
                else
                {
                    // add all
                    tmpList.add(m);
                }
            }
        }

        return tmpList;
    }

}