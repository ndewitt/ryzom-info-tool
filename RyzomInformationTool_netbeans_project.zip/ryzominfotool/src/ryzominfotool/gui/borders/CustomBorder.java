/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui.borders;

import java.awt.*;
import java.awt.Insets;
import javax.swing.border.AbstractBorder;

/**
 * A border implementation, that paints a rounded border around the component.
 * The outer area is colored, as well as the inner area. Colors can be adjusted.
 * 
 * @author Niels-Peter de Witt
 */
public class CustomBorder extends AbstractBorder
{

    private Color[] colors2 = new Color[]
    {
        new Color(100, 0, 0),
        new Color(180, 100, 100),
        new Color(150, 0, 0),
        new Color(100, 0, 0)
    };
    private int sinkLevel = colors2.length;
    private Color innerBg = new Color(255, 255, 204);
    private Color outerBg = new Color(200, 255, 200);

    @Override
    public Insets getBorderInsets(Component c)
    {
        return new Insets(sinkLevel + 5, sinkLevel + 5, sinkLevel + 5, sinkLevel + 5);
    }

    @Override
    public Insets getBorderInsets(Component c, Insets i)
    {
        i.left = i.right = i.bottom = i.top = sinkLevel;
        return i;
    }

    @Override
    public boolean isBorderOpaque()
    {
        return false;
    }

    /**
     * Sets the inner background color
     * @param innerBg - the inner background color
     */
    public void setInnerBackground(Color innerBg)
    {
        this.innerBg = innerBg;
    }

    /**
     * Sets the outer background color
     * @param outerBg - the outer background color
     */
    public void setOuterBackground(Color outerBg)
    {
        this.outerBg = outerBg;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
    {
        g.translate(x, y);
        g.setColor(outerBg);
        g.fillRect(0, 0, w, h);
        g.setColor(innerBg);
        g.fillRoundRect(1, 1, w - 2, h - 2, 20, 20);
        for (int i = 0; i < sinkLevel; i++)
        {
            g.setColor(colors2[i]);
            g.drawRoundRect(i + 1, i + 1, w - 2 - (2 * i), h - 2 - (2 * i), 20 - 2 * i, 20 - 2 * i);
        }

        g.translate(-x, -y);
    }
}
