/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.gui;

import java.net.URL;
import javax.swing.JPanel;
import ryzominfotool.Enums.Language;

/**
 * A Plugins Main Class.
 * @author Niels-Peter de Witt
 */
public abstract class PluggableContent extends JPanel
{

    private FrameworkFrame frame = null;

    /**
     * Returns the display name for the Plugin in the Frame
     * @return the display name for the Plugin in the Frame
     */
    public abstract String getDisplayName();

    /**
     * Returns the URL to a help page. Overwrite it, if you have a help page.
     * @return By default null. Otherwise a valid URL.
     */
    public URL getHelpURL()
    {
        return null; 

    }

    /**
     * Returns the frame where the plugin is added to
     * @return the frame where the plugin is added to
     */
    public FrameworkFrame getFrame()
    {
        return frame;
    }

    /**
     * Sets the frame where the plugin is added to
     * @param frame - the frame where the plugin is added to
     */
    public void setFrame(FrameworkFrame frame)
    {
        this.frame = frame;
    }

    /**
     * Sets the current language
     * @param lan - the current language
     */
    public abstract void setLanguage(Language lan);

    /**
     * Returns a plugin Information like Name and Version
     * @return a plugin Information like Name and Version
     */
    public abstract String getPluginId();
}
