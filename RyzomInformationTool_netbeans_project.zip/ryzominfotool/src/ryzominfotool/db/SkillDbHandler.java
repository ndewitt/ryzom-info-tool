/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */


package ryzominfotool.db;

import java.sql.*;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.Language;

/**
 * Related to the Skill Entries in the database.
 * 
 * @author Niels-Peter de Witt
 */
public class SkillDbHandler {

    /**
     * Returns the Skill description based on the Language from the database
     * @param skillId - the skill id to retrive
     * @param lan - the language to retrieve the skill description for
     * @return The description
     * 
     * @throws java.sql.SQLException in case the description could not be retrieved
     */
    public static String getSkillDescription(String skillId, Language lan) throws SQLException
    {
        String rv = "";
        String lanCol = "";
        if (lan != null)
        {
            switch (lan)
            {
                case English:
                    lanCol = "local_en";
                    break;
                case French:
                    lanCol = "local_fr";
                    break;
                case German:
                    lanCol = "local_de";
                    break;
            }
        }
        else
        {
            lanCol = "local_en";
        }
        String sql = "SELECT " + lanCol + " FROM Skills WHERE skillid = ?";
        PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(sql);
        ps.setString(1, skillId);
        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            rv = rs.getString(1);
        }
        if (rv == null)
        {
            rv = "";
        }
        rs.close();
        ps.close();
        return rv;
    }
    
    public static List<String> getSkillIds() throws SQLException {
        List<String> rv = new Vector<String>();
                
        String sql = "SELECT skillid FROM Skills";
        PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            rv.add(rs.getString(1));
        }
        rs.close();
        ps.close();
        return rv;
    }
    
    public static void setSkillDescription(String skillId, Language lan, String description) throws SQLException {
        String lanCol = "";
        if (lan != null)
        {
            switch (lan)
            {
                case English:
                    lanCol = "local_en";
                    break;
                case French:
                    lanCol = "local_fr";
                    break;
                case German:
                    lanCol = "local_de";
                    break;
            }
        }
        else
        {
            lanCol = "local_en";
        }

        String sql = "UPDATE Skills SET "+lanCol+" = ? WHERE skillid = ?";        
        PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(sql);
        ps.setString(1, description);
        ps.setString(2, skillId);
        ps.executeUpdate();
        ps.close();        
    }
}
