/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */


package ryzominfotool.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.Language;

public class TranslationDbHandler {
    /**
     * Gets the text stored in DB for the given key and the useable langugage.
     * If the key is not present at the moment, the default value is stored
     * in the database as english value. The German and French values are 
     * the english value with a leading "DE_" or "FR_".
     * If defaultEnValue is null, an empty String will be added.
     * Precondition: The connection of the DerbyLoader is already opened.
     * 
     * @param key - the key to retrieve a text for
     * @param lan - the langugage to get the text for
     * @param defaultEnValue - the Default english value to use, in case no
     * value is in DB
     * @return Returns the stored translation out of the database, or if non is
     * present the default value.
     */
    public static String getTranslation(String key, Language lan, String defaultEnValue) {
        String rv = "";
        Connection con = DerbyLoader.getConnection(DerbyLoader.INFO_DB);
        String lanString = "value_";
        switch (lan) {
            case English: lanString += "en"; break;
            case German: lanString += "de"; break;
            case French: lanString += "fr"; break;
        }
        try {
            if (!con.isClosed()) {
                String checkSQL = "SELECT PropKey, "+lanString+" FROM Translations WHERE PropKey = '"+key+"'";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(checkSQL);
                if (rs.next()) {
                    rv = rs.getString(lanString);
                } else {
                    // prop not available. Add it with default value
                    String insVal = "INSERT INTO Translations (PropKey, value_en, value_de, value_fr) VALUES (?, ?,?,?)";
                    String val = (defaultEnValue != null)? defaultEnValue : "";
                    PreparedStatement ps = con.prepareStatement(insVal);
                    ps.setString(1, key);
                    ps.setString(2, val);
                    ps.setString(3, "DE_"+val);
                    ps.setString(4, "FR_"+val);
                    ps.execute();
                    rv = val;
                    ps.close();
                }
                rs.close();
                st.close();
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
        return rv;
    }
    
    public static void setTranslation(String key, Language lan, String value) {
        Connection con = DerbyLoader.getConnection(DerbyLoader.INFO_DB);
        String lanString = "value_";
        switch (lan) {
            case English: lanString += "en"; break;
            case German: lanString += "de"; break;
            case French: lanString += "fr"; break;
        }
        try {
            if (!con.isClosed()) {
                PreparedStatement ps = con.prepareStatement("UPDATE Translations SET "+lanString+" = ? WHERE PropKey = ?");
                ps.setString(1, value);
                ps.setString(2, key);
                ps.execute();
                ps.close();
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
    }
    
    public static List<String> getTranslationKeys() {
        Vector<String> lst = new Vector<String>();
        Connection con = DerbyLoader.getConnection(DerbyLoader.INFO_DB);
        try {
            if (!con.isClosed()) {
                String checkSQL = "SELECT PropKey FROM Translations";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(checkSQL);
                while (rs.next()) {
                    lst.add(rs.getString("PropKey"));
                } 
                rs.close();
                st.close();
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }        
        return lst;
    }
}
