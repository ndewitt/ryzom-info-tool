/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */


package ryzominfotool.db;

import java.sql.*;

/**
 * Related to the Property Table in the database.
 * Its for setting and retrieving stored property values
 * 
 * @author Niels-Peter de Witt
 */
public class PropertyDbHandler {

    /**
     * Sets the new property value into the database. The old value will be 
     * returned.
     * 
     * @param key - the key of the property
     * @param value - the value to set
     * @return the old value of the property.
     * 
     * @throws java.sql.SQLException in case the property could not be set in 
     * the database
     */
    public static String setProperty(String key, String value) throws SQLException
    {
        String oldValue = null;

        String sqlString = "SELECT Property, Value FROM Properties WHERE Property ='" + key + "'";
        Statement st = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
        ResultSet rs = st.executeQuery(sqlString);
        boolean existsProperty = false;
        if (rs.next())
        {
            existsProperty = true;
            oldValue = rs.getString("Value");
        }
        rs.close();
        rs = null;
        st.close();
        st = null;

        if (existsProperty)
        {
            Statement st2 = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
            String sqlUpdate = "DELETE  FROM Properties WHERE Property = '" + key + "'";
            st2.executeUpdate(sqlUpdate);
            st2.close();
            st2 = null;
        }
        Statement st3 = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
        String sqlInsert = "INSERT INTO Properties VALUES('" + key + "', '" + value + "')";
        st3.executeUpdate(sqlInsert);
        st3.close();
        st3 = null;
        return oldValue;
    }

    /**
     * Returns the property from the database
     * @param key - the key to lookup
     * @return the property related to the key - may be null, if property
     * does not exists.
     * 
     * @throws java.sql.SQLException in case getting of the property fails
     */
    public static String getProperty(String key) throws SQLException
    {
        String oldValue = null;

        String sqlString = "SELECT Property, Value FROM Properties WHERE Property ='" + key + "'";
        Statement st = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
        ResultSet rs = st.executeQuery(sqlString);
        if (rs.next())
        {
            oldValue = rs.getString("Value");
        }
        rs.close();
        rs = null;
        st.close();
        return oldValue;
    }
}
