/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import ryzominfotool.Enums.*;
import ryzominfotool.utils.*;

/**
 * Related to the Materials in the database
 * 
 * @author Niels-Peter de Witt
 */
public class MaterialDbHandler
{

    private static MyMap<Categorie, List<Material>> loadedMats = new MyMap<Categorie, List<Material>>();
    private static boolean matsAlreadyLoaded = false;

    /**
     * Returns the cached loaded mats. 
     * 
     * @return the map with Lists of Materials for Categories. Maybe empty
     */
    public static synchronized MyMap<Categorie, List<Material>> getLoadedMats()
    {
         return loadedMats;
    }

    /**
     * Loads the Materials from the database into the cache once called.
     * 
     * @throws java.sql.SQLException in case the mats could not be retrieved.
     */
    public static synchronized void loadMats() throws SQLException
    {
        if (matsAlreadyLoaded)
        {
            return;
        }
        Statement st = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
        ResultSet set = st.executeQuery("SELECT * from Materials ORDER BY Name");
        while (set.next())
        {
            Material m = analyseSet(set);
            addMaterial(m.getCategorie(), m);

        }
        set.close();
        set = null;
        st.close();
        st = null;
        matsAlreadyLoaded = true;
                
    }

    /**
     * Retrieves a list of Materials with the given itemId
     * 
     * @param itemId - the item Id of the materials to get
     * @return A list of Materials. Maybe a empty list, in case no Material
     * exists for this itemId.-
     * 
     * @throws java.sql.SQLException in case the retrieving fails
     */
    public static List<Material> getMats(String itemId) throws SQLException
    {
        List<Material> rv = new Vector<Material>();
        Statement st = DerbyLoader.getConnection(DerbyLoader.INFO_DB).createStatement();
        ResultSet set = st.executeQuery("SELECT * from Materials WHERE Item_ID = '" + itemId + "'");
        while (set.next())
        {
            Material m = analyseSet(set);
            rv.add(m);
        }
        set.close();
        set = null;
        return rv;
    }

    /**
     * Helper routine, that adds the mat to its categorie
     * @param cat - the categorie to add mat to
     * @param mat - the mat to add
     */
    private static void addMaterial(Categorie cat, Material mat)
    {
        if (getLoadedMats().containsKey(cat))
        {
            List<Material> v = getLoadedMats().get(cat);
            v.add(mat);
        }
        else
        {
            List<Material> v = new Vector<Material>();
            v.add(mat);
            getLoadedMats().put(cat, v);
        }

    }

    /**
     * Sorts a list of Materials by Name and Grade
     * 
     * @param lst - lst to sort
     */
    public static void sortByNameAndGrade(java.util.List<Material> lst)
    {
        Comparator cmp = new Comparator()
        {

            @Override
            public int compare(Object o1, Object o2)
            {
                Material m1 = (Material) o1;
                Material m2 = (Material) o2;
                int rv = 0;
                rv = m1.getName().compareTo(m2.getName());
                if (rv == 0)
                {
                    if (m1.getGrade().getOrder() > m2.getGrade().getOrder())
                    {
                        rv = 1;
                    }
                    else if (m1.getGrade().getOrder() == m2.getGrade().getOrder())
                    {
                        rv = 0;
                    }
                    else
                    {
                        rv = -1;
                    }
                }
                return rv;
            }
        };

        Collections.sort(lst, cmp);
    }

    /**
     * Analysis a Resultset row of a Material and returns the related material.
     * In case it does not contain material data, null is returned
     * 
     * @param set - the resultset at the row to analyse
     * @return The analysed Material or null, if a failure occured
     */
    private static Material analyseSet(ResultSet set)
    {
        Material mat = null;
        try
        {
            int id = set.getInt("Id");
            String categorie = set.getString("Categorie");
            String rtype = set.getString("RType");
            String grade = set.getString("Grade");
            String name = set.getString("Name");
            String race = set.getString("Race");
            String color = set.getString("Color");
            int maxLevel = set.getInt("MaxLevel");
            String itemId = set.getString("Item_ID");
            String description = set.getString("Description");


            mat = new Material(Source.valueOf(rtype),
                    Grade.valueOf(grade),
                    name,
                    MatColor.valueOf(color),
                    Categorie.valueOf(categorie));
            mat.setDB_ID(id);
            mat.setDescription(description);
            mat.setItemID(itemId);
            mat.setQualityLevel(maxLevel);

            for (Status status : Status.values())
            {
                try
                {
                    int value = set.getInt(status.name());
                    mat.setStatusValue(status, value);
                }
                catch (SQLException exc)
                {
                    // status not existend for mat, or problem with DB
                }
            }
            mat.setRace(Race.valueOf(race));
        }
        catch (SQLException exc)
        {
            exc.printStackTrace();
        }
        return mat;
    }

    /**
     * Returns a list of alternate materials, with similar stats to the one
     * passed.
     * @param list - list of input Materials to look into
     * @param lookup - the material to find alternates for
     * @return A list with alternate materials. Maybe empty
     */
    public static List<Material> getAlternateMaterial(List<Material> list, Material lookup)
    {
        List<Material> rv = new Vector();
        if (list != null)
        {
            for (Material m : list)
            {
                if (!m.equals(lookup))
                {
                    boolean equal = true;
                    for (Iterator<Status> it = lookup.getStati().iterator(); it.hasNext() && equal;)
                    {
                        Status s = it.next();
                        equal &= lookup.getStatusValue(s) == m.getStatusValue(s);
                    }
                    if (equal)
                    {
                        rv.add(m);
                    }
                }
            }

        }
        return rv;
    }
}
