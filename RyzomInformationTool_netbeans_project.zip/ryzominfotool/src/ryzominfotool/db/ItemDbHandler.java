/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */


package ryzominfotool.db;

import java.sql.*;
import ryzominfotool.Enums.Language;

/**
 * Realted to the Item table.
 * 
 * @author Niels-Peter de Witt
 */
public class ItemDbHandler {

    /**
     * Returns the item description in the given language
     * 
     * @param itemId - the itemid to get a description for
     * @param lan - the language to get the description for
     * @return The description of the item. "" if no description is found
     * @throws java.sql.SQLException in case the retrival fails
     */
    public static String getItemDescription(String itemId, Language lan) throws SQLException
    {
        String rv = "";
        String lanCol = "";
        switch (lan)
        {
            case English:
                lanCol = "Name_En";
                break;
            case French:
                lanCol = "Name_Fr";
                break;
            case German:
                lanCol = "Name_De";
                break;
        }
        String sql = "SELECT " + lanCol + " FROM Items WHERE ItemCode = ?";
        PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(sql);
        ps.setString(1, itemId);
        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            rv = rs.getString(1);
        }
        if (rv == null)
        {
            rv = "";
        }
        rs.close();
        rs = null;
        ps.close();
        ps = null;
        return rv;
    }

}
