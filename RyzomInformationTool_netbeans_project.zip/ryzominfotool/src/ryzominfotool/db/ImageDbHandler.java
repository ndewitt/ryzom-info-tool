/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */

package ryzominfotool.db;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import javax.imageio.ImageIO;

/**
 * This handler gives acces to get Images from the database by its itemcode.
 * In case a image is not available, it will be tried to load it from the 
 * ryzom API and stored in DB
 * 
 * It is especially only useable for images that are only available via the 
 * Ryzom API
 * 
 * @author Niels-Peter de Witt
 */
public class ImageDbHandler {


    /**
     * Returns the Image belonging to the item code
     * 
     * @param itemCode - code of the image
     * @return The image. Maybe null, if no image could be accessed.
     * @throws java.sql.SQLException in case the loading from the database fails
     * @throws java.io.IOException in case the image could not be read via the
     * ryzom API
     */
    public static BufferedImage getItemImage(String itemCode) throws SQLException, IOException
    {
        return getItemImage(itemCode, "");
    }

    /**
     * Returns the image with the given color code. This is especially for
     * armors, because the itemcode itself does not provide the color.
     * 
     * @param itemCode - the code of the item
     * @param colorCode - the color of the item
     * @return The image. Maybe null, if no image could be accessed.
     * @throws java.sql.SQLException in case the loading from the database fails
     * @throws java.io.IOException in case the image could not be read via the
     * ryzom API
     */
    public static BufferedImage getItemImage(String itemCode, String colorCode) throws SQLException, IOException
    {
        BufferedImage rv = null;
        // CREATE TABLE Images (itemCode varchar(100) NOT NULL PRIMARY KEY, imageData Blob)
        String sql = "SELECT imageData FROM Images WHERE itemCode = ?";
        PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(sql);
        ps.setString(1, itemCode + colorCode);
        ResultSet rs = ps.executeQuery();
        boolean imgFound = false;
        while (rs.next())
        {
            Blob blob = rs.getBlob("imageData");
            rv = ImageIO.read(blob.getBinaryStream());
            imgFound = true;
        }
        if (!imgFound)
        {
            rv = getItemImageFromAPI(itemCode, colorCode, true);
        }
        rs.close();
        ps.close();
        rs = null;
        ps = null;
        return rv;
    }

    /**
     * Returns the Image read from the Ryzom API and stores it into the DB
     * 
     * @param itemCode - the code of the item
     * @param colorCode - the  color of the item
     * @param storeInDb - true if the image should be stored in the DB
     * @return the image read from the API
     * @throws java.sql.SQLException in case the loading from the database fails
     * @throws java.io.IOException in case the image could not be read via the
     * ryzom API
     */
    public static BufferedImage getItemImageFromAPI(String itemCode, String colorCode, boolean storeInDb) throws IOException, SQLException
    {
        URL url = new URL("http://atys.ryzom.com/api/item_icon.php?sheetid=" + itemCode + ".sitem&c=" + colorCode);
        System.out.println("Loading new image " + itemCode + colorCode);
        BufferedImage img = ImageIO.read(url);
        if (storeInDb) {
            String insertImg = "INSERT INTO Images (itemCode, imageData) VALUES (?, ?)";
            PreparedStatement ps = DerbyLoader.getConnection(DerbyLoader.INFO_DB).prepareStatement(insertImg);
            ps.setString(1, itemCode + colorCode);
            ps.setBlob(2, url.openStream());
            ps.execute();
            ps.close();
        }
        return img;
    }
}
