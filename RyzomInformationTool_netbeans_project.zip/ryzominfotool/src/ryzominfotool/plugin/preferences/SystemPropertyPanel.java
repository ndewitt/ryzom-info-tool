/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.plugin.preferences;

import java.awt.Cursor;
import java.net.URL;
import ryzominfotool.gui.*;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.PropertyDbHandler;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.borders.CustomBorder;

/**
 * A panel for System-Properties
 * @author  Niels-Peter de Witt
 */
public class SystemPropertyPanel extends PluggableContent
{

    private boolean manualUpdateOfProxyProperties = false;
    private CustomBorder custBorder = new CustomBorder();
    private boolean isManualLanguageChange = false;
    private Language curLanguage = Language.English;
    private class PropTableModel extends AbstractTableModel {
        
        private Vector<String> keys = new Vector<String>();

        @Override
        public String getColumnName(int column)
        {
            String rv = "";
            switch (column) {
                case 0:
                    rv = TranslationDbHandler.getTranslation(this.getClass().getName() + ".propname", curLanguage, "Property Name");
                    break;
                case 1:
                    rv = TranslationDbHandler.getTranslation(this.getClass().getName() + ".propclass", curLanguage, "Property Class");
                    break;
                case 2:
                    rv = TranslationDbHandler.getTranslation(this.getClass().getName() + ".propdesc", curLanguage, "Property Description");
                    break;
            }
            return rv;
        }
        
        @Override
        public int getRowCount()
        {
            return keys.size();
        }

        @Override
        public int getColumnCount()
        {
            return 3;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex)
        {
            String rv = "";
            String key = keys.get(rowIndex);
            switch(columnIndex) {
                case 0: // key value
                    rv = key;
                    break;
                case 1: // class
                    rv = getFrame().getPropertyValueClass(key);
                    break;
                case 2: // description
                    rv = getFrame().getPropertyDescription(key);
                    break;
            }
            return rv;
        }
        
        public void updateTableData() {
            keys.clear();
            keys.addAll(getFrame().getPropertyKeys());
            fireTableDataChanged();
        }
    };
    private PropTableModel propTblModel = new PropTableModel();
    
    
    /** Creates new form SystemPropertyPanel */
    public SystemPropertyPanel()
    {
        initComponents();
        try
        {
            String useProxy = PropertyDbHandler.getProperty("http.proxySet");
            String proxyUrl = PropertyDbHandler.getProperty("http.proxyHost");
            String proxyPort = PropertyDbHandler.getProperty("http.proxyPort");
            if (!(useProxy == null | proxyPort == null || proxyUrl == null))
            {
                manualUpdateOfProxyProperties = true;
                txtProxyPort.setText(proxyPort);
                txtProxyUrl.setText(proxyUrl);
                chkUseProxy.setSelected("true".equalsIgnoreCase(useProxy));
                System.setProperty("http.proxySet", useProxy);
                System.setProperty("http.proxyHost", proxyUrl);
                System.setProperty("http.proxyPort", proxyPort);

                manualUpdateOfProxyProperties = false;
            }
            isManualLanguageChange = true;
            cmbLanguage.removeAllItems();
            cmbLanguage.addItem(Language.English);
            cmbLanguage.addItem(Language.German);
            cmbLanguage.addItem(Language.French);
            isManualLanguageChange = false;
            String language = PropertyDbHandler.getProperty("Language");
            Language lan = Language.valueOf(language);
            cmbLanguage.setSelectedItem(lan);
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
        }
        tblCurProperties.setModel(propTblModel);
        tblCurProperties.getTableHeader().setReorderingAllowed(false);
        TimerTask propTask = new TimerTask() {

            @Override
            public void run()
            {
                propTblModel.updateTableData();
            }
        };
        Timer propTimer = new Timer();
        propTimer.schedule(propTask, 5*1000, 10*1000);
        startMemoryMonitoring();
    }
    
    /**
     * Memory watch starting
     */
    private void startMemoryMonitoring() {
        TimerTask tt = new TimerTask() {

            @Override
            public void run()
            {
                long totalMem = Runtime.getRuntime().totalMemory()/1024/1024;
                long usedMem = (Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1024/1024;
                lblMemUsageVal.setText(usedMem+"/"+totalMem+" MB");
            }
        };
        Timer t = new Timer();
        t.schedule(tt, 0, 1000*10);
    }    

    @Override
    public void setFrame(FrameworkFrame frame)
    {
        super.setFrame(frame);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panProxy = new javax.swing.JPanel();
        chkUseProxy = new javax.swing.JCheckBox();
        lblProxyUrl = new javax.swing.JLabel();
        lblProxyPort = new javax.swing.JLabel();
        txtProxyUrl = new javax.swing.JTextField();
        txtProxyPort = new javax.swing.JTextField();
        panLanguage = new javax.swing.JPanel();
        lblLanguage = new javax.swing.JLabel();
        cmbLanguage = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        panMemory = new javax.swing.JPanel();
        lblMemUsage = new javax.swing.JLabel();
        lblMemUsageVal = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCurProperties = new javax.swing.JTable();

        setBackground(new java.awt.Color(200, 255, 200));
        setLayout(new java.awt.GridBagLayout());

        panProxy.setBackground(new java.awt.Color(255, 255, 204));
        panProxy.setBorder(custBorder);
        panProxy.setLayout(new java.awt.GridBagLayout());

        chkUseProxy.setText("null");
        chkUseProxy.setOpaque(false);
        chkUseProxy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkUseProxyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panProxy.add(chkUseProxy, gridBagConstraints);

        lblProxyUrl.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panProxy.add(lblProxyUrl, gridBagConstraints);

        lblProxyPort.setText("null");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panProxy.add(lblProxyPort, gridBagConstraints);

        txtProxyUrl.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtProxyUrlFocusLost(evt);
            }
        });
        txtProxyUrl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProxyUrlKeyTyped(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panProxy.add(txtProxyUrl, gridBagConstraints);

        txtProxyPort.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtProxyPortFocusLost(evt);
            }
        });
        txtProxyPort.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProxyPortKeyTyped(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panProxy.add(txtProxyPort, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        add(panProxy, gridBagConstraints);

        panLanguage.setBackground(new java.awt.Color(255, 255, 204));
        panLanguage.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panLanguage.setLayout(new java.awt.GridBagLayout());

        lblLanguage.setText("Language:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panLanguage.add(lblLanguage, gridBagConstraints);

        cmbLanguage.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbLanguage.setMinimumSize(new java.awt.Dimension(120, 24));
        cmbLanguage.setPreferredSize(new java.awt.Dimension(120, 24));
        cmbLanguage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbLanguageActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panLanguage.add(cmbLanguage, gridBagConstraints);

        jPanel3.setMinimumSize(new java.awt.Dimension(1, 1));
        jPanel3.setOpaque(false);
        jPanel3.setPreferredSize(new java.awt.Dimension(1, 1));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 265, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panLanguage.add(jPanel3, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        add(panLanguage, gridBagConstraints);

        panMemory.setBackground(new java.awt.Color(255, 255, 204));
        panMemory.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panMemory.setOpaque(false);
        panMemory.setLayout(new java.awt.GridBagLayout());

        lblMemUsage.setText("Memory usage: ");
        panMemory.add(lblMemUsage, new java.awt.GridBagConstraints());
        panMemory.add(lblMemUsageVal, new java.awt.GridBagConstraints());

        jPanel1.setOpaque(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        panMemory.add(jPanel1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        add(panMemory, gridBagConstraints);

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        jPanel4.setLayout(new java.awt.BorderLayout());

        tblCurProperties.setAutoCreateRowSorter(true);
        tblCurProperties.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblCurProperties.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(tblCurProperties);

        jPanel4.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        add(jPanel4, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void chkUseProxyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkUseProxyActionPerformed
    updateProxyData();
}//GEN-LAST:event_chkUseProxyActionPerformed

private void txtProxyPortKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProxyPortKeyTyped
    updateProxyData();
}//GEN-LAST:event_txtProxyPortKeyTyped

private void txtProxyUrlKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProxyUrlKeyTyped
    updateProxyData();
}//GEN-LAST:event_txtProxyUrlKeyTyped

private void txtProxyUrlFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtProxyUrlFocusLost
    updateProxyData();
}//GEN-LAST:event_txtProxyUrlFocusLost

private void txtProxyPortFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtProxyPortFocusLost
    updateProxyData();
}//GEN-LAST:event_txtProxyPortFocusLost

private void cmbLanguageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbLanguageActionPerformed
    if (isManualLanguageChange) return;
    cmbLanguage.setEnabled(false);
    final Language lan = (Language) cmbLanguage.getSelectedItem();
    try {
        PropertyDbHandler.setProperty("Language", lan.name());
    } catch (SQLException exc) {
        getFrame().addLog(exc);
    }
    if (getFrame() != null)
    {
        Runnable runner = new Runnable()
        {

                @Override
            public void run()
            {
                getFrame().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                getFrame().setCurrentLanguage(lan);
                getFrame().setCursor(Cursor.getDefaultCursor());
                cmbLanguage.setEnabled(true);
            }
        };
        Thread t = new Thread(runner);
        t.start();
    }
    else
    {
        cmbLanguage.setEnabled(true);
    }

}//GEN-LAST:event_cmbLanguageActionPerformed

    private void updateProxyData()
    {
        boolean useProxy = chkUseProxy.isSelected();
        String proxyUrl = txtProxyUrl.getText();
        String proxyPort = txtProxyPort.getText();
        System.setProperty("http.proxySet", useProxy + "");
        System.setProperty("http.proxyHost", proxyUrl);
        System.setProperty("http.proxyPort", proxyPort);
        if (!manualUpdateOfProxyProperties)
        {
            try
            {
                PropertyDbHandler.setProperty("http.proxySet", useProxy + "");
                PropertyDbHandler.setProperty("http.proxyHost", proxyUrl);
                PropertyDbHandler.setProperty("http.proxyPort", proxyPort);
            }
            catch (SQLException exc)
            {
                exc.printStackTrace();
            }
        }
//    System.out.println(""+System.getProperties().entrySet());
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkUseProxy;
    private javax.swing.JComboBox cmbLanguage;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblLanguage;
    private javax.swing.JLabel lblMemUsage;
    private javax.swing.JLabel lblMemUsageVal;
    private javax.swing.JLabel lblProxyPort;
    private javax.swing.JLabel lblProxyUrl;
    private javax.swing.JPanel panLanguage;
    private javax.swing.JPanel panMemory;
    private javax.swing.JPanel panProxy;
    private javax.swing.JTable tblCurProperties;
    private javax.swing.JTextField txtProxyPort;
    private javax.swing.JTextField txtProxyUrl;
    // End of variables declaration//GEN-END:variables

    @Override
    public String getDisplayName()
    {
        return TranslationDbHandler.getTranslation(this.getClass().getName() + ".displayName", curLanguage, "Preferences");
    }

    @Override
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        lblLanguage.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblLanguage", curLanguage, "Language:"));
        lblProxyPort.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblProxyPort", curLanguage, "Proxy Port:"));
        lblProxyUrl.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblProxyUrl", curLanguage, "Proxy URL:"));
        chkUseProxy.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".chkUseProxy", curLanguage, "use Proxy"));
        lblMemUsage.setText(TranslationDbHandler.getTranslation(this.getClass().getName() + ".lblMemUsage", curLanguage, "Memory usage: "));
    }

    @Override
    public URL getHelpURL()
    {
        URL url = null;
        switch (curLanguage)
        {
            case English:
                url = this.getClass().getResource("help/help_en.html");
                break;
            case German:
                url = this.getClass().getResource("help/help_de.html");
                break;
            case French:
                url = this.getClass().getResource("help/help_fr.html");
                break;
        }
        return url;
    }

    @Override
    public String getPluginId()
    {
        return "Preference Plugin V0.1";
    }
}
