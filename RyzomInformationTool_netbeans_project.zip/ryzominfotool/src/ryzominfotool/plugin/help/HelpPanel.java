/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool.plugin.help;

import java.awt.Component;
import java.io.IOException;
import java.net.URL;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import ryzominfotool.Enums.Language;
import ryzominfotool.db.TranslationDbHandler;
import ryzominfotool.gui.FrameworkFrame;
import ryzominfotool.gui.PluggableContent;

/**
 * A Help Panel, that gathers help pages from Plugins and displays them
 * @author  Niels-Peter de Witt
 */
public class HelpPanel extends PluggableContent
{
    private Language curLanguage = Language.English;
    private DefaultListModel model = new DefaultListModel();
    private AboutPanel aboutPanel = new AboutPanel();
    private DefaultListCellRenderer renderer = new DefaultListCellRenderer()
    {

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
            JLabel rv = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            PluggableContent plugin = (PluggableContent) value;
            rv.setText(plugin.getDisplayName());
            return rv;
        }
    };

    /** Creates new form HelpPanel */
    public HelpPanel()
    {
        initComponents();
        lstHelpEntries.setModel(model);
        lstHelpEntries.setCellRenderer(renderer);
        lstHelpEntries.getSelectionModel().addListSelectionListener(new ListSelectionListener()
        {

            @Override
            public void valueChanged(ListSelectionEvent e)
            {
                updateHelpContent();
            }
        });
    }

    @Override
    public void setFrame(FrameworkFrame frame)
    {
        super.setFrame(frame);
        if (frame != null)
        {
            loadHelpContents();
        }
    }

    /**
     * Retrieves the help content from the registered PluggableContents
     */
    public void loadHelpContents()
    {

        java.util.List<PluggableContent> plugins = getFrame().getPluggableContents();
        model.clear();
        if (aboutPanel.getHelpURL() != null) {
            model.addElement(aboutPanel);
        }
        for (PluggableContent p : plugins)
        {
            if (p.getHelpURL() != null)
            {
                model.addElement(p);
            }
        }
    }

    public void updateHelpContent()
    {
        lstHelpEntries.setEnabled(false);
        
        PluggableContent p = (PluggableContent) lstHelpEntries.getSelectedValue();
        if (p != null)
        {
            try
            {
                edtHelpContent.setPage(p.getHelpURL());
            }
            catch (IOException exc)
            {
                exc.printStackTrace();
                edtHelpContent.setText("Cannot load " + exc.getMessage());
            }
        }
        else
        {
            edtHelpContent.setText("");
        }
        lstHelpEntries.setEnabled(true);
    }
    
    private class AboutPanel extends PluggableContent {
        Language currentLanguage = Language.English;
        @Override
        public String getDisplayName()
        {
            return TranslationDbHandler.getTranslation(this.getClass().getName() + ".displayName", curLanguage, "About");
        }

        @Override
        public void setLanguage(Language lan)
        {
            currentLanguage = lan;
        }

        @Override
        public String getPluginId()
        {
            return "ABOUT";
        }

        @Override
        public URL getHelpURL()
        {
            URL url = null;
            switch (curLanguage)
            {
                case English:
                    url = this.getClass().getResource("help/help_en.html");
                    break;
                case German:
                    url = this.getClass().getResource("help/help_de.html");
                    break;
                case French:
                    url = this.getClass().getResource("help/help_fr.html");
                    break;
            }
            return url;
        }
        
        
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        panHelpEntries = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstHelpEntries = new javax.swing.JList();
        panHelpContent = new javax.swing.JPanel();
        scrHelpContent = new javax.swing.JScrollPane();
        edtHelpContent = new javax.swing.JEditorPane();

        setBackground(new java.awt.Color(200, 255, 200));
        setLayout(new java.awt.GridBagLayout());

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        panHelpEntries.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panHelpEntries.setOpaque(false);
        panHelpEntries.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setMinimumSize(new java.awt.Dimension(120, 22));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(150, 139));

        lstHelpEntries.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(lstHelpEntries);

        panHelpEntries.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panHelpEntries, gridBagConstraints);

        panHelpContent.setBackground(new java.awt.Color(200, 255, 200));
        panHelpContent.setBorder(new ryzominfotool.gui.borders.CustomBorder());
        panHelpContent.setLayout(new java.awt.BorderLayout());

        edtHelpContent.setContentType("text/html");
        edtHelpContent.setEditable(false);
        scrHelpContent.setViewportView(edtHelpContent);

        panHelpContent.add(scrHelpContent, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel1.add(panHelpContent, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        add(jPanel1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane edtHelpContent;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList lstHelpEntries;
    private javax.swing.JPanel panHelpContent;
    private javax.swing.JPanel panHelpEntries;
    private javax.swing.JScrollPane scrHelpContent;
    // End of variables declaration//GEN-END:variables

    @Override
    public String getDisplayName()
    {
        return TranslationDbHandler.getTranslation(this.getClass().getName() + ".displayName", curLanguage, "Help");
    }

    @Override
    public void setLanguage(Language lan)
    {
        curLanguage = lan;
        aboutPanel.setLanguage(lan);
    }

    @Override
    public URL getHelpURL()
    {
        URL url = null;
        switch (curLanguage)
        {
            case English:
                url = this.getClass().getResource("help/help_en.html");
                break;
            case German:
                url = this.getClass().getResource("help/help_de.html");
                break;
            case French:
                url = this.getClass().getResource("help/help_fr.html");
                break;
        }
        return url;
    }

    @Override
    public String getPluginId()
    {
        return "Help Plugin V0.1";
    }
}
