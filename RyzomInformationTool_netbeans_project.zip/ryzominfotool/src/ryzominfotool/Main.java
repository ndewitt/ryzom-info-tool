/**
 * 
 * Copyright: Niels-Peter de Witt (ndewitt@gmx.de), 2009
 * 
 * This file is Ryzom Information Tool
 * 
 * Ryzom Information Tool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Ryzom Information Tool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with Ryzom Information Tool.  If not, see <http://www.gnu.org/licenses/>.
 */
package ryzominfotool;

import ryzominfotool.plugin.log.LogPanel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JWindow;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import ryzominfotool.db.DerbyLoader;
import ryzominfotool.db.MaterialDbHandler;
import ryzominfotool.db.PropertyDbHandler;
import ryzominfotool.gui.FrameworkFrame;
import ryzominfotool.gui.PluggableContent;
import ryzominfotool.plugin.help.HelpPanel;
import ryzominfotool.plugin.preferences.SystemPropertyPanel;

/**
 * The Main class of the Ryzom Info Tool
 * During startup the first is opening the database for public access and the
 * loading the plugins and adding them to the framework.
 * During the loading a Splash-Screen is displayed.
 * @author Niels-Peter de Witt
 */
public class Main {

    /** The VERSION Identifier of the tool */
    public final static String VERSION = "1.1";
    /** The Frame that will be opened */
    private static FrameworkFrame frame = null;

    /**
     * Start methods.
     * @param args
     */
    public static void main(String[] args) {
        new Main(args);
    }

    /**
     * Constructor that opens the DB and opens the frame with the loaded plugins,
     * while showing a SplashScreen during power up.
     * @param args - tha passed arguments. Ignored at the moment
     */
    private Main(final String args[]) {
        try {
            DerbyLoader.open(DerbyLoader.INFO_DB, false, "user1", "user1");
        } catch (Exception ex) {
            Main.showErrorDialog("Another instance is already running on the database.");
            ex.printStackTrace();
            System.exit(-1);
        }
        final JWindow w = new JWindow();
        w.getContentPane().setLayout(new BorderLayout());
        try {
            SplashIcon ic = new SplashIcon();
            JLabel lblIc = new JLabel(ic);
            lblIc.setOpaque(true);
            w.getContentPane().add(lblIc, BorderLayout.CENTER);
            w.setSize(ic.getIconWidth(), ic.getIconHeight());
            Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
            w.setLocation((d.width - w.getWidth()) / 2, (d.height - w.getWidth()) / 2);
            w.setVisible(true);
        } catch (Exception exc) {
            exc.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                try {
                    MaterialDbHandler.loadMats();
                } catch (SQLException exc) {
                    exc.printStackTrace();
                }
                final long SCHEDULE_TIME = 10*1000;
                TimerTask serverTickTask = new TimerTask() {

                    int counter[] = new int[] {0,0,0};
                    long lastExecution[] = new long[] {0,0,0};
                    long lastServerSync[] = new long[] {0,0,0};

                    @Override
                    public void run() {
                        long curExecution = System.currentTimeMillis();

                        for (Enums.Server s : Enums.Server.values()) {
                            if (frame != null ) {
                                long newTick = 0;
                                if (counter[s.ordinal()] == 0) {
                                    // do resync with server
                                    newTick = Main.getServerTick(s);
                                    lastServerSync[s.ordinal()] = curExecution;
//                                    System.out.println("Server Sync with server "+s.name());
                                } else {
                                    Long lastTick = (Long) frame.getProperty("common.servertick." + s.name());
                                    long additionalTicks = (curExecution-lastExecution[s.ordinal()])/100;
                                    newTick = (lastTick+additionalTicks);
//                                    System.out.println("Calc time for server "+s.name());
                                }
                                counter[s.ordinal()]++;
                                lastExecution[s.ordinal()] = curExecution;
                                if (curExecution-lastServerSync[s.ordinal()] > 5*60*1000) {
                                    counter[s.ordinal()] = 0;
                                }
                                frame.setProperty(this, "common.servertick." + s.name(), newTick, "Current ServerTick for "+s.name()+ " updated every "+SCHEDULE_TIME);
                            }
                        }
                    }
                };
                Timer serverTickTimer = new Timer();
                serverTickTimer.schedule(serverTickTask, 10 * 1000, SCHEDULE_TIME);

                frame = new FrameworkFrame();
                frame.setSize(1024, 786);
                frame.setTitle("Ryzom Information Tool" + " " + VERSION);
                loadPlugins(frame);
                Enums.Language lan = Enums.Language.English;
                try {
                    String language = PropertyDbHandler.getProperty("Language");
                    lan = Enums.Language.valueOf(language);
                } catch (SQLException exc) {
                    exc.printStackTrace();
                }

                frame.setCurrentLanguage(lan);
                frame.setVisible(true);
                w.setVisible(false);
            }
        });

    }

    public static Long getServerTick(Enums.Server server) {
        Long st = Long.valueOf(-1);
        try {
            String urlTxt = "http://atys.ryzom.com/api/time.php?shardid=";
            switch (server) {
                case Arispotle:
                    urlTxt += "ari";
                    break;
                case Aniro:
                    urlTxt += "ani";
                    break;
                case Leanon:
                    urlTxt += "lea";
                    break;
            }
            URL url = new URL(urlTxt);
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            String tick = br.readLine();
            st = Long.parseLong(tick);
            br.close();
        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return st;
    }

    /**
     * This loads the Plugins from the "/plugins" folder next to the executable
     * jar file and searchs for a plugin-XML in there with the related Jar-File
     * of the plugin.
     * The plugins are added to the frame and a log is saved to the log panel.
     * 
     * @param frame - the frame to add loaded plugins to.
     */
    public void loadPlugins(FrameworkFrame frame) {

        LogPanel logPanel = new LogPanel();

        SAXBuilder builder = new SAXBuilder();
        File pluginDir = new File("./plugins");
        if (!pluginDir.exists()) {
            pluginDir.mkdirs();
        } else {
            File[] files = pluginDir.listFiles();
            Arrays.sort(files);
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile() && file.getName().toLowerCase().endsWith(".xml")) {
                    logPanel.addLog("Checking xml file: " + file.getAbsolutePath());
                    try {
                        Document doc = builder.build(new FileReader(file));
                        Element root = doc.detachRootElement();
                        String rootName = root.getName();
                        if (rootName.equalsIgnoreCase("ryzominfotoolplugin")) {
                            Element pluginName = root.getChild("PluginName");
                            String name = "";
                            String className = "";
                            String jarFile = "";

                            if (pluginName != null) {
                                name = pluginName.getValue();

                            }
                            Element pluginClass = root.getChild("PluginClass");
                            if (pluginClass != null) {
                                className = pluginClass.getValue();
                            }
                            Element pluginJar = root.getChild("PluginJar");
                            if (pluginJar != null) {
                                jarFile = pluginJar.getValue();
                            }
                            File jar = new File(pluginDir, jarFile);
                            URLClassLoader cl = new URLClassLoader(new URL[]{jar.toURI().toURL()}, ClassLoader.getSystemClassLoader());
                            Class c = cl.loadClass(className);
                            Constructor ct = c.getConstructor(new Class[0]);
                            Object retobj = ct.newInstance(new Object[0]);
                            if (retobj instanceof PluggableContent) {
                                PluggableContent cont = (PluggableContent) retobj;
                                frame.addPluggableContent(cont);
                                logPanel.addLog("\tLoaded Plugin: " + cont.getPluginId());
                            }
                        }
                    } catch (Exception exc) {
                        exc.printStackTrace();
                        logPanel.addException(exc);
                    }
                }
            }
        }
        frame.addPluggableContent(logPanel);
        frame.addPluggableContent(new SystemPropertyPanel());
        frame.addPluggableContent(new HelpPanel());
    }

    /**
     * Shows a, on the frame centered (if available) error dialog with the
     * given error message.
     * 
     * @param error - the error message to display
     */
    static public void showErrorDialog(String error) {
        JOptionPane.showMessageDialog(frame, error, "", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * A Splash Icon drawing the image located under "resource/splash.png" of
     * the executed jar file
     */
    private class SplashIcon implements Icon {

        private int width = 40;
        private int height = 40;
        private BufferedImage bg = null;

        /**
         * Contains the Image under "resource/splash.png".
         * The icon has the same size, as the loaded image.
         * @throws java.io.IOException in case the image could not be loaded
         */
        public SplashIcon() throws IOException {
            URL url = Main.class.getResource("resource/splash.png");
            bg = ImageIO.read(url);
            this.width = bg.getWidth();
            this.height = bg.getHeight();
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            g.drawImage(bg, 0, 0, bg.getWidth(), bg.getHeight(), c);
        }

        @Override
        public int getIconWidth() {
            return width;
        }

        @Override
        public int getIconHeight() {
            return height;
        }
    }
}
